local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1, L27_1, L28_1, L29_1, L30_1, L31_1, L32_1, L33_1, L34_1, L35_1, L36_1, L37_1, L38_1, L39_1, L40_1, L41_1, L42_1, L43_1, L44_1, L45_1, L46_1, L47_1, L48_1, L49_1, L50_1, L51_1, L52_1, L53_1, L54_1, L55_1, L56_1, L57_1, L58_1, L59_1, L60_1, L61_1, L62_1, L63_1, L64_1, L65_1, L66_1, L67_1, L68_1, L69_1
L0_1 = {}
L1_1 = "anim_casino_b@amb@casino@games@threecardpoker@dealer"
L2_1 = "anim_casino_b@amb@casino@games@shared@dealer@"
L3_1 = "anim_casino_b@amb@casino@games@threecardpoker@player"
L4_1 = "anim_casino_b@amb@casino@games@shared@player@"
L5_1 = nil
L6_1 = false
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = false
L11_1 = -2
L12_1 = 0
L13_1 = 0
L14_1 = 0
L15_1 = false
L16_1 = false
L17_1 = false
L18_1 = nil
L19_1 = 0
L20_1 = {}
L21_1 = 0
L22_1 = 0
L23_1 = 0
L24_1 = 0
L25_1 = {}
L26_1 = nil
L27_1 = nil
L28_1 = nil
L29_1 = nil
L30_1 = nil
function L31_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "Reset"
  L0_2(L1_2)
  L0_2 = {}
  L0_1 = L0_2
  L0_2 = nil
  L5_1 = L0_2
  L0_2 = false
  L6_1 = L0_2
  L0_2 = nil
  L7_1 = L0_2
  L0_2 = nil
  L8_1 = L0_2
  L0_2 = false
  L10_1 = L0_2
  L0_2 = -2
  L11_1 = L0_2
  L0_2 = 0
  L12_1 = L0_2
  L0_2 = 0
  L13_1 = L0_2
  L0_2 = 0
  L14_1 = L0_2
  L0_2 = false
  L15_1 = L0_2
  L0_2 = false
  L16_1 = L0_2
  L0_2 = false
  L17_1 = L0_2
  L0_2 = nil
  L18_1 = L0_2
  L0_2 = 0
  L19_1 = L0_2
  L0_2 = {}
  L20_1 = L0_2
  L0_2 = {}
  L25_1 = L0_2
  L0_2 = nil
  L26_1 = L0_2
  L0_2 = nil
  L27_1 = L0_2
  L0_2 = nil
  L28_1 = L0_2
  L0_2 = nil
  L29_1 = L0_2
  L0_2 = nil
  L30_1 = L0_2
end
function L32_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "DestroyTimerBars"
  L0_2(L1_2)
  L0_2 = L30_1
  if nil ~= L0_2 then
    L0_2 = TimerBar
    L0_2 = L0_2.Destroy
    L1_2 = L30_1
    L0_2(L1_2)
    L0_2 = nil
    L30_1 = L0_2
  end
  L0_2 = L27_1
  if nil ~= L0_2 then
    L0_2 = TimerBar
    L0_2 = L0_2.Destroy
    L1_2 = L27_1
    L0_2(L1_2)
    L0_2 = nil
    L27_1 = L0_2
  end
  L0_2 = L28_1
  if nil ~= L0_2 then
    L0_2 = TimerBar
    L0_2 = L0_2.Destroy
    L1_2 = L28_1
    L0_2(L1_2)
    L0_2 = nil
    L28_1 = L0_2
  end
  L0_2 = L29_1
  if nil ~= L0_2 then
    L0_2 = TimerBar
    L0_2 = L0_2.Destroy
    L1_2 = L29_1
    L0_2(L1_2)
    L0_2 = nil
    L29_1 = L0_2
  end
  L0_2 = L26_1
  if nil ~= L0_2 then
    L0_2 = TimerBar
    L0_2 = L0_2.Destroy
    L1_2 = L26_1
    L0_2(L1_2)
    L0_2 = nil
    L26_1 = L0_2
  end
end
function L33_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "ResetSession"
  L0_2(L1_2)
  L0_2 = L32_1
  L0_2()
  L0_2 = ClearSceneEvent
  L0_2()
  L0_2 = nil
  L5_1 = L0_2
  L0_2 = false
  L6_1 = L0_2
  L0_2 = nil
  L18_1 = L0_2
  L0_2 = false
  L17_1 = L0_2
  L0_2 = nil
  L8_1 = L0_2
  L0_2 = false
  L10_1 = L0_2
  L0_2 = -2
  L11_1 = L0_2
  L0_2 = 0
  L12_1 = L0_2
  L0_2 = 0
  L13_1 = L0_2
  L0_2 = 0
  L14_1 = L0_2
  L0_2 = false
  L15_1 = L0_2
  L0_2 = false
  L16_1 = L0_2
  L0_2 = {}
  L20_1 = L0_2
  L0_2 = {}
  L25_1 = L0_2
end
function L34_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = DebugStart
  L1_2 = "PlayRandomIdleAnimation"
  L0_2(L1_2)
  L0_2 = L8_1
  if nil == L0_2 then
    return
  end
  L0_2 = nil
  L1_2 = IsPedMale
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  if L1_2 then
    L1_2 = "idle_var_"
    L2_2 = string
    L2_2 = L2_2.format
    L3_2 = "%02d"
    L4_2 = RandomNumber
    L5_2 = 1
    L6_2 = 13
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2, L6_2)
    L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    L1_2 = L1_2 .. L2_2
    L0_2 = L1_2
  end
  L1_2 = "female_idle_var_"
  L2_2 = string
  L2_2 = L2_2.format
  L3_2 = "%02d"
  L4_2 = RandomNumber
  L5_2 = 1
  L6_2 = 8
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2, L6_2)
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L1_2 = L1_2 .. L2_2
  L0_2 = L1_2
  L1_2 = PlaySynchronizedScene
  L2_2 = L8_1.coords
  L3_2 = L8_1.rotation
  L4_2 = L4_1
  L5_2 = L0_2
  L6_2 = false
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L2_2 = CreateNewSceneEndEvent
  L3_2 = L1_2
  L4_2 = 0.95
  L5_2 = L34_1
  L6_2 = 8000
  L7_2 = 500
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
end
function L35_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = DebugStart
  L2_2 = "GetPokerInstanceFromCoords"
  L1_2(L2_2)
  L1_2 = pairs
  L2_2 = L0_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.coords
    L7_2 = L7_2 - A0_2
    L7_2 = #L7_2
    L8_2 = 0.2
    if L7_2 < L8_2 then
      return L6_2
    end
  end
  L1_2 = nil
  return L1_2
end
function L36_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = DebugStart
  L4_2 = "PlayPedCardsPlay"
  L3_2(L4_2)
  L3_2 = A1_2.chairPositions
  L3_2 = L3_2[A2_2]
  L4_2 = PlaySynchronizedSceneOnPed
  L5_2 = A0_2
  L6_2 = L3_2.coords
  L7_2 = L3_2.rotation
  L8_2 = L3_1
  L9_2 = "cards_play"
  L10_2 = false
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = A1_2.acceptAndPlay
  L6_2 = L3_2.id
  L5_2(L6_2)
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  if A0_2 == L5_2 then
    L5_2 = CreateNewSceneEndEvent
    L6_2 = L4_2
    L7_2 = 0.9
    L8_2 = L34_1
    L9_2 = 5000
    L10_2 = 500
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  end
end
function L37_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L6_2 = DebugStart
  L7_2 = "PlayPedBetAnimation"
  L6_2(L7_2)
  L6_2 = nil
  L7_2 = nil
  if 1 == A4_2 then
    L8_2 = 5000
    if A3_2 < L8_2 then
      L8_2 = "bet_ante"
      if L8_2 then
        goto lbl_14
        L6_2 = L8_2 or L6_2
      end
    end
    L6_2 = "bet_ante_large"
    ::lbl_14::
    if 4 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.498025
      L10_2 = 0.199675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 3 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.168025
      L10_2 = 0.514675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 2 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.200975
      L10_2 = 0.499675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 1 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.511975
      L10_2 = 0.166675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    end
  elseif 2 == A4_2 then
    L8_2 = 5000
    if A3_2 < L8_2 then
      L8_2 = "bet_plus"
      if L8_2 then
        goto lbl_59
        L6_2 = L8_2 or L6_2
      end
    end
    L6_2 = "bet_plus_large"
    ::lbl_59::
    if 4 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.578025
      L10_2 = 0.234675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 3 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.193025
      L10_2 = 0.594675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 2 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.232975
      L10_2 = 0.579675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 1 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.591975
      L10_2 = 0.196675
      L11_2 = 0.95
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    end
  elseif 3 == A4_2 then
    L8_2 = 10000
    if A3_2 < L8_2 then
      L8_2 = "cards_bet"
      if L8_2 then
        goto lbl_104
        L6_2 = L8_2 or L6_2
      end
    end
    L6_2 = "cards_bet_large"
    ::lbl_104::
    if 4 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.413025
      L10_2 = 0.164675
      L11_2 = 0.955
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 3 == A2_2 then
      L8_2 = vector3
      L9_2 = 0.139025
      L10_2 = 0.419675
      L11_2 = 0.955
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 2 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.165975
      L10_2 = 0.414675
      L11_2 = 0.955
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    elseif 1 == A2_2 then
      L8_2 = vector3
      L9_2 = -0.418975
      L10_2 = 0.136675
      L11_2 = 0.955
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    end
  end
  L8_2 = A1_2.chairPositions
  L8_2 = L8_2[A2_2]
  L9_2 = GetObjectOffsetFromCoords
  L10_2 = L8_2.coords
  L11_2 = A1_2.heading
  L12_2 = L7_2
  L9_2 = L9_2(L10_2, L11_2, L12_2)
  L10_2 = CreateThread
  function L11_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L0_3 = A4_2
    if 3 == L0_3 then
      L0_3 = A1_2.syncedState
      L0_3 = L0_3.cardsInHands
      L1_3 = A2_2
      L0_3 = L0_3[L1_3]
      if true == L0_3 then
        L0_3 = A1_2.automated
        if not L0_3 then
          L0_3 = L36_1
          L1_3 = A0_2
          L2_3 = A1_2
          L3_3 = A2_2
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = Wait
          L1_3 = 1000
          L0_3(L1_3)
        end
      end
    end
    L0_3 = PokerGetChipModel
    L1_3 = A3_2
    L0_3, L1_3 = L0_3(L1_3)
    L2_3 = RequestModelAndWait
    L3_3 = L0_3
    L2_3(L3_3)
    L2_3 = nil
    L3_3 = A5_2
    if L3_3 then
      L3_3 = GetInitialAnimOffsets
      L4_3 = L3_1
      L5_3 = L6_2
      L6_3 = L8_2.coords
      L7_3 = L8_2.rotation
      L3_3, L4_3 = L3_3(L4_3, L5_3, L6_3, L7_3)
      L5_3 = IsPedMale
      L6_3 = A0_2
      L5_3 = L5_3(L6_3)
      if L5_3 then
        L5_3 = 0.0
        if L5_3 then
          goto lbl_46
        end
      end
      L5_3 = 0.07
      ::lbl_46::
      L6_3 = vector3
      L7_3 = L3_3.x
      L8_3 = L3_3.y
      L9_3 = L3_3.z
      L9_3 = L9_3 + L5_3
      L6_3 = L6_3(L7_3, L8_3, L9_3)
      L3_3 = L6_3
      L6_3 = TaskPlayAnimAdvanced
      L7_3 = A0_2
      L8_3 = L3_1
      L9_3 = L6_2
      L10_3 = L3_3
      L11_3 = L4_3
      L12_3 = 3.0
      L13_3 = 3.0
      L14_3 = -1
      L15_3 = 2
      L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L6_3 = WaitTaskAnimToReachTime
      L7_3 = A0_2
      L8_3 = L3_1
      L9_3 = L6_2
      L10_3 = 0.2
      L11_3 = 2000
      L12_3 = 100
      L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
    else
      L3_3 = PlaySynchronizedSceneOnPed
      L4_3 = A0_2
      L5_3 = L8_2.coords
      L6_3 = L8_2.rotation
      L7_3 = L3_1
      L8_3 = L6_2
      L9_3 = false
      L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
      L2_3 = L3_3
      L3_3 = WaitSynchronizedSceneToReachTime
      L4_3 = L2_3
      L5_3 = 0.2
      L6_3 = 2000
      L7_3 = 100
      L3_3(L4_3, L5_3, L6_3, L7_3)
    end
    L3_3 = IN_CASINO
    if not L3_3 then
      return
    end
    if 0 ~= L1_3 then
      L3_3 = math
      L3_3 = L3_3.floor
      L4_3 = A3_2
      L4_3 = L4_3 / L1_3
      L3_3 = L3_3(L4_3)
      L4_3 = A3_2
      L5_3 = 5000
      if L4_3 < L5_3 then
        L4_3 = L9_2
        L5_3 = vector3
        L6_3 = 0.0
        L7_3 = 0.0
        L8_3 = 0.061
        L5_3 = L5_3(L6_3, L7_3, L8_3)
        L4_3 = L4_3 - L5_3
        L9_2 = L4_3
        L4_3 = L9_2
        L5_3 = vector3
        L6_3 = 0.0
        L7_3 = 0.0
        L8_3 = L3_3 * 0.005
        L5_3 = L5_3(L6_3, L7_3, L8_3)
        L4_3 = L4_3 + L5_3
        L9_2 = L4_3
      else
        L4_3 = L9_2
        L5_3 = vector3
        L6_3 = 0.0
        L7_3 = 0.0
        L8_3 = 0.0645
        L5_3 = L5_3(L6_3, L7_3, L8_3)
        L4_3 = L4_3 - L5_3
        L9_2 = L4_3
        L4_3 = L3_3 * 0.0065
        if -1204079456 == L0_3 then
          L5_3 = 0.13
          if L4_3 >= L5_3 then
            L4_3 = 0.058
          end
        end
        L5_3 = L9_2
        L6_3 = vector3
        L7_3 = 0.0
        L8_3 = 0.0
        L9_3 = L4_3
        L6_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3 + L6_3
        L9_2 = L5_3
      end
    end
    L3_3 = CreateObjectNoOffset
    L4_3 = L0_3
    L5_3 = L9_2
    L6_3 = false
    L7_3 = false
    L8_3 = false
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    L4_3 = table
    L4_3 = L4_3.insert
    L5_3 = A1_2.chairChips
    L6_3 = A2_2
    L5_3 = L5_3[L6_3]
    L6_3 = L3_3
    L4_3(L5_3, L6_3)
    L4_3 = "DLC_VW_CHIP_BET_SML_SMALL"
    L5_3 = A3_2
    L6_3 = 10000
    if L5_3 >= L6_3 then
      L4_3 = "DLC_VW_CHIP_BET_SML_LARGE"
    else
      L5_3 = A3_2
      L6_3 = 5000
      if L5_3 >= L6_3 then
        L4_3 = "DLC_VW_CHIP_BET_SML_MEDIUM"
      end
    end
    L5_3 = PlaySound
    L6_3 = L4_3
    L7_3 = "dlc_vw_table_games_sounds"
    L8_3 = L3_3
    L9_3 = false
    L5_3(L6_3, L7_3, L8_3, L9_3)
    L5_3 = SetEntityCoordsNoOffset
    L6_3 = L3_3
    L7_3 = L9_2
    L8_3 = false
    L9_3 = false
    L10_3 = true
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    L5_3 = SetEntityHeading
    L6_3 = L3_3
    L7_3 = GetEntityHeading
    L8_3 = A0_2
    L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3 = L7_3(L8_3)
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    L5_3 = FreezeEntityPosition
    L6_3 = L3_3
    L7_3 = true
    L5_3(L6_3, L7_3)
    L5_3 = A0_2
    L6_3 = PlayerPedId
    L6_3 = L6_3()
    if L5_3 == L6_3 then
      if not L2_3 or -1 == L2_3 then
        L5_3 = WaitTaskAnimToReachTime
        L6_3 = A0_2
        L7_3 = L3_1
        L8_3 = L6_2
        L9_3 = 0.8
        L10_3 = 2000
        L11_3 = 100
        L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      else
        L5_3 = WaitSynchronizedSceneToReachTime
        L6_3 = L2_3
        L7_3 = 0.8
        L8_3 = 2000
        L9_3 = 100
        L5_3(L6_3, L7_3, L8_3, L9_3)
      end
      L5_3 = IN_CASINO
      if not L5_3 then
        return
      end
      L5_3 = L34_1
      L5_3()
    end
    L5_3 = A5_2
    if L5_3 then
      L5_3 = WaitTaskAnimToReachTime
      L6_3 = A0_2
      L7_3 = L3_1
      L8_3 = L6_2
      L9_3 = 0.8
      L10_3 = 2000
      L11_3 = 100
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      L5_3 = A1_2
      if L5_3 then
        L5_3 = A1_2.automateMakeIdle
        if L5_3 then
          goto lbl_248
        end
      end
      do return end
      ::lbl_248::
      L5_3 = A1_2.automateMakeIdle
      L6_3 = A2_2
      L5_3(L6_3)
    end
  end
  L12_2 = "play *bet* animation on ped"
  L10_2(L11_2, L12_2)
end
function L38_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "HideTimeBars"
  L0_2(L1_2)
  L0_2 = L30_1
  if nil ~= L0_2 then
    L30_1.visible = false
  end
  L0_2 = L27_1
  if nil ~= L0_2 then
    L27_1.visible = false
  end
  L0_2 = L28_1
  if nil ~= L0_2 then
    L28_1.visible = false
  end
  L0_2 = L29_1
  if nil ~= L0_2 then
    L29_1.visible = false
  end
  L0_2 = L26_1
  if nil ~= L0_2 then
    L26_1.visible = false
  end
end
function L39_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = DebugStart
  L1_2 = "CreateActualBettingBar"
  L0_2(L1_2)
  L0_2 = Translation
  L0_2 = L0_2.Get
  L1_2 = "POKER_BET_DEFAULT"
  L0_2 = L0_2(L1_2)
  L1_2 = L11_1
  if 1 == L1_2 then
    L1_2 = Translation
    L1_2 = L1_2.Get
    L2_2 = "POKER_ANTE_BET"
    L1_2 = L1_2(L2_2)
    L0_2 = L1_2
  else
    L1_2 = L11_1
    if 2 == L1_2 then
      L1_2 = Translation
      L1_2 = L1_2.Get
      L2_2 = "POKER_PAIR_PLUS_BET"
      L1_2 = L1_2(L2_2)
      L0_2 = L1_2
    else
      L1_2 = L11_1
      if 4 == L1_2 then
        L1_2 = Translation
        L1_2 = L1_2.Get
        L2_2 = "POKER_PLAY_WAGER"
        L1_2 = L1_2(L2_2)
        L0_2 = L1_2
      end
    end
  end
  L1_2 = L30_1
  if nil ~= L1_2 then
    L30_1.visible = true
    L1_2 = L30_1.setTitle
    L2_2 = L0_2
    L1_2(L2_2)
    L1_2 = L30_1.setText
    L2_2 = CommaValue
    L3_2 = L13_1
    L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  else
    L1_2 = TimerBar
    L1_2 = L1_2.Create
    L2_2 = TimerBar
    L2_2 = L2_2.Text
    L3_2 = L0_2
    L4_2 = CommaValue
    L5_2 = L13_1
    L4_2, L5_2, L6_2 = L4_2(L5_2)
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    L30_1 = L1_2
    L1_2 = L30_1.setTextColor
    L2_2 = {}
    L3_2 = 238
    L4_2 = 232
    L5_2 = 170
    L6_2 = 255
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L1_2(L2_2)
    L1_2 = L30_1.setTitleColor
    L2_2 = {}
    L3_2 = 238
    L4_2 = 232
    L5_2 = 170
    L6_2 = 255
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L1_2(L2_2)
  end
end
function L40_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = DebugStart
  L2_2 = "CreateAnteBar"
  L1_2(L2_2)
  L1_2 = L28_1
  if nil ~= L1_2 then
    L28_1.visible = true
    L1_2 = L28_1.setText
    L2_2 = CommaValue
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  else
    L1_2 = TimerBar
    L1_2 = L1_2.Create
    L2_2 = TimerBar
    L2_2 = L2_2.Text
    L3_2 = Translation
    L3_2 = L3_2.Get
    L4_2 = "POKER_ANTE_BET"
    L3_2 = L3_2(L4_2)
    L4_2 = CommaValue
    L5_2 = A0_2
    L4_2, L5_2, L6_2 = L4_2(L5_2)
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    L28_1 = L1_2
    L1_2 = L28_1.setTextColor
    L2_2 = {}
    L3_2 = 255
    L4_2 = 255
    L5_2 = 255
    L6_2 = 255
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L1_2(L2_2)
  end
end
function L41_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = DebugStart
  L2_2 = "CreatePairPlusBar"
  L1_2(L2_2)
  L1_2 = L29_1
  if nil ~= L1_2 then
    L29_1.visible = true
    L1_2 = L29_1.setText
    L2_2 = CommaValue
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  else
    L1_2 = TimerBar
    L1_2 = L1_2.Create
    L2_2 = TimerBar
    L2_2 = L2_2.Text
    L3_2 = Translation
    L3_2 = L3_2.Get
    L4_2 = "POKER_PAIR_PLUS_BET"
    L3_2 = L3_2(L4_2)
    L4_2 = CommaValue
    L5_2 = A0_2
    L4_2, L5_2, L6_2 = L4_2(L5_2)
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    L29_1 = L1_2
    L1_2 = L29_1.setTextColor
    L2_2 = {}
    L3_2 = 255
    L4_2 = 255
    L5_2 = 255
    L6_2 = 255
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L1_2(L2_2)
  end
end
function L42_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = DebugStart
  L1_2 = "CreateWaitingPlayersBar"
  L0_2(L1_2)
  L0_2 = L26_1
  if nil ~= L0_2 then
    L26_1.visible = true
  else
    L0_2 = TimerBar
    L0_2 = L0_2.Create
    L1_2 = TimerBar
    L1_2 = L1_2.Checkpoint
    L2_2 = Translation
    L2_2 = L2_2.Get
    L3_2 = "UI_WAITING_FOR_EVERYONE"
    L2_2 = L2_2(L3_2)
    L3_2 = 4
    L0_2 = L0_2(L1_2, L2_2, L3_2)
    L26_1 = L0_2
  end
  L0_2 = L5_1
  if nil ~= L0_2 then
    L0_2 = L5_1.syncedState
    if nil ~= L0_2 then
      L0_2 = 0
      L1_2 = 1
      L2_2 = 4
      L3_2 = 1
      for L4_2 = L1_2, L2_2, L3_2 do
        L5_2 = L5_1.syncedState
        L5_2 = L5_2.chairs
        L5_2 = L5_2[L4_2]
        if nil ~= L5_2 and -1 ~= L5_2 then
          L0_2 = L0_2 + 1
        end
      end
      L1_2 = L26_1.changeNumCheckpoints
      L2_2 = L0_2
      L1_2(L2_2)
    end
  end
end
function L43_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = DebugStart
  L2_2 = "TimerBarChairReady"
  L1_2(L2_2)
  L1_2 = L26_1
  if nil ~= L1_2 then
    L1_2 = L20_1
    if nil ~= L1_2 then
      goto lbl_11
    end
  end
  do return end
  ::lbl_11::
  L1_2 = L20_1
  L1_2 = L1_2[A0_2]
  if nil ~= L1_2 then
    return
  end
  L1_2 = L20_1
  L1_2[A0_2] = true
  L1_2 = 1
  L2_2 = 1
  L3_2 = 4
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L20_1
    L6_2 = L6_2[L5_2]
    if true == L6_2 then
      L6_2 = L26_1.setCheckpointState
      L7_2 = L1_2
      L8_2 = true
      L6_2(L7_2, L8_2)
      L1_2 = L1_2 + 1
    end
  end
end
function L44_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "TimerBarResetChairsReady"
  L0_2(L1_2)
  L0_2 = {}
  L20_1 = L0_2
  L0_2 = L26_1
  if nil ~= L0_2 then
    L0_2 = L26_1.uncheckAll
    L0_2()
  end
end
function L45_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = DebugStart
  L1_2 = "CreateTimeleftBar"
  L0_2(L1_2)
  L0_2 = L27_1
  if nil ~= L0_2 then
    L27_1.visible = true
  else
    L0_2 = TimerBar
    L0_2 = L0_2.Create
    L1_2 = TimerBar
    L1_2 = L1_2.Text
    L2_2 = Translation
    L2_2 = L2_2.Get
    L3_2 = "ROULETTE_TIMERBAR_TIME"
    L2_2 = L2_2(L3_2)
    L3_2 = "0"
    L0_2 = L0_2(L1_2, L2_2, L3_2)
    L27_1 = L0_2
    L0_2 = L27_1.setTextColor
    L1_2 = {}
    L2_2 = 255
    L3_2 = 20
    L4_2 = 20
    L5_2 = 255
    L1_2[1] = L2_2
    L1_2[2] = L3_2
    L1_2[3] = L4_2
    L1_2[4] = L5_2
    L0_2(L1_2)
    L0_2 = L27_1.setHighlightColor
    L1_2 = {}
    L2_2 = 255
    L3_2 = 20
    L4_2 = 20
    L5_2 = 255
    L1_2[1] = L2_2
    L1_2[2] = L3_2
    L1_2[3] = L4_2
    L1_2[4] = L5_2
    L0_2(L1_2)
  end
  L0_2 = L5_1
  if nil ~= L0_2 then
    L0_2 = L5_1.syncedState
    if nil ~= L0_2 then
      L0_2 = L5_1.syncedState
      L0_2 = L0_2.timeleft
      if nil ~= L0_2 then
        L0_2 = L27_1.setText
        L1_2 = "00:"
        L2_2 = string
        L2_2 = L2_2.format
        L3_2 = "%02d"
        L4_2 = L5_1.syncedState
        L4_2 = L4_2.timeleft
        L2_2 = L2_2(L3_2, L4_2)
        L1_2 = L1_2 .. L2_2
        L0_2(L1_2)
      end
    end
  end
end
function L46_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = DebugStart
  L1_2 = "GetActualMinMaxBetValue"
  L0_2(L1_2)
  L0_2 = 0
  L1_2 = 0
  L2_2 = L5_1
  if nil ~= L2_2 then
    L2_2 = L11_1
    if 1 == L2_2 then
      L0_2 = L9_1.MinBetValueAntePlay
      L1_2 = L9_1.MaxBetValueAntePlay
    else
      L2_2 = L11_1
      if 2 == L2_2 then
        L0_2 = L9_1.MinBetValuePairPlus
        L1_2 = L9_1.MaxBetValuePairPlus
      else
        L2_2 = L11_1
        if 4 == L2_2 then
          L2_2 = L25_1
          if nil ~= L2_2 then
            L2_2 = L25_1.ante
            if nil ~= L2_2 then
              L0_2 = L25_1.ante
              L1_2 = L25_1.ante
            end
          end
        end
      end
    end
  end
  L2_2 = L0_2
  L3_2 = L1_2
  return L2_2, L3_2
end
function L47_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = DebugStart
  L1_2 = "RedrawInstructionalButtons"
  L0_2(L1_2)
  L0_2 = CAN_INTERACT
  if L0_2 then
    L0_2 = L10_1
    if L0_2 then
      goto lbl_14
    end
  end
  L0_2 = PushNUIInstructionalButtons
  L1_2 = nil
  L0_2(L1_2)
  do return end
  ::lbl_14::
  L0_2 = {}
  L1_2 = L12_1
  if L1_2 > 0 then
    L1_2 = table
    L1_2 = L1_2.insert
    L2_2 = L0_2
    L3_2 = {}
    L3_2.key = 202
    L4_2 = Translation
    L4_2 = L4_2.Get
    L5_2 = "ROULETTE_BTN_CLOSE_RULES"
    L4_2 = L4_2(L5_2)
    L3_2.title = L4_2
    L1_2(L2_2, L3_2)
    L1_2 = table
    L1_2 = L1_2.insert
    L2_2 = L0_2
    L3_2 = {}
    L3_2.key = 190
    L4_2 = Translation
    L4_2 = L4_2.Get
    L5_2 = "BTN_PREV_PAGE"
    L4_2 = L4_2(L5_2)
    L3_2.title = L4_2
    L1_2(L2_2, L3_2)
    L1_2 = table
    L1_2 = L1_2.insert
    L2_2 = L0_2
    L3_2 = {}
    L3_2.key = 189
    L4_2 = Translation
    L4_2 = L4_2.Get
    L5_2 = "BTN_NEXT_PAGE"
    L4_2 = L4_2(L5_2)
    L3_2.title = L4_2
    L1_2(L2_2, L3_2)
  else
    L1_2 = table
    L1_2 = L1_2.insert
    L2_2 = L0_2
    L3_2 = {}
    L3_2.key = 202
    L4_2 = Translation
    L4_2 = L4_2.Get
    L5_2 = "BTN_QUIT"
    L4_2 = L4_2(L5_2)
    L3_2.title = L4_2
    L1_2(L2_2, L3_2)
    L1_2 = L17_1
    if L1_2 then
      L1_2 = L11_1
      if 1 ~= L1_2 then
        L1_2 = L11_1
        if 2 ~= L1_2 then
          goto lbl_185
        end
      end
      L1_2 = L11_1
      if 1 == L1_2 then
        L1_2 = L15_1
        if 1 ~= L1_2 then
          L1_2 = L25_1.ante
          if nil == L1_2 then
            L1_2 = table
            L1_2 = L1_2.insert
            L2_2 = L0_2
            L3_2 = {}
            L3_2.key = 201
            L4_2 = Translation
            L4_2 = L4_2.Get
            L5_2 = "POKER_CONFIRM_ANTE"
            L4_2 = L4_2(L5_2)
            L3_2.title = L4_2
            L1_2(L2_2, L3_2)
            L1_2 = table
            L1_2 = L1_2.insert
            L2_2 = L0_2
            L3_2 = {}
            L3_2.key = 203
            L4_2 = Translation
            L4_2 = L4_2.Get
            L5_2 = "POKER_SKIP_ANTE"
            L4_2 = L4_2(L5_2)
            L3_2.title = L4_2
            L1_2(L2_2, L3_2)
        end
      end
      else
        L1_2 = L11_1
        if 2 == L1_2 then
          L1_2 = L15_1
          if 2 ~= L1_2 then
            L1_2 = L25_1.pairPlus
            if nil == L1_2 then
              L1_2 = table
              L1_2 = L1_2.insert
              L2_2 = L0_2
              L3_2 = {}
              L3_2.key = 201
              L4_2 = Translation
              L4_2 = L4_2.Get
              L5_2 = "POKER_CONFIRM_PAIRPLUS"
              L4_2 = L4_2(L5_2)
              L3_2.title = L4_2
              L1_2(L2_2, L3_2)
              L1_2 = table
              L1_2 = L1_2.insert
              L2_2 = L0_2
              L3_2 = {}
              L3_2.key = 203
              L4_2 = Translation
              L4_2 = L4_2.Get
              L5_2 = "POKER_SKIP_PAIRPLUS"
              L4_2 = L4_2(L5_2)
              L3_2.title = L4_2
              L1_2(L2_2, L3_2)
            end
          end
        end
      end
      L1_2 = L11_1
      L2_2 = L15_1
      if L1_2 ~= L2_2 then
        L1_2 = table
        L1_2 = L1_2.insert
        L2_2 = L0_2
        L3_2 = {}
        L4_2 = GameplayKeys
        L4_2 = L4_2.TableGamesMaxBet
        L3_2.key = L4_2
        L4_2 = L13_1
        L5_2 = L19_1
        if L4_2 >= L5_2 then
          L4_2 = Translation
          L4_2 = L4_2.Get
          L5_2 = "ROULETTE_BTN_MIN_BET"
          L4_2 = L4_2(L5_2)
          if L4_2 then
            goto lbl_170
          end
        end
        L4_2 = Translation
        L4_2 = L4_2.Get
        L5_2 = "ROULETTE_BTN_MAX_BET"
        L4_2 = L4_2(L5_2)
        ::lbl_170::
        L3_2.title = L4_2
        L1_2(L2_2, L3_2)
        L1_2 = table
        L1_2 = L1_2.insert
        L2_2 = L0_2
        L3_2 = {}
        L3_2.key = 187
        L4_2 = Translation
        L4_2 = L4_2.Get
        L5_2 = "ROULETTE_BTN_ADJUST_BET"
        L4_2 = L4_2(L5_2)
        L3_2.title = L4_2
        L3_2.extraKey = 188
        L1_2(L2_2, L3_2)
      end
      ::lbl_185::
      L1_2 = L11_1
      if 4 == L1_2 then
        L1_2 = L25_1.ante
        if nil ~= L1_2 then
          L1_2 = L25_1.ante
          if L1_2 > 0 then
            L1_2 = L25_1.isPlaying
            if nil == L1_2 then
              L1_2 = table
              L1_2 = L1_2.insert
              L2_2 = L0_2
              L3_2 = {}
              L3_2.key = 201
              L4_2 = Translation
              L4_2 = L4_2.Get
              L5_2 = "BTN_FOLD_PLAY"
              L4_2 = L4_2(L5_2)
              L3_2.title = L4_2
              L1_2(L2_2, L3_2)
              L1_2 = table
              L1_2 = L1_2.insert
              L2_2 = L0_2
              L3_2 = {}
              L3_2.key = 203
              L4_2 = Translation
              L4_2 = L4_2.Get
              L5_2 = "BTN_FOLD"
              L4_2 = L4_2(L5_2)
              L3_2.title = L4_2
              L1_2(L2_2, L3_2)
              L1_2 = L16_1
              if not L1_2 then
                L1_2 = table
                L1_2 = L1_2.insert
                L2_2 = L0_2
                L3_2 = {}
                L4_2 = GameplayKeys
                L4_2 = L4_2.TableGamesGrabCards
                L3_2.key = L4_2
                L4_2 = Translation
                L4_2 = L4_2.Get
                L5_2 = "POKER_GRAB_CARDS"
                L4_2 = L4_2(L5_2)
                L3_2.title = L4_2
                L1_2(L2_2, L3_2)
              end
            end
          end
        end
      end
      L1_2 = L11_1
      if 5 ~= L1_2 then
        L1_2 = L11_1
        if 6 ~= L1_2 then
          goto lbl_258
        end
      end
      L1_2 = table
      L1_2 = L1_2.insert
      L2_2 = L0_2
      L3_2 = {}
      L4_2 = GameplayKeys
      L4_2 = L4_2.TableGamesGrabCards
      L3_2.key = L4_2
      L4_2 = Translation
      L4_2 = L4_2.Get
      L5_2 = "BTN_CAMERA"
      L4_2 = L4_2(L5_2)
      L3_2.title = L4_2
      L1_2(L2_2, L3_2)
    end
    ::lbl_258::
    L1_2 = table
    L1_2 = L1_2.insert
    L2_2 = L0_2
    L3_2 = {}
    L3_2.key = 210
    L4_2 = Translation
    L4_2 = L4_2.Get
    L5_2 = "BTN_RULES"
    L4_2 = L4_2(L5_2)
    L3_2.title = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = PushNUIInstructionalButtons
  L2_2 = L0_2
  L1_2(L2_2)
end
function L48_1()
  local L0_2, L1_2, L2_2
  L0_2 = DebugStart
  L1_2 = "TempHideInstructionalButtons"
  L0_2(L1_2)
  L0_2 = PushNUIInstructionalButtons
  L1_2 = nil
  L0_2(L1_2)
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3
    while true do
      L0_3 = CAN_INTERACT
      if L0_3 then
        break
      end
      L0_3 = IN_CASINO
      if not L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 33
      L0_3(L1_3)
    end
    L0_3 = L47_1
    L0_3()
  end
  L2_2 = "hide instructional buttons until player can interact again"
  L0_2(L1_2, L2_2)
end
function L49_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = DebugStart
  L4_2 = "ShowWinnersUI"
  L3_2(L4_2)
  L3_2 = InfoPanel_UpdateNotification
  L4_2 = nil
  L3_2(L4_2)
  L3_2 = RageUI
  L3_2 = L3_2.CreateMenu
  L4_2 = ""
  L5_2 = "custom"
  L6_2 = 25
  L7_2 = 25
  L8_2 = "casinoui_winners"
  L9_2 = "casinoui_winners"
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L3_2.NoHud = true
  L4_2 = L3_2.Display
  L4_2.Header = false
  L4_2 = L3_2.Display
  L4_2.InstructionalButton = false
  L4_2 = L3_2.Display
  L4_2.Subtitle = false
  function L4_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3
    L3_3 = pairs
    L4_3 = A1_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L10_3 = A0_3
      L9_3 = A0_3.AddWinnerLoser
      L11_3 = L8_3.name
      L12_3 = L8_3.score
      L13_3 = L8_3.txd
      L14_3 = nil
      L15_3 = {}
      L15_3.IsDisabled = false
      L16_3 = L8_3.score
      L15_3.RightLabel = L16_3
      L15_3.RightLabelColor = A2_3
      L16_3 = RageUI
      L16_3 = L16_3.ItemsColour
      L16_3 = L16_3.White
      L15_3.TextLabelColor = L16_3
      L16_3 = {}
      L17_3 = {}
      L18_3 = 0
      L19_3 = 0
      L20_3 = 0
      L21_3 = 100
      L17_3[1] = L18_3
      L17_3[2] = L19_3
      L17_3[3] = L20_3
      L17_3[4] = L21_3
      L16_3.BackgroundColor = L17_3
      L15_3.Color = L16_3
      L16_3 = nil
      function L17_3()
        local L0_4, L1_4
      end
      L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
    end
  end
  DrawPlayers = L4_2
  L4_2 = RageUI
  L4_2 = L4_2.PoolMenus
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = L3_2
    L2_3 = L1_3
    L1_3 = L1_3.IsVisible
    function L3_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
      L1_4 = A0_2
      L1_4 = #L1_4
      L2_4 = A1_2
      L2_4 = #L2_4
      L1_4 = L1_4 + L2_4
      if 0 == L1_4 then
        L2_4 = A0_4
        L1_4 = A0_4.AddEmpty
        L1_4(L2_4)
      end
      L1_4 = A0_2
      L1_4 = #L1_4
      if L1_4 > 0 then
        L2_4 = A0_4
        L1_4 = A0_4.AddExtraSubtitle
        L3_4 = Translation
        L3_4 = L3_4.Get
        L4_4 = "WINNERS"
        L3_4 = L3_4(L4_4)
        L4_4 = A0_2
        L4_4 = #L4_4
        L5_4 = 0
        L6_4 = 181
        L7_4 = 0
        L8_4 = 50
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4)
        L1_4 = DrawPlayers
        L2_4 = A0_4
        L3_4 = A0_2
        L4_4 = RageUI
        L4_4 = L4_4.ItemsColour
        L4_4 = L4_4.GreenLight
        L1_4(L2_4, L3_4, L4_4)
      end
      L1_4 = A1_2
      L1_4 = #L1_4
      if L1_4 > 0 then
        L2_4 = A0_4
        L1_4 = A0_4.AddExtraSubtitle
        L3_4 = Translation
        L3_4 = L3_4.Get
        L4_4 = "LOSERS"
        L3_4 = L3_4(L4_4)
        L4_4 = A1_2
        L4_4 = #L4_4
        L5_4 = 181
        L6_4 = 0
        L7_4 = 0
        L8_4 = 50
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4)
        L1_4 = DrawPlayers
        L2_4 = A0_4
        L3_4 = A1_2
        L4_4 = RageUI
        L4_4 = L4_4.ItemsColour
        L4_4 = L4_4.RedLight
        L1_4(L2_4, L3_4, L4_4)
      end
      L1_4 = A2_2
      if L1_4 then
        L2_4 = A0_4
        L1_4 = A0_4.AddText
        L3_4 = A2_2
        L4_4 = "\n"
        L3_4 = L3_4 .. L4_4
        L4_4 = 5
        L1_4(L2_4, L3_4, L4_4)
      end
    end
    function L4_3(A0_4)
      local L1_4
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L4_2.WinnersUI = L5_2
  L4_2 = RageUI
  L4_2 = L4_2.Visible
  L5_2 = L3_2
  L6_2 = true
  L4_2(L5_2, L6_2)
end
function L50_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2
  L1_2 = DebugStart
  L2_2 = "ShowRulesUI"
  L1_2(L2_2)
  L1_2 = CloseAllMenus
  L1_2()
  L1_2 = {}
  L2_2 = ""
  L3_2 = nil
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L12_1 = A0_2
  L2_2 = L12_1
  if 1 == L2_2 then
    L2_2 = Translation
    L2_2 = L2_2.Get
    L3_2 = "POKER_RULES_PART1"
    L2_2 = L2_2(L3_2)
    L1_2[1] = L2_2
    L1_2[2] = ""
  else
    L2_2 = L12_1
    if 2 == L2_2 then
      L2_2 = Translation
      L2_2 = L2_2.Get
      L3_2 = "POKER_RULES_PART2"
      L2_2 = L2_2(L3_2)
      L1_2[1] = L2_2
      L1_2[2] = ""
    else
      L2_2 = L12_1
      if 3 == L2_2 then
        L2_2 = Translation
        L2_2 = L2_2.Get
        L3_2 = "POKER_RULES_PART3"
        L2_2 = L2_2(L3_2)
        L1_2[1] = L2_2
        L2_2 = Translation
        L2_2 = L2_2.Get
        L3_2 = "POKER_RULES_PART3_2"
        L2_2 = L2_2(L3_2)
        L1_2[2] = L2_2
      else
        L2_2 = L12_1
        if 4 == L2_2 then
          L2_2 = Translation
          L2_2 = L2_2.Get
          L3_2 = "POKER_RULES_PART4"
          L2_2 = L2_2(L3_2)
          L1_2[1] = L2_2
          L1_2[2] = ""
        else
          L2_2 = L12_1
          if 5 == L2_2 then
            L2_2 = Translation
            L2_2 = L2_2.Get
            L3_2 = "POKER_RULES_PART5"
            L2_2 = L2_2(L3_2)
            L1_2[1] = L2_2
            L1_2[2] = ""
          else
            L2_2 = L12_1
            if 6 == L2_2 then
              L2_2 = Translation
              L2_2 = L2_2.Get
              L3_2 = "ROULETTE_RULES_BET_LIMITS"
              L2_2 = L2_2(L3_2)
              L3_2 = [[


]]
              L4_2 = Translation
              L4_2 = L4_2.Get
              L5_2 = "POKER_RULES_ANTE_AND_PLAY"
              L4_2 = L4_2(L5_2)
              L5_2 = [[
:
- ]]
              L6_2 = Translation
              L6_2 = L6_2.Get
              L7_2 = "ROULETTE_RULES_MINIMUM"
              L6_2 = L6_2(L7_2)
              L7_2 = ": "
              L8_2 = L9_1.MinBetValueAntePlay
              L9_2 = " "
              L10_2 = Translation
              L10_2 = L10_2.Get
              L11_2 = "ROULETTE_RULES_CHIPS"
              L10_2 = L10_2(L11_2)
              L11_2 = [[

- ]]
              L12_2 = Translation
              L12_2 = L12_2.Get
              L13_2 = "ROULETTE_NUMBERS_MAXIMUM"
              L12_2 = L12_2(L13_2)
              L13_2 = ": "
              L14_2 = L9_1.MaxBetValueAntePlay
              L15_2 = " "
              L16_2 = Translation
              L16_2 = L16_2.Get
              L17_2 = "ROULETTE_RULES_CHIPS"
              L16_2 = L16_2(L17_2)
              L17_2 = [[


]]
              L18_2 = Translation
              L18_2 = L18_2.Get
              L19_2 = "POKER_RULES_PAIR_PLUS"
              L18_2 = L18_2(L19_2)
              L19_2 = [[
:
- ]]
              L20_2 = Translation
              L20_2 = L20_2.Get
              L21_2 = "ROULETTE_RULES_MINIMUM"
              L20_2 = L20_2(L21_2)
              L21_2 = ": "
              L22_2 = L9_1.MinBetValuePairPlus
              L23_2 = " "
              L24_2 = Translation
              L24_2 = L24_2.Get
              L25_2 = "ROULETTE_RULES_CHIPS"
              L24_2 = L24_2(L25_2)
              L25_2 = [[

- ]]
              L26_2 = Translation
              L26_2 = L26_2.Get
              L27_2 = "ROULETTE_NUMBERS_MAXIMUM"
              L26_2 = L26_2(L27_2)
              L27_2 = ": "
              L28_2 = L9_1.MaxBetValuePairPlus
              L29_2 = " "
              L30_2 = Translation
              L30_2 = L30_2.Get
              L31_2 = "ROULETTE_RULES_CHIPS"
              L30_2 = L30_2(L31_2)
              L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2 .. L27_2 .. L28_2 .. L29_2 .. L30_2
              L1_2[1] = L2_2
            end
          end
        end
      end
    end
  end
  L2_2 = InfoPanel_Update
  L3_2 = L9_1.Banner
  L4_2 = L9_1.Banner
  L5_2 = Translation
  L5_2 = L5_2.Get
  L6_2 = "ROULETTE_RULES_TITLE"
  L5_2 = L5_2(L6_2)
  L6_2 = L1_2[1]
  L7_2 = L1_2[2]
  L8_2 = false
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L3_2 = L2_2.Display
  L3_2.PageCounter = true
  L3_2 = L2_2.Display
  L3_2.InstructionalButton = false
  L3_2 = L12_1
  L4_2 = " / 6"
  L3_2 = L3_2 .. L4_2
  L2_2.CustomCounter = L3_2
  L3_2 = L47_1
  L3_2()
end
function L51_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = DebugStart
  L1_2 = "HandleUIButtons"
  L0_2(L1_2)
  L0_2 = L5_1
  if nil ~= L0_2 then
    L0_2 = L10_1
    if L0_2 then
      goto lbl_11
    end
  end
  do return end
  ::lbl_11::
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 187
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 188
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 189
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 190
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 201
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 203
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = GameplayKeys
  L2_2 = L2_2.TableGamesGrabCards
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 208
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = 210
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableControlAction
  L1_2 = 0
  L2_2 = GameplayKeys
  L2_2 = L2_2.TableGamesMaxBet
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = DisableESCThisFrame
  L0_2()
  L0_2 = GAME_INFO_PANEL
  if nil ~= L0_2 then
    L0_2 = L12_1
    if 0 ~= L0_2 then
      L0_2 = IsDisabledControlJustPressed
      L1_2 = 0
      L2_2 = 189
      L0_2 = L0_2(L1_2, L2_2)
      if L0_2 then
        L0_2 = L12_1
        if L0_2 > 1 then
          L0_2 = L50_1
          L1_2 = L12_1
          L1_2 = L1_2 - 1
          L0_2(L1_2)
          L0_2 = PlaySound
          L1_2 = "DLC_VW_BET_UP"
          L2_2 = "dlc_vw_table_games_frontend_sounds"
          L0_2(L1_2, L2_2)
        end
      end
      L0_2 = IsDisabledControlJustPressed
      L1_2 = 0
      L2_2 = 190
      L0_2 = L0_2(L1_2, L2_2)
      if L0_2 then
        L0_2 = L12_1
        if L0_2 < 6 then
          L0_2 = L50_1
          L1_2 = L12_1
          L1_2 = L1_2 + 1
          L0_2(L1_2)
          L0_2 = PlaySound
          L1_2 = "DLC_VW_BET_UP"
          L2_2 = "dlc_vw_table_games_frontend_sounds"
          L0_2(L1_2, L2_2)
        end
      end
    end
    return
  end
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = 188
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = L11_1
    if 1 ~= L0_2 then
      L0_2 = L11_1
      if 2 ~= L0_2 then
        goto lbl_169
      end
    end
    L0_2 = L15_1
    L1_2 = L11_1
    if L0_2 ~= L1_2 then
      L0_2 = L46_1
      L0_2, L1_2 = L0_2()
      L2_2 = GetHigherBetStepOf
      L3_2 = L13_1
      L2_2 = L2_2(L3_2)
      L13_1 = L2_2
      L2_2 = math
      L2_2 = L2_2.round
      L3_2 = L13_1
      L3_2 = L3_2 / 5
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 5
      L13_1 = L2_2
      L2_2 = L13_1
      if L1_2 < L2_2 then
        L13_1 = L1_2
      end
      L2_2 = L13_1
      L3_2 = PLAYER_CHIPS
      if L2_2 > L3_2 then
        L2_2 = PLAYER_CHIPS
        L13_1 = L2_2
      end
      L2_2 = L30_1
      if nil ~= L2_2 then
        L2_2 = L30_1.setText
        L3_2 = CommaValue
        L4_2 = L13_1
        L3_2, L4_2 = L3_2(L4_2)
        L2_2(L3_2, L4_2)
      end
      L2_2 = L13_1
      if L2_2 == L1_2 then
        L2_2 = PlaySound
        L3_2 = "DLC_VW_ERROR_MAX"
        L4_2 = "dlc_vw_table_games_frontend_sounds"
        L2_2(L3_2, L4_2)
      else
        L2_2 = PlaySound
        L3_2 = "DLC_VW_BET_UP"
        L4_2 = "dlc_vw_table_games_frontend_sounds"
        L2_2(L3_2, L4_2)
      end
    end
  end
  ::lbl_169::
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = 187
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = L11_1
    if 1 ~= L0_2 then
      L0_2 = L11_1
      if 2 ~= L0_2 then
        goto lbl_228
      end
    end
    L0_2 = L15_1
    L1_2 = L11_1
    if L0_2 ~= L1_2 then
      L0_2 = L46_1
      L0_2, L1_2 = L0_2()
      L2_2 = GetLowerBetStepOf
      L3_2 = L13_1
      L2_2 = L2_2(L3_2)
      L13_1 = L2_2
      L2_2 = math
      L2_2 = L2_2.round
      L3_2 = L13_1
      L3_2 = L3_2 / 5
      L2_2 = L2_2(L3_2)
      L2_2 = L2_2 * 5
      L13_1 = L2_2
      L2_2 = L13_1
      if L0_2 > L2_2 then
        L13_1 = L0_2
      end
      L2_2 = L13_1
      if L2_2 < 0 then
        L13_1 = L0_2
      end
      L2_2 = L30_1
      if nil ~= L2_2 then
        L2_2 = L30_1.setText
        L3_2 = CommaValue
        L4_2 = L13_1
        L3_2, L4_2 = L3_2(L4_2)
        L2_2(L3_2, L4_2)
      end
      L2_2 = L13_1
      if L2_2 == L0_2 then
        L2_2 = PlaySound
        L3_2 = "DLC_VW_ERROR_MAX"
        L4_2 = "dlc_vw_table_games_frontend_sounds"
        L2_2(L3_2, L4_2)
      else
        L2_2 = PlaySound
        L3_2 = "DLC_VW_BET_UP"
        L4_2 = "dlc_vw_table_games_frontend_sounds"
        L2_2(L3_2, L4_2)
      end
    end
  end
  ::lbl_228::
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = 203
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = CAN_INTERACT
    if L0_2 then
      L0_2 = L11_1
      if 1 == L0_2 then
        L0_2 = L15_1
        if 1 ~= L0_2 then
          L0_2 = BlockPlayerInteraction
          L1_2 = 500
          L0_2(L1_2)
          L0_2 = TriggerServerEvent
          L1_2 = "Poker:SkipAnte"
          L0_2(L1_2)
      end
      else
        L0_2 = L11_1
        if 2 == L0_2 then
          L0_2 = L15_1
          if 2 ~= L0_2 then
            L0_2 = BlockPlayerInteraction
            L1_2 = 500
            L0_2(L1_2)
            L0_2 = TriggerServerEvent
            L1_2 = "Poker:SkipPairPlus"
            L0_2(L1_2)
        end
        else
          L0_2 = L11_1
          if 4 == L0_2 then
            L0_2 = L15_1
            if 4 ~= L0_2 then
              L0_2 = L25_1.isPlaying
              if nil == L0_2 then
                L0_2 = L25_1.ante
                if nil ~= L0_2 then
                  L0_2 = L25_1.ante
                  if L0_2 > 0 then
                    L0_2 = BlockPlayerInteraction
                    L1_2 = 500
                    L0_2(L1_2)
                    L0_2 = TriggerServerEvent
                    L1_2 = "Poker:SkipPlay"
                    L0_2(L1_2)
                  end
                end
              end
            end
          end
        end
      end
      L0_2 = L48_1
      L0_2()
    end
  end
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = 201
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = CAN_INTERACT
    if L0_2 then
      L0_2 = L11_1
      if 1 ~= L0_2 then
        L0_2 = L11_1
        if 2 ~= L0_2 then
          goto lbl_347
        end
      end
      L0_2 = L15_1
      L1_2 = L11_1
      if L0_2 ~= L1_2 then
        L0_2 = L46_1
        L0_2, L1_2 = L0_2()
        L2_2 = L13_1
        if L0_2 > L2_2 then
          return
        end
        L2_2 = L13_1
        if L1_2 < L2_2 then
          return
        end
        L2_2 = L13_1
        L3_2 = PLAYER_CHIPS
        if L2_2 > L3_2 then
          return
        end
        L2_2 = BlockPlayerInteraction
        L3_2 = 500
        L2_2(L3_2)
        L2_2 = L11_1
        if 1 == L2_2 then
          L2_2 = L13_1
          L21_1 = L2_2
          L2_2 = TriggerServerEvent
          L3_2 = "Poker:ConfirmAnte"
          L4_2 = L13_1
          L2_2(L3_2, L4_2)
          L2_2 = Stats_Increase
          L3_2 = "rcore_casino_poker_games_played"
          L4_2 = 1
          L2_2(L3_2, L4_2)
        else
          L2_2 = L11_1
          if 2 == L2_2 then
            L2_2 = L13_1
            L22_1 = L2_2
            L2_2 = TriggerServerEvent
            L3_2 = "Poker:ConfirmPairPlus"
            L4_2 = L13_1
            L2_2(L3_2, L4_2)
          end
        end
      ::lbl_347::
      else
        L0_2 = L11_1
        if 4 == L0_2 then
          L0_2 = L25_1
          if nil ~= L0_2 then
            L0_2 = L25_1.ante
            if nil ~= L0_2 then
              L0_2 = L25_1.ante
              if not (L0_2 <= 0) then
                L0_2 = L15_1
                if 4 ~= L0_2 then
                  goto lbl_363
                end
              end
            end
          end
          do return end
          ::lbl_363::
          L0_2 = true
          L16_1 = L0_2
          L0_2 = BlockPlayerInteraction
          L1_2 = 500
          L0_2(L1_2)
          L0_2 = TriggerServerEvent
          L1_2 = "Poker:ConfirmPlay"
          L0_2(L1_2)
        end
      end
      L0_2 = L48_1
      L0_2()
    end
  end
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = GameplayKeys
  L2_2 = L2_2.TableGamesGrabCards
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = L11_1
    if 4 == L0_2 then
      L0_2 = L16_1
      if not L0_2 then
        L0_2 = L25_1.ante
        if nil ~= L0_2 then
          L0_2 = L25_1.ante
          if L0_2 > 0 then
            L0_2 = L25_1.isPlaying
            if nil == L0_2 then
              L0_2 = true
              L16_1 = L0_2
              L0_2 = BlockPlayerInteraction
              L1_2 = 500
              L0_2(L1_2)
              L0_2 = TriggerServerEvent
              L1_2 = "Poker:GrabCards"
              L0_2(L1_2)
          end
        end
      end
    end
    else
      L0_2 = L11_1
      if 5 ~= L0_2 then
        L0_2 = L11_1
        if 6 ~= L0_2 then
          goto lbl_418
        end
      end
      L0_2 = L5_1.cameraActive
      if L0_2 then
        L0_2 = L5_1.disableCamera
        L0_2()
      else
        L0_2 = L5_1.enableCamera
        L0_2()
      end
    end
    ::lbl_418::
    L0_2 = L47_1
    L0_2()
  end
  L0_2 = IsDisabledControlJustPressed
  L1_2 = 0
  L2_2 = GameplayKeys
  L2_2 = L2_2.TableGamesMaxBet
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L0_2 = L12_1
    if 0 == L0_2 then
      L0_2 = L11_1
      if 1 ~= L0_2 then
        L0_2 = L11_1
        if 2 ~= L0_2 then
          goto lbl_466
        end
      end
      L0_2 = L15_1
      L1_2 = L11_1
      if L0_2 ~= L1_2 then
        L0_2 = L46_1
        L0_2, L1_2 = L0_2()
        L2_2 = PLAYER_CHIPS
        if L1_2 > L2_2 then
          L1_2 = PLAYER_CHIPS
        end
        L2_2 = L13_1
        if L2_2 ~= L1_2 then
          L13_1 = L1_2
        else
          L13_1 = L0_2
        end
        L2_2 = L30_1
        if nil ~= L2_2 then
          L2_2 = L30_1.setText
          L3_2 = CommaValue
          L4_2 = L13_1
          L3_2, L4_2 = L3_2(L4_2)
          L2_2(L3_2, L4_2)
        end
        L2_2 = PlaySound
        L3_2 = "DLC_VW_BET_MAX"
        L4_2 = "dlc_vw_table_games_frontend_sounds"
        L2_2(L3_2, L4_2)
        L2_2 = L47_1
        L2_2()
      end
    end
  end
  ::lbl_466::
  L0_2 = IsControlJustPressed
  L1_2 = 0
  L2_2 = 210
  L0_2 = L0_2(L1_2, L2_2)
  if not L0_2 then
    L0_2 = IsDisabledControlJustPressed
    L1_2 = 0
    L2_2 = 210
    L0_2 = L0_2(L1_2, L2_2)
    if not L0_2 then
      goto lbl_497
    end
  end
  L0_2 = L12_1
  if 0 == L0_2 then
    L0_2 = Config
    L0_2 = L0_2.EnableGuidebookIntegration
    if L0_2 then
      L0_2 = TriggerServerEvent
      L1_2 = "GuideBook:ShowItToMe"
      L2_2 = "casinopoker"
      L0_2(L1_2, L2_2)
    else
      L0_2 = L50_1
      L1_2 = 1
      L0_2(L1_2)
      L0_2 = PlaySound
      L1_2 = "DLC_VW_RULES"
      L2_2 = "dlc_vw_table_games_frontend_sounds"
      L0_2(L1_2, L2_2)
    end
  end
  ::lbl_497::
end
function L52_1()
  local L0_2, L1_2, L2_2
  L0_2 = DebugStart
  L1_2 = "StartSittingThread"
  L0_2(L1_2)
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = nil
    while true do
      L1_3 = L10_1
      if not L1_3 then
        break
      end
      L1_3 = L5_1
      if nil == L1_3 then
        break
      end
      L1_3 = IsGamepadControl
      L1_3 = L1_3()
      if L1_3 ~= L0_3 then
        L1_3 = L47_1
        L1_3()
        L1_3 = IsGamepadControl
        L1_3 = L1_3()
        L0_3 = L1_3
      end
      L1_3 = L51_1
      L1_3()
      L1_3 = L12_1
      if L1_3 > 0 then
        L1_3 = GAME_INFO_PANEL
        if nil == L1_3 then
          L1_3 = 0
          L12_1 = L1_3
          L1_3 = RageUI
          L1_3.WaitForClose = false
          L1_3 = L47_1
          L1_3()
        end
      end
      L1_3 = L17_1
      if not L1_3 then
        L1_3 = InfoPanel_DrawNotificationThisFrame
        L2_3 = Translation
        L2_3 = L2_3.Get
        L3_3 = "CASINO_NOT_IN_ROUND"
        L2_3, L3_3 = L2_3(L3_3)
        L1_3(L2_3, L3_3)
      end
      L1_3 = Wait
      L2_3 = 0
      L1_3(L2_3)
    end
  end
  L2_2 = "thread that runs while sitting/playing"
  L0_2(L1_2, L2_2)
end
function L53_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "OnPlayerSatDown"
  L0_2(L1_2)
  L0_2 = true
  L6_1 = L0_2
  L0_2 = L34_1
  L0_2()
  L0_2 = L52_1
  L0_2()
  L0_2 = RequestPlayerChips
  L0_2()
end
function L54_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = DebugStart
  L1_2 = "StartSittingDown"
  L0_2(L1_2)
  L0_2 = SetInventoryBusy
  L1_2 = true
  L0_2(L1_2)
  L0_2 = RequestAnimDictAndWait
  L1_2 = L4_1
  L0_2(L1_2)
  L0_2 = RequestAnimDictAndWait
  L1_2 = L3_1
  L0_2(L1_2)
  L0_2 = getClosestAnimation
  L1_2 = GetPlayerPosition
  L1_2 = L1_2()
  L2_2 = L8_1.coords
  L3_2 = L8_1.rotation
  L4_2 = L4_1
  L5_2 = {}
  L6_2 = "sit_enter_left"
  L7_2 = "sit_enter_left_side"
  L8_2 = "sit_enter_right"
  L9_2 = "sit_enter_right_side"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L5_2[4] = L9_2
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  L1_2 = PlaySynchronizedScene
  L2_2 = L8_1.coords
  L3_2 = L8_1.rotation
  L4_2 = L4_1
  L5_2 = L0_2
  L6_2 = false
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L2_2 = CreateNewSceneEndEvent
  L3_2 = L1_2
  L4_2 = 0.5
  L5_2 = L53_1
  L6_2 = 8000
  L7_2 = 500
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L2_2 = SetCurrentPedWeapon
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetHashKey
  L5_2 = "weapon_unarmed"
  L4_2 = L4_2(L5_2)
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Stats_StartActivity
  L3_2 = "poker"
  L2_2(L3_2)
  L2_2 = 0
  L24_1 = L2_2
  L2_2 = 0
  L23_1 = L2_2
end
function L55_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = DebugStart
  L4_2 = "PlayPedCardsFold"
  L3_2(L4_2)
  L3_2 = A1_2.chairPositions
  L3_2 = L3_2[A2_2]
  L4_2 = PlaySynchronizedSceneOnPed
  L5_2 = A0_2
  L6_2 = L3_2.coords
  L7_2 = L3_2.rotation
  L8_2 = L3_1
  L9_2 = "cards_fold"
  L10_2 = false
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = A1_2.foldCards
  L6_2 = L3_2.id
  L5_2(L6_2)
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  if A0_2 == L5_2 then
    L5_2 = CreateNewSceneEndEvent
    L6_2 = L4_2
    L7_2 = 0.9
    L8_2 = L34_1
    L9_2 = 5000
    L10_2 = 500
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  end
end
function L56_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = DebugStart
  L4_2 = "PlayPedPickupCardsAnimation"
  L3_2(L4_2)
  L3_2 = A1_2.syncedState
  L3_2 = L3_2.cardsInHands
  L3_2[A2_2] = true
  L3_2 = A1_2.chairPositions
  L3_2 = L3_2[A2_2]
  L4_2 = PlaySynchronizedSceneOnPed
  L5_2 = A0_2
  L6_2 = L3_2.coords
  L7_2 = L3_2.rotation
  L8_2 = L3_1
  L9_2 = "cards_pickup"
  L10_2 = false
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = A1_2.pickupCards
  L6_2 = L3_2.id
  L5_2(L6_2)
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  if A0_2 == L5_2 then
    L5_2 = CreateNewSceneEndEvent
    L6_2 = L4_2
    L7_2 = 0.9
    function L8_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
      L0_3 = PlaySynchronizedScene
      L1_3 = L3_2.coords
      L2_3 = L3_2.rotation
      L3_3 = L3_1
      L4_3 = "cards_idle"
      L5_3 = true
      L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
      L0_3 = A1_2.holdCards
      L1_3 = L3_2.id
      L0_3(L1_3)
    end
    L9_2 = 5000
    L10_2 = 500
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  end
end
function L57_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L6_2 = DebugStart
  L7_2 = "CreatePokerTable"
  L6_2(L7_2)
  L6_2 = Debug
  L7_2 = "CreatePokerTable"
  L8_2 = A0_2
  L9_2 = A1_2
  L10_2 = A2_2
  L11_2 = A3_2
  L12_2 = A4_2
  L13_2 = A5_2
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
  L6_2 = {}
  L6_2.magicNumber = A5_2
  L7_2 = {}
  L6_2.chairPositions = L7_2
  L6_2.tickSound = -1
  L6_2.keepTableObject = false
  L6_2.automated = false
  L6_2.pokerCamera = nil
  L6_2.cameraActive = false
  L7_2 = {}
  L6_2.allCards = L7_2
  L7_2 = {}
  L6_2.chairCards = L7_2
  L7_2 = {}
  L6_2.chairChips = L7_2
  L6_2.cardPileObject = nil
  L6_2.ped = nil
  L6_2.ambientPeds = nil
  L6_2.pedModel = "S_F_Y_Casino_01"
  L7_2 = {}
  L6_2.syncedState = L7_2
  L7_2 = L6_2.syncedState
  L8_2 = {}
  L7_2.chairs = L8_2
  L7_2 = L6_2.syncedState
  L8_2 = {}
  L7_2.cardStates = L8_2
  L7_2 = L6_2.syncedState
  L8_2 = {}
  L7_2.cardsInHands = L8_2
  L7_2 = DoesEntityExist
  L8_2 = A0_2
  L7_2 = L7_2(L8_2)
  if L7_2 then
    L7_2 = Debug
    L8_2 = "CreatePokerTable"
    L9_2 = "Table object already exists"
    L7_2(L8_2, L9_2)
    L6_2.tableObject = A0_2
    L7_2 = GetEntityCoords
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    A1_2 = L7_2
    L7_2 = GetEntityRotation
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    A2_2 = L7_2
    L7_2 = GetEntityHeading
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    A3_2 = L7_2
    L6_2.keepTableObject = true
  else
    L7_2 = Debug
    L8_2 = "CreatePokerTable"
    L9_2 = "Table object does not exist"
    L7_2(L8_2, L9_2)
    L7_2 = CreateObject
    L8_2 = A0_2
    L9_2 = A1_2
    L10_2 = false
    L11_2 = false
    L12_2 = false
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L6_2.tableObject = L7_2
  end
  L7_2 = L6_2.tableObject
  L6_2.id = L7_2
  L6_2.color = A4_2
  L6_2.coords = A1_2
  L6_2.heading = A3_2
  L6_2.rotation = A2_2
  L7_2 = SetObjectTextureVariation
  L8_2 = L6_2.tableObject
  L9_2 = A4_2
  L7_2(L8_2, L9_2)
  L7_2 = GetObjectOffsetFromCoords
  L8_2 = L6_2.coords
  L9_2 = L6_2.heading
  L10_2 = 0.0
  L11_2 = -0.04
  L12_2 = 1.35
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  L8_2 = CreateCamWithParams
  L9_2 = "DEFAULT_SCRIPTED_CAMERA"
  L10_2 = L7_2
  L11_2 = -78.0
  L12_2 = 0.0
  L13_2 = L6_2.heading
  L14_2 = 70.0
  L15_2 = true
  L16_2 = 2
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L6_2.pokerCamera = L8_2
  L8_2 = SetCamActive
  L9_2 = L6_2.pokerCamera
  L10_2 = false
  L8_2(L9_2, L10_2)
  L8_2 = math
  L8_2 = L8_2.fmod
  L9_2 = L6_2.magicNumber
  L10_2 = 2
  L8_2 = L8_2(L9_2, L10_2)
  if 0 == L8_2 then
    L6_2.pedModel = "S_F_Y_Casino_01"
    L8_2 = RouletteFemaleVoices
    L9_2 = Repeat
    L10_2 = L6_2.magicNumber
    L11_2 = 3
    L9_2 = L9_2(L10_2, L11_2)
    L9_2 = L9_2 + 1
    L8_2 = L8_2[L9_2]
    L6_2.pedVoice = L8_2
  else
    L6_2.pedModel = "S_M_Y_Casino_01"
    L8_2 = RouletteMaleVoices
    L9_2 = Repeat
    L10_2 = L6_2.magicNumber
    L11_2 = 3
    L9_2 = L9_2(L10_2, L11_2)
    L9_2 = L9_2 + 1
    L8_2 = L8_2[L9_2]
    L6_2.pedVoice = L8_2
  end
  L8_2 = Debug
  L9_2 = "CreatePokerTable"
  L10_2 = "Ped model"
  L11_2 = L6_2.pedModel
  L12_2 = "Ped voice"
  L13_2 = L6_2.pedVoice
  L8_2(L9_2, L10_2, L11_2, L12_2, L13_2)
  L8_2 = RequestModelAndWait
  L9_2 = GetHashKey
  L10_2 = L6_2.pedModel
  L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2 = L9_2(L10_2)
  L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L8_2 = GetObjectOffsetFromCoords
  L9_2 = A1_2.x
  L10_2 = A1_2.y
  L11_2 = A1_2.z
  L12_2 = A3_2
  L13_2 = 0.0
  L14_2 = 0.7
  L15_2 = 0.0
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L6_2.pedOffset = L8_2
  L8_2 = CreatePed
  L9_2 = 2
  L10_2 = GetHashKey
  L11_2 = L6_2.pedModel
  L10_2 = L10_2(L11_2)
  L11_2 = L6_2.pedOffset
  L12_2 = A3_2 + 180.0
  L13_2 = false
  L14_2 = false
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L6_2.ped = L8_2
  L8_2 = SetEntityNoCollisionEntity
  L9_2 = L6_2.ped
  L10_2 = L6_2.tableObject
  L11_2 = false
  L8_2(L9_2, L10_2, L11_2)
  L8_2 = FreezeEntityPosition
  L9_2 = L6_2.ped
  L10_2 = true
  L8_2(L9_2, L10_2)
  L8_2 = SetCroupierSkin
  L9_2 = L6_2.ped
  L10_2 = L6_2.magicNumber
  L8_2(L9_2, L10_2)
  L8_2 = SetPedBrave
  L9_2 = L6_2.ped
  L8_2(L9_2)
  L8_2 = Debug
  L9_2 = "CreatePokerTable"
  L10_2 = "Ped created"
  L11_2 = L6_2.ped
  L8_2(L9_2, L10_2, L11_2)
  L8_2 = 1
  L9_2 = 4
  L10_2 = 1
  for L11_2 = L8_2, L9_2, L10_2 do
    L12_2 = L6_2.syncedState
    L12_2 = L12_2.chairs
    L12_2[L11_2] = -1
    L12_2 = L6_2.chairCards
    L13_2 = {}
    L12_2[L11_2] = L13_2
    L12_2 = L6_2.chairChips
    L13_2 = {}
    L12_2[L11_2] = L13_2
    L12_2 = L6_2.syncedState
    L12_2 = L12_2.cardsInHands
    L12_2[L11_2] = false
  end
  L8_2 = L6_2.chairCards
  L9_2 = {}
  L8_2.dealer = L9_2
  L8_2 = Debug
  L9_2 = "CreatePokerTable"
  L10_2 = "Table created"
  L11_2 = L6_2.tableObject
  L12_2 = "Ped"
  L13_2 = L6_2.ped
  L14_2 = "Camera"
  L15_2 = L6_2.pokerCamera
  L16_2 = "Magic number"
  L17_2 = L6_2.magicNumber
  L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  function L8_2()
    local L0_3, L1_3, L2_3
    L0_3 = Debug
    L1_3 = "pedEnsureDictionary"
    L2_3 = "Ensuring dictionary"
    L0_3(L1_3, L2_3)
    L0_3 = RequestAnimDictAndWait
    L1_3 = L1_1
    L0_3(L1_3)
    L0_3 = RequestAnimDictAndWait
    L1_3 = L2_1
    L0_3(L1_3)
  end
  L6_2.pedEnsureDictionary = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L0_3 = Debug
    L1_3 = "loadChairData"
    L2_3 = "Loading chair data"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.chairPositions
    L0_3 = #L0_3
    if L0_3 > 0 then
      return
    end
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = GetEntityBoneIndexByName
      L5_3 = L6_2.tableObject
      L6_3 = "Chair_Base_0"
      L7_3 = L3_3
      L6_3 = L6_3 .. L7_3
      L4_3 = L4_3(L5_3, L6_3)
      L5_3 = {}
      L6_3 = GetWorldPositionOfEntityBone
      L7_3 = L6_2.tableObject
      L8_3 = L4_3
      L6_3 = L6_3(L7_3, L8_3)
      L5_3.coords = L6_3
      L6_3 = GetWorldRotationOfEntityBone
      L7_3 = L6_2.tableObject
      L8_3 = L4_3
      L6_3 = L6_3(L7_3, L8_3)
      L5_3.rotation = L6_3
      L6_3 = table
      L6_3 = L6_3.insert
      L7_3 = L6_2.chairPositions
      L8_3 = 1
      L9_3 = L5_3
      L6_3(L7_3, L8_3, L9_3)
    end
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = L6_2.chairPositions
      L4_3 = L4_3[L3_3]
      L4_3.id = L3_3
    end
    L0_3 = Debug
    L1_3 = "loadChairData"
    L2_3 = "Chair data loaded"
    L3_3 = L6_2.chairPositions
    L0_3(L1_3, L2_3, L3_3)
  end
  L6_2.loadChairData = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = Debug
    L1_3 = "disableCamera"
    L2_3 = "Disabling camera"
    L0_3(L1_3, L2_3)
    L0_3 = SetCamActive
    L1_3 = L6_2.pokerCamera
    L2_3 = false
    L0_3(L1_3, L2_3)
    L0_3 = RenderScriptCams
    L1_3 = false
    L2_3 = 900
    L3_3 = 900
    L4_3 = true
    L5_3 = false
    L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
    L6_2.cameraActive = false
    L0_3 = Debug
    L1_3 = "disableCamera"
    L2_3 = "Camera disabled"
    L0_3(L1_3, L2_3)
  end
  L6_2.disableCamera = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = Debug
    L1_3 = "enableCamera"
    L2_3 = "Enabling camera"
    L0_3(L1_3, L2_3)
    L0_3 = SetCamActive
    L1_3 = L6_2.pokerCamera
    L2_3 = true
    L0_3(L1_3, L2_3)
    L0_3 = RenderScriptCams
    L1_3 = true
    L2_3 = 900
    L3_3 = 900
    L4_3 = true
    L5_3 = false
    L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
    L0_3 = ShakeCam
    L1_3 = L6_2.pokerCamera
    L2_3 = "HAND_SHAKE"
    L3_3 = 0.25
    L0_3(L1_3, L2_3, L3_3)
    L6_2.cameraActive = true
    L0_3 = Debug
    L1_3 = "enableCamera"
    L2_3 = "Camera enabled"
    L0_3(L1_3, L2_3)
  end
  L6_2.enableCamera = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = Debug
    L1_3 = "startTicking"
    L2_3 = "Starting ticking sound effect"
    L0_3(L1_3, L2_3)
    L0_3 = GetSoundId
    L0_3 = L0_3()
    L6_2.tickSound = L0_3
    L0_3 = PlaySoundFrontend
    L1_3 = L6_2.tickSound
    L2_3 = "5s"
    L3_3 = "MP_MISSION_COUNTDOWN_SOUNDSET"
    L4_3 = 1
    L0_3(L1_3, L2_3, L3_3, L4_3)
    L0_3 = Debug
    L1_3 = "startTicking"
    L2_3 = "Ticking sound effect started"
    L3_3 = L6_2.tickSound
    L0_3(L1_3, L2_3, L3_3)
  end
  L6_2.startTicking = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3
    L0_3 = Debug
    L1_3 = "stopTicking"
    L2_3 = "Stopping ticking sound effect"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.tickSound
    if -1 ~= L0_3 then
      L0_3 = StopSound
      L1_3 = L6_2.tickSound
      L0_3(L1_3)
      L0_3 = ReleaseSoundId
      L1_3 = L6_2.tickSound
      L0_3(L1_3)
    end
    L6_2.tickSound = -1
    L0_3 = Debug
    L1_3 = "stopTicking"
    L2_3 = "Ticking sound effect stopped"
    L0_3(L1_3, L2_3)
  end
  L6_2.stopTicking = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = Debug
    L2_3 = "getClosestChair"
    L3_3 = "Getting closest chair"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = 9.0
    L2_3 = 1
    L3_3 = nil
    L4_3 = pairs
    L5_3 = L6_2.chairPositions
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = L9_3.coords
      L10_3 = A0_3 - L10_3
      L10_3 = #L10_3
      if L1_3 > L10_3 then
        L10_3 = L9_3.coords
        L10_3 = A0_3 - L10_3
        L1_3 = #L10_3
        L2_3 = L8_3
        L3_3 = L9_3
      end
    end
    L4_3 = Debug
    L5_3 = "getClosestChair"
    L6_3 = "Closest chair"
    L7_3 = L2_3
    L8_3 = L3_3
    L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L2_3
    L5_3 = L3_3
    return L4_3, L5_3
  end
  L6_2.getClosestChair = L8_2
  L8_2 = {}
  L6_2.dirtObjects = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L0_3 = Debug
    L1_3 = "cleanDirt"
    L2_3 = "Cleaning dirt"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.dirtObjects
    if not L0_3 then
      return
    end
    L0_3 = pairs
    L1_3 = L6_2.dirtObjects
    L0_3, L1_3, L2_3, L3_3 = L0_3(L1_3)
    for L4_3, L5_3 in L0_3, L1_3, L2_3, L3_3 do
      L6_3 = Cleaner_RemoveDirt
      L7_3 = L5_3.id
      L6_3(L7_3)
    end
    L0_3 = {}
    L6_2.dirtObjects = L0_3
    L0_3 = Debug
    L1_3 = "cleanDirt"
    L2_3 = "Dirt cleaned"
    L0_3(L1_3, L2_3)
  end
  L6_2.cleanDirt = L8_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = Debug
    L3_3 = "changeDirtLevel"
    L4_3 = "Changing dirt level"
    L5_3 = A0_3
    L6_3 = A1_3
    L2_3(L3_3, L4_3, L5_3, L6_3)
    L2_3 = Config
    L2_3 = L2_3.Jobs
    if L2_3 then
      L2_3 = Config
      L2_3 = L2_3.Jobs
      L2_3 = L2_3.Cleaner
      L2_3 = L2_3.Enabled
      if L2_3 then
        goto lbl_18
      end
    end
    do return end
    ::lbl_18::
    L2_3 = 0.15
    if A0_3 < L2_3 then
      A0_3 = 0
    end
    if 0 == A0_3 and 0 == A1_3 then
      L2_3 = L6_2.cleanDirt
      L2_3()
      return
    end
    if not A1_3 then
      A1_3 = 0
    end
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4
      L0_4 = L6_2.dirtObjects
      L0_4 = L0_4[1]
      L1_4 = A0_3
      if L1_4 > 0.0 then
        if L0_4 then
          L1_4 = L0_4.destroyed
          if not L1_4 then
            goto lbl_47
          end
        end
        L1_4 = GetObjectOffsetFromCoords
        L2_4 = L6_2.coords
        L3_4 = L6_2.heading
        L4_4 = 0.0
        L5_4 = 0.0987
        L6_4 = 0.89261
        L1_4 = L1_4(L2_4, L3_4, L4_4, L5_4, L6_4)
        L2_4 = Cleaner_AddNearbyDirt
        L3_4 = "pk_"
        L4_4 = GetGameTimer
        L4_4 = L4_4()
        L5_4 = "_0"
        L3_4 = L3_4 .. L4_4 .. L5_4
        L4_4 = "casino_dirt_plane"
        L5_4 = L1_4
        L6_4 = vector3
        L7_4 = 0.0
        L8_4 = 0.0
        L9_4 = L6_2.heading
        L9_4 = L9_4 + 180.0
        L6_4 = L6_4(L7_4, L8_4, L9_4)
        L7_4 = 10.0
        L8_4 = 255
        L9_4 = 2
        L2_4 = L2_4(L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4)
        L0_4 = L2_4
        L2_4 = L6_2
        L0_4.forTable = L2_4
        L0_4.tableGame = "poker"
        L0_4.isPlane = true
        L2_4 = table
        L2_4 = L2_4.insert
        L3_4 = L6_2.dirtObjects
        L4_4 = L0_4
        L2_4(L3_4, L4_4)
        ::lbl_47::
        L1_4 = L0_4.o
        if L1_4 then
          L1_4 = SetEntityAlpha
          L2_4 = L0_4.o
          L3_4 = math
          L3_4 = L3_4.ceil
          L4_4 = A0_3
          L4_4 = L4_4 * 255.0
          L3_4 = L3_4(L4_4)
          L4_4 = false
          L1_4(L2_4, L3_4, L4_4)
        end
        L1_4 = math
        L1_4 = L1_4.ceil
        L2_4 = A0_3
        L2_4 = L2_4 * 255.0
        L1_4 = L1_4(L2_4)
        L0_4.alpha = L1_4
      elseif L0_4 then
        L1_4 = L0_4.destroyed
        if not L1_4 then
          L1_4 = Cleaner_RemoveDirt
          L2_4 = L0_4.id
          L1_4(L2_4)
          L1_4 = L6_2.dirtObjects
          L1_4[0] = nil
        end
      end
      L1_4 = L6_2.dirtObjects
      L1_4 = #L1_4
      L1_4 = L1_4 - 1
      L2_4 = A1_3
      if L2_4 > 0 then
        L2_4 = A1_3
        if L1_4 < L2_4 then
          L2_4 = {}
          L3_4 = 1
          L4_4 = Config
          L4_4 = L4_4.JobConsts
          L4_4 = L4_4.MissionPokerDirtyOffsets
          L4_4 = #L4_4
          L5_4 = 1
          for L6_4 = L3_4, L4_4, L5_4 do
            L7_4 = 1
            L8_4 = Config
            L8_4 = L8_4.JobConsts
            L8_4 = L8_4.MissionPokerDirtyOffsets
            L8_4 = L8_4[L6_4]
            L8_4 = L8_4.offsets
            L8_4 = #L8_4
            L9_4 = 1
            for L10_4 = L7_4, L8_4, L9_4 do
              L11_4 = table
              L11_4 = L11_4.insert
              L12_4 = L2_4
              L13_4 = {}
              L14_4 = Config
              L14_4 = L14_4.JobConsts
              L14_4 = L14_4.MissionPokerDirtyOffsets
              L14_4 = L14_4[L6_4]
              L14_4 = L14_4.model
              L13_4.model = L14_4
              L14_4 = Config
              L14_4 = L14_4.JobConsts
              L14_4 = L14_4.MissionPokerDirtyOffsets
              L14_4 = L14_4[L6_4]
              L14_4 = L14_4.offsets
              L14_4 = L14_4[L10_4]
              L13_4.offset = L14_4
              L11_4(L12_4, L13_4)
            end
          end
          L3_4 = ShuffleList
          L4_4 = L2_4
          L5_4 = L6_2.magicNumber
          L3_4(L4_4, L5_4)
          L3_4 = L1_4
          L4_4 = 1
          L5_4 = #L2_4
          L6_4 = 1
          for L7_4 = L4_4, L5_4, L6_4 do
            L8_4 = L2_4[L7_4]
            L9_4 = GetObjectOffsetFromCoords
            L10_4 = L6_2.coords
            L11_4 = L6_2.heading
            L12_4 = L8_4.offset
            L12_4 = L12_4.x
            L13_4 = L8_4.offset
            L13_4 = L13_4.y
            L14_4 = L8_4.offset
            L14_4 = L14_4.z
            L9_4 = L9_4(L10_4, L11_4, L12_4, L13_4, L14_4)
            L10_4 = false
            L11_4 = L6_2.dirtObjects
            L11_4 = #L11_4
            if L11_4 > 1 then
              L11_4 = 2
              L12_4 = L6_2.dirtObjects
              L12_4 = #L12_4
              L13_4 = 1
              for L14_4 = L11_4, L12_4, L13_4 do
                L15_4 = L6_2.dirtObjects
                L15_4 = L15_4[L14_4]
                L15_4 = L15_4.destroyed
                if not L15_4 then
                  L15_4 = L6_2.dirtObjects
                  L15_4 = L15_4[L14_4]
                  L15_4 = L15_4.coords
                  L15_4 = L9_4 - L15_4
                  L15_4 = #L15_4
                  L16_4 = 0.1
                  if L15_4 < L16_4 then
                    L10_4 = true
                  end
                end
              end
            end
            if not L10_4 then
              L11_4 = RequestModelAndWait
              L12_4 = L8_4.model
              L11_4(L12_4)
              L11_4 = IN_CASINO
              if not L11_4 then
                return
              end
              L11_4 = GetObjectOffsetFromCoords
              L12_4 = L6_2.coords
              L13_4 = L6_2.heading
              L14_4 = L8_4.offset
              L14_4 = L14_4.x
              L15_4 = L8_4.offset
              L15_4 = L15_4.y
              L16_4 = L8_4.offset
              L16_4 = L16_4.z
              L11_4 = L11_4(L12_4, L13_4, L14_4, L15_4, L16_4)
              L12_4 = "pk_"
              L13_4 = GetGameTimer
              L13_4 = L13_4()
              L14_4 = "_"
              L15_4 = L7_4
              L12_4 = L12_4 .. L13_4 .. L14_4 .. L15_4
              L13_4 = Cleaner_AddNearbyDirt
              L14_4 = L12_4
              L15_4 = L8_4.model
              L16_4 = L11_4
              L17_4 = nil
              L18_4 = 10.0
              L19_4 = 255
              L20_4 = 2
              L13_4 = L13_4(L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4)
              L14_4 = L6_2
              L13_4.forTable = L14_4
              L13_4.tableGame = "poker"
              L14_4 = table
              L14_4 = L14_4.insert
              L15_4 = L6_2.dirtObjects
              L16_4 = L13_4
              L14_4(L15_4, L16_4)
              L3_4 = L3_4 + 1
              L14_4 = A1_3
              if L3_4 >= L14_4 then
                break
              end
            end
          end
      end
      else
        L2_4 = A1_3
        if L1_4 > L2_4 then
          L2_4 = L6_2.dirtObjects
          L2_4 = #L2_4
          L3_4 = 2
          L4_4 = -1
          for L5_4 = L2_4, L3_4, L4_4 do
            L6_4 = L6_2.dirtObjects
            L6_4 = L6_4[L5_4]
            L6_4 = L6_4.destroyed
            if not L6_4 then
              L6_4 = Cleaner_RemoveDirt
              L7_4 = L6_2.dirtObjects
              L7_4 = L7_4[L5_4]
              L7_4 = L7_4.id
              L6_4(L7_4)
              L6_4 = table
              L6_4 = L6_4.remove
              L7_4 = L6_2.dirtObjects
              L8_4 = L5_4
              L6_4(L7_4, L8_4)
            end
            L6_4 = L6_2.dirtObjects
            L6_4 = #L6_4
            L6_4 = L6_4 - 1
            L7_4 = A1_3
            if L6_4 <= L7_4 then
              break
            end
          end
        end
      end
    end
    L4_3 = "changed dirt level"
    L2_3(L3_3, L4_3)
    L2_3 = Debug
    L3_3 = "changeDirtLevel"
    L4_3 = "Dirt level changed"
    L2_3(L3_3, L4_3)
  end
  L6_2.changeDirtLevel = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = Debug
    L2_3 = "createCard"
    L3_3 = "Creating card"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = GetHashKey
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    L2_3 = RequestModelAndWait
    L3_3 = L1_3
    L2_3(L3_3)
    L2_3 = CreateObject
    L3_3 = L1_3
    L4_3 = L6_2.coords
    L5_3 = vector3
    L6_3 = 0.0
    L7_3 = 0.0
    L8_3 = -0.045
    L5_3 = L5_3(L6_3, L7_3, L8_3)
    L4_3 = L4_3 + L5_3
    L5_3 = false
    L6_3 = false
    L7_3 = false
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
    L3_3 = L6_2.allCards
    L3_3[L2_3] = L2_3
    L3_3 = Debug
    L4_3 = "createCard"
    L5_3 = "Card created"
    L6_3 = L2_3
    L3_3(L4_3, L5_3, L6_3)
    return L2_3
  end
  L6_2.createCard = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = Debug
    L2_3 = "createDuplicate"
    L3_3 = "Creating duplicate"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = GetEntityModel
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    L2_3 = GetEntityCoords
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    L3_3 = GetEntityRotation
    L4_3 = A0_3
    L3_3 = L3_3(L4_3)
    L4_3 = CreateObject
    L5_3 = L1_3
    L6_3 = L2_3
    L7_3 = L3_3
    L4_3 = L4_3(L5_3, L6_3, L7_3)
    L5_3 = SetEntityCoordsNoOffset
    L6_3 = L4_3
    L7_3 = L2_3
    L5_3(L6_3, L7_3)
    L5_3 = SetEntityRotation
    L6_3 = L4_3
    L7_3 = L3_3
    L5_3(L6_3, L7_3)
    L5_3 = SetEntityCollision
    L6_3 = L4_3
    L7_3 = false
    L8_3 = false
    L5_3(L6_3, L7_3, L8_3)
    L5_3 = FreezeEntityPosition
    L6_3 = L4_3
    L7_3 = true
    L5_3(L6_3, L7_3)
    L5_3 = L6_2.allCards
    L5_3[L4_3] = L4_3
    L5_3 = Debug
    L6_3 = "createDuplicate"
    L7_3 = "Duplicate created"
    L8_3 = L4_3
    L5_3(L6_3, L7_3, L8_3)
    return L4_3
  end
  L6_2.createDuplicate = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = Debug
    L2_3 = "deleteCard"
    L3_3 = "Deleting card"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = L6_2.allCards
    L1_3 = L1_3[A0_3]
    if nil ~= L1_3 then
      L1_3 = ForceDeleteEntity
      L2_3 = L6_2.allCards
      L2_3 = L2_3[A0_3]
      L1_3(L2_3)
      L1_3 = L6_2.allCards
      L1_3[A0_3] = nil
    end
    L1_3 = Debug
    L2_3 = "deleteCard"
    L3_3 = "Card deleted"
    L1_3(L2_3, L3_3)
  end
  L6_2.deleteCard = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = Debug
    L2_3 = "getChairCards"
    L3_3 = "Getting chair cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = L6_2.chairCards
    L1_3 = L1_3[A0_3]
    return L1_3
  end
  L6_2.getChairCards = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = Debug
    L1_3 = "createCardPile"
    L2_3 = "Creating card pile"
    L0_3(L1_3, L2_3)
    L0_3 = GetHashKey
    L1_3 = "vw_prop_vw_casino_cards_01"
    L0_3 = L0_3(L1_3)
    L1_3 = GetAnimInitialOffsetPosition
    L2_3 = L1_1
    L3_3 = "deck_pick_up_deck"
    L4_3 = L6_2.coords
    L5_3 = 0.0
    L6_3 = 0.0
    L7_3 = L6_2.heading
    L8_3 = 0.01
    L9_3 = 2
    L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
    L2_3 = GetAnimInitialOffsetRotation
    L3_3 = L1_1
    L4_3 = "deck_pick_up_deck"
    L5_3 = L6_2.coords
    L6_3 = 0.0
    L7_3 = 0.0
    L8_3 = L6_2.heading
    L9_3 = 0.01
    L10_3 = 2
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L3_3 = CreateObject
    L4_3 = L0_3
    L5_3 = L1_3
    L6_3 = false
    L7_3 = false
    L8_3 = true
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    L6_2.cardPileObject = L3_3
    L3_3 = SetEntityCoordsNoOffset
    L4_3 = L6_2.cardPileObject
    L5_3 = L1_3
    L6_3 = false
    L7_3 = false
    L8_3 = true
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    L3_3 = SetEntityRotation
    L4_3 = L6_2.cardPileObject
    L5_3 = L2_3
    L6_3 = 2
    L7_3 = true
    L3_3(L4_3, L5_3, L6_3, L7_3)
    L3_3 = FreezeEntityPosition
    L4_3 = L6_2.cardPileObject
    L5_3 = true
    L3_3(L4_3, L5_3)
    L3_3 = Debug
    L4_3 = "createCardPile"
    L5_3 = "Card pile created"
    L6_3 = L6_2.cardPileObject
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2.createCardPile = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = Debug
    L2_3 = "pokerPedSay"
    L3_3 = "Ped saying"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = PlayPedAmbientSpeechWithVoiceNative
    L2_3 = L6_2.ped
    L3_3 = A0_3
    L4_3 = L6_2.pedVoice
    L5_3 = "SPEECH_PARAMS_FORCE_NORMAL"
    L6_3 = 0
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
    L1_3 = Debug
    L2_3 = "pokerPedSay"
    L3_3 = "Ped said"
    L1_3(L2_3, L3_3)
  end
  L6_2.pokerPedSay = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L0_3 = Debug
    L1_3 = "pedPickupDeck"
    L2_3 = "Ped picking up deck"
    L0_3(L1_3, L2_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = L6_2.pokerPedSay
      if L0_3 then
        goto lbl_12
      end
    end
    do return end
    ::lbl_12::
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = IsPedMale
    L1_3 = L6_2.ped
    L0_3 = L0_3(L1_3)
    if L0_3 then
      L0_3 = ""
      if L0_3 then
        goto lbl_23
      end
    end
    L0_3 = "female_"
    ::lbl_23::
    L1_3 = nil
    L2_3 = PlayFacialAnim
    L3_3 = L6_2.ped
    L4_3 = L0_3
    L5_3 = "deck_pick_up_facial"
    L4_3 = L4_3 .. L5_3
    L5_3 = L1_1
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = GetInitialAnimOffsets
      L3_3 = L1_1
      L4_3 = L0_3
      L5_3 = "deck_pick_up"
      L4_3 = L4_3 .. L5_3
      L5_3 = L6_2.coords
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = L6_2.heading
      L2_3, L3_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
      L4_3 = TaskPlayAnimAdvanced
      L5_3 = L6_2.ped
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = "deck_pick_up"
      L7_3 = L7_3 .. L8_3
      L8_3 = L2_3
      L9_3 = L3_3
      L10_3 = 3.0
      L11_3 = 3.0
      L12_3 = -1
      L13_3 = 2
      L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L4_3 = WaitTaskAnimToReachTime
      L5_3 = L6_2.ped
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = "deck_pick_up"
      L7_3 = L7_3 .. L8_3
      L8_3 = 0.2
      L9_3 = 1000
      L10_3 = 100
      L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    else
      L2_3 = CreateSynchronizedScene
      L3_3 = L6_2.coords
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = L6_2.heading
      L7_3 = 2
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
      L1_3 = L2_3
      L2_3 = TaskSynchronizedScene
      L3_3 = L6_2.ped
      L4_3 = L1_3
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = "deck_pick_up"
      L6_3 = L6_3 .. L7_3
      L7_3 = 2.0
      L8_3 = -1.5
      L9_3 = 13
      L10_3 = 16
      L11_3 = 2.0
      L12_3 = 0
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
      L2_3 = WaitSynchronizedSceneToReachTime
      L3_3 = L1_3
      L4_3 = 0.2
      L5_3 = 1000
      L2_3(L3_3, L4_3, L5_3)
    end
    L2_3 = IN_CASINO
    if L2_3 then
      L2_3 = L6_2.pedPickupDeck
      if L2_3 then
        goto lbl_102
      end
    end
    do return end
    ::lbl_102::
    L2_3 = AttachEntityToEntity
    L3_3 = L6_2.cardPileObject
    L4_3 = L6_2.ped
    L5_3 = GetPedBoneIndex
    L6_3 = L6_2.ped
    L7_3 = 60309
    L5_3 = L5_3(L6_3, L7_3)
    L6_3 = 0.0
    L7_3 = 0.0
    L8_3 = 0.0
    L9_3 = 0.0
    L10_3 = 0.0
    L11_3 = 0.0
    L12_3 = false
    L13_3 = false
    L14_3 = false
    L15_3 = true
    L16_3 = 2
    L17_3 = true
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = WaitTaskAnimToReachTime
      L3_3 = L6_2.ped
      L4_3 = L1_1
      L5_3 = L0_3
      L6_3 = "deck_pick_up"
      L5_3 = L5_3 .. L6_3
      L6_3 = 0.7
      L7_3 = 1000
      L8_3 = 100
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
    else
      L2_3 = WaitSynchronizedSceneToReachTime
      L3_3 = L1_3
      L4_3 = 0.7
      L5_3 = 1000
      L2_3(L3_3, L4_3, L5_3)
    end
    L2_3 = IN_CASINO
    if L2_3 then
      L2_3 = L6_2.pedPickupDeck
      if L2_3 then
        goto lbl_148
      end
    end
    do return end
    ::lbl_148::
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = TaskPlayAnimAdvanced
      L3_3 = L6_2.ped
      L4_3 = L1_1
      L5_3 = L0_3
      L6_3 = "deck_idle"
      L5_3 = L5_3 .. L6_3
      L6_3 = initialPos
      L7_3 = initialRot
      L8_3 = 3.0
      L9_3 = 3.0
      L10_3 = -1
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
      L2_3 = WaitTaskAnimToReachTime
      L3_3 = L6_2.ped
      L4_3 = L1_1
      L5_3 = L0_3
      L6_3 = "deck_idle"
      L5_3 = L5_3 .. L6_3
      L6_3 = 0.3
      L7_3 = 1000
      L8_3 = 100
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
    else
      L2_3 = CreateSynchronizedScene
      L3_3 = L6_2.coords
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = L6_2.heading
      L7_3 = 2
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
      L1_3 = L2_3
      L2_3 = TaskSynchronizedScene
      L3_3 = L6_2.ped
      L4_3 = L1_3
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = "deck_idle"
      L6_3 = L6_3 .. L7_3
      L7_3 = 2.0
      L8_3 = -1.5
      L9_3 = 13
      L10_3 = 16
      L11_3 = 2.0
      L12_3 = 0
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
      L2_3 = PlayFacialAnim
      L3_3 = L6_2.ped
      L4_3 = L0_3
      L5_3 = "deck_idle_facial"
      L4_3 = L4_3 .. L5_3
      L5_3 = L1_1
      L2_3(L3_3, L4_3, L5_3)
      L2_3 = SetSynchronizedSceneLooped
      L3_3 = L1_3
      L4_3 = true
      L2_3(L3_3, L4_3)
      L2_3 = WaitSynchronizedSceneToReachTime
      L3_3 = L1_3
      L4_3 = 0.3
      L5_3 = 1000
      L2_3(L3_3, L4_3, L5_3)
    end
    L2_3 = Debug
    L3_3 = "pedPickupDeck"
    L4_3 = "Deck picked up"
    L2_3(L3_3, L4_3)
  end
  L6_2.pedPickupDeck = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L0_3 = Debug
    L1_3 = "pedShuffle"
    L2_3 = "Ped shuffling"
    L0_3(L1_3, L2_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = L6_2.createCard
      if L0_3 then
        goto lbl_12
      end
    end
    do return end
    ::lbl_12::
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = IsPedMale
    L1_3 = L6_2.ped
    L0_3 = L0_3(L1_3)
    if L0_3 then
      L0_3 = "deck_shuffle"
      if L0_3 then
        goto lbl_23
      end
    end
    L0_3 = "female_deck_shuffle"
    ::lbl_23::
    L1_3 = {}
    L2_3 = nil
    L3_3 = PlayFacialAnim
    L4_3 = L6_2.ped
    L5_3 = L0_3
    L6_3 = "_facial"
    L5_3 = L5_3 .. L6_3
    L6_3 = L1_1
    L3_3(L4_3, L5_3, L6_3)
    L3_3 = L6_2.automated
    if L3_3 then
      L3_3 = GetInitialAnimOffsets
      L4_3 = L1_1
      L5_3 = L0_3
      L6_3 = L6_2.coords
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = L6_2.heading
      L3_3, L4_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
      L5_3 = TaskPlayAnimAdvanced
      L6_3 = L6_2.ped
      L7_3 = L1_1
      L8_3 = L0_3
      L9_3 = L3_3
      L10_3 = L4_3
      L11_3 = 3.0
      L12_3 = 3.0
      L13_3 = -1
      L14_3 = 2
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    else
      L3_3 = CreateSynchronizedScene
      L4_3 = L6_2.coords
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = L6_2.heading
      L8_3 = 2
      L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
      L2_3 = L3_3
      L3_3 = TaskSynchronizedScene
      L4_3 = L6_2.ped
      L5_3 = L2_3
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = 2.0
      L9_3 = -1.5
      L10_3 = 13
      L11_3 = 16
      L12_3 = 2.0
      L13_3 = 0
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
    end
    L3_3 = RequestModelAndWait
    L4_3 = "vw_prop_vw_club_char_a_a"
    L3_3(L4_3)
    L3_3 = 1
    L4_3 = 3
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = L6_2.createCard
      L8_3 = "vw_prop_vw_club_char_a_a"
      L7_3 = L7_3(L8_3)
      L8_3 = "deck_shuffle_card_"
      L9_3 = PokerLetterIndex
      L9_3 = L9_3[L6_3]
      L8_3 = L8_3 .. L9_3
      L9_3 = GetInitialAnimOffsets
      L10_3 = L1_1
      L11_3 = L8_3
      L12_3 = L6_2.coords
      L13_3 = 0.0
      L14_3 = 0.0
      L15_3 = L6_2.heading
      L9_3, L10_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L11_3 = L6_2.automated
      if L11_3 then
        L11_3 = SetEntityCoordsNoOffset
        L12_3 = L7_3
        L13_3 = L9_3
        L11_3(L12_3, L13_3)
        L11_3 = SetEntityRotation
        L12_3 = L7_3
        L13_3 = L10_3
        L11_3(L12_3, L13_3)
        L11_3 = PlayEntityAnim
        L12_3 = L7_3
        L13_3 = L8_3
        L14_3 = L1_1
        L15_3 = 5000.0
        L16_3 = false
        L17_3 = true
        L18_3 = false
        L19_3 = 5000.0
        L20_3 = 0
        L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
      else
        L11_3 = PlaySynchronizedEntityAnim
        L12_3 = L7_3
        L13_3 = L2_3
        L14_3 = L8_3
        L15_3 = L1_1
        L16_3 = -5000.0
        L17_3 = 0
        L18_3 = 0
        L19_3 = 5000.0
        L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
      end
      L11_3 = SetEntityVisible
      L12_3 = L7_3
      L13_3 = false
      L11_3(L12_3, L13_3)
      L11_3 = table
      L11_3 = L11_3.insert
      L12_3 = L1_3
      L13_3 = L7_3
      L11_3(L12_3, L13_3)
    end
    L3_3 = CreateThread
    function L4_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
      L0_4 = L6_2.automated
      if L0_4 then
        L0_4 = WaitTaskAnimToReachTime
        L1_4 = L6_2.ped
        L2_4 = L1_1
        L3_4 = L0_3
        L4_4 = 0.6
        L5_4 = 3000
        L6_4 = 100
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4)
      else
        L0_4 = WaitSynchronizedSceneToReachTime
        L1_4 = L2_3
        L2_4 = 0.6
        L3_4 = 3000
        L0_4(L1_4, L2_4, L3_4)
      end
      L0_4 = IN_CASINO
      if L0_4 then
        L0_4 = L6_2.pedPickupDeck
        if L0_4 then
          goto lbl_25
        end
      end
      do return end
      ::lbl_25::
      L0_4 = pairs
      L1_4 = L1_3
      L0_4, L1_4, L2_4, L3_4 = L0_4(L1_4)
      for L4_4, L5_4 in L0_4, L1_4, L2_4, L3_4 do
        L6_4 = L6_2.deleteCard
        L7_4 = L5_4
        L6_4(L7_4)
      end
    end
    L5_3 = "Deleting animations after some time"
    L3_3(L4_3, L5_3)
    L3_3 = L6_2.automated
    if L3_3 then
      L3_3 = WaitTaskAnimToReachTime
      L4_3 = L6_2.ped
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = 0.15
      L8_3 = 3000
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    else
      L3_3 = WaitSynchronizedSceneToReachTime
      L4_3 = L2_3
      L5_3 = 0.15
      L6_3 = 3000
      L3_3(L4_3, L5_3, L6_3)
    end
    L3_3 = IN_CASINO
    if L3_3 then
      L3_3 = L6_2.pedPickupDeck
      if L3_3 then
        goto lbl_168
      end
    end
    do return end
    ::lbl_168::
    L3_3 = pairs
    L4_3 = L1_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = SetEntityVisible
      L10_3 = L8_3
      L11_3 = true
      L9_3(L10_3, L11_3)
    end
    L3_3 = L6_2.automated
    if L3_3 then
      L3_3 = WaitTaskAnimToReachTime
      L4_3 = L6_2.ped
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = 0.65
      L8_3 = 3000
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    else
      L3_3 = WaitSynchronizedSceneToReachTime
      L4_3 = L2_3
      L5_3 = 0.65
      L6_3 = 3000
      L3_3(L4_3, L5_3, L6_3)
    end
    L3_3 = Debug
    L4_3 = "pedShuffle"
    L5_3 = "Deck shuffled"
    L3_3(L4_3, L5_3)
  end
  L6_2.pedShuffle = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L0_3 = Debug
    L1_3 = "pedPutDownCardPile"
    L2_3 = "Ped putting down card pile"
    L0_3(L1_3, L2_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = L6_2.pedPickupDeck
      if L0_3 then
        goto lbl_12
      end
    end
    do return end
    ::lbl_12::
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = IsPedMale
    L1_3 = L6_2.ped
    L0_3 = L0_3(L1_3)
    if L0_3 then
      L0_3 = "deck_put_down"
      if L0_3 then
        goto lbl_23
      end
    end
    L0_3 = "female_deck_put_down"
    ::lbl_23::
    L1_3 = nil
    L2_3 = PlayFacialAnim
    L3_3 = L6_2.ped
    L4_3 = L0_3
    L5_3 = "_facial"
    L4_3 = L4_3 .. L5_3
    L5_3 = L1_1
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = GetInitialAnimOffsets
      L3_3 = L1_1
      L4_3 = L0_3
      L5_3 = L6_2.coords
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = L6_2.heading
      L2_3, L3_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
      L4_3 = TaskPlayAnimAdvanced
      L5_3 = L6_2.ped
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = L2_3
      L9_3 = L3_3
      L10_3 = 3.0
      L11_3 = 3.0
      L12_3 = -1
      L13_3 = 2
      L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L4_3 = WaitTaskAnimToReachTime
      L5_3 = L6_2.ped
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = 0.5
      L9_3 = 2000
      L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
    else
      L2_3 = CreateSynchronizedScene
      L3_3 = L6_2.coords
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = L6_2.heading
      L7_3 = 2
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
      L1_3 = L2_3
      L2_3 = TaskSynchronizedScene
      L3_3 = L6_2.ped
      L4_3 = L1_3
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = 2.0
      L8_3 = -1.5
      L9_3 = 13
      L10_3 = 16
      L11_3 = 2.0
      L12_3 = 0
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
      L2_3 = WaitSynchronizedSceneToReachTime
      L3_3 = L1_3
      L4_3 = 0.5
      L5_3 = 2000
      L6_3 = 100
      L2_3(L3_3, L4_3, L5_3, L6_3)
    end
    L2_3 = IN_CASINO
    if L2_3 then
      L2_3 = L6_2.pedPickupDeck
      if L2_3 then
        goto lbl_94
      end
    end
    do return end
    ::lbl_94::
    L2_3 = GetAnimInitialOffsetPosition
    L3_3 = L1_1
    L4_3 = "deck_pick_up_deck"
    L5_3 = L6_2.coords
    L6_3 = 0.0
    L7_3 = 0.0
    L8_3 = L6_2.heading
    L9_3 = 0.01
    L10_3 = 2
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L3_3 = GetAnimInitialOffsetRotation
    L4_3 = L1_1
    L5_3 = "deck_pick_up_deck"
    L6_3 = L6_2.coords
    L7_3 = 0.0
    L8_3 = 0.0
    L9_3 = L6_2.heading
    L10_3 = 0.01
    L11_3 = 2
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
    L4_3 = SetEntityCoordsNoOffset
    L5_3 = L6_2.cardPileObject
    L6_3 = L2_3
    L7_3 = false
    L8_3 = false
    L9_3 = true
    L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
    L4_3 = SetEntityRotation
    L5_3 = L6_2.cardPileObject
    L6_3 = L3_3
    L7_3 = 2
    L8_3 = true
    L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = FreezeEntityPosition
    L5_3 = L6_2.cardPileObject
    L6_3 = true
    L4_3(L5_3, L6_3)
    L4_3 = DetachEntity
    L5_3 = L6_2.cardPileObject
    L6_3 = true
    L7_3 = true
    L4_3(L5_3, L6_3, L7_3)
    L4_3 = Debug
    L5_3 = "pedPutDownCardPile"
    L6_3 = "Card pile put down"
    L4_3(L5_3, L6_3)
  end
  L6_2.pedPutDownCardPile = L8_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L2_3 = Debug
    L3_3 = "dealCards"
    L4_3 = "Dealing cards"
    L5_3 = A0_3
    L6_3 = A1_3
    L2_3(L3_3, L4_3, L5_3, L6_3)
    L2_3 = IN_CASINO
    if L2_3 then
      L2_3 = L6_2.pedPickupDeck
      if L2_3 then
        goto lbl_14
      end
    end
    do return end
    ::lbl_14::
    L2_3 = L6_2.pedEnsureDictionary
    L2_3()
    L2_3 = IsPedMale
    L3_3 = L6_2.ped
    L2_3 = L2_3(L3_3)
    if L2_3 then
      L2_3 = "deck_deal_p0"
      if L2_3 then
        goto lbl_25
      end
    end
    L2_3 = "female_deck_deal_p0"
    ::lbl_25::
    L3_3 = L2_3
    L4_3 = A0_3
    L3_3 = L3_3 .. L4_3
    L2_3 = L3_3
    L3_3 = nil
    L4_3 = {}
    L5_3 = L6_2.automated
    if L5_3 then
      L5_3 = GetInitialAnimOffsets
      L6_3 = L1_1
      L7_3 = L2_3
      L8_3 = L6_2.coords
      L9_3 = 0.0
      L10_3 = 0.0
      L11_3 = L6_2.heading
      L5_3, L6_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      L7_3 = TaskPlayAnimAdvanced
      L8_3 = L6_2.ped
      L9_3 = L1_1
      L10_3 = L2_3
      L11_3 = L5_3
      L12_3 = L6_3
      L13_3 = 3.0
      L14_3 = 3.0
      L15_3 = -1
      L16_3 = 2
      L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
    else
      L5_3 = CreateSynchronizedScene
      L6_3 = L6_2.coords
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = L6_2.heading
      L10_3 = 2
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
      L3_3 = L5_3
      L5_3 = TaskSynchronizedScene
      L6_3 = L6_2.ped
      L7_3 = L3_3
      L8_3 = L1_1
      L9_3 = L2_3
      L10_3 = 2.0
      L11_3 = -1.5
      L12_3 = 13
      L13_3 = 16
      L14_3 = 2.0
      L15_3 = 0
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L5_3 = IN_CASINO
    if L5_3 then
      L5_3 = L6_2.pedPickupDeck
      if L5_3 then
        goto lbl_82
      end
    end
    do return end
    ::lbl_82::
    L5_3 = 1
    L6_3 = 3
    L7_3 = 1
    for L8_3 = L5_3, L6_3, L7_3 do
      L9_3 = L6_2.createCard
      L10_3 = PokerCardModels
      L11_3 = A1_3[L8_3]
      L10_3 = L10_3[L11_3]
      L9_3 = L9_3(L10_3)
      L10_3 = table
      L10_3 = L10_3.insert
      L11_3 = L4_3
      L12_3 = L9_3
      L10_3(L11_3, L12_3)
      L10_3 = table
      L10_3 = L10_3.insert
      L11_3 = L6_2.chairCards
      L11_3 = L11_3[A0_3]
      L12_3 = L9_3
      L10_3(L11_3, L12_3)
      L10_3 = SetEntityVisible
      L11_3 = L9_3
      L12_3 = false
      L10_3(L11_3, L12_3)
      L10_3 = "deck_deal_p0"
      L11_3 = A0_3
      L12_3 = "_card_"
      L13_3 = PokerLetterIndex
      L13_3 = L13_3[L8_3]
      L10_3 = L10_3 .. L11_3 .. L12_3 .. L13_3
      L11_3 = L6_2.automated
      if L11_3 then
        L11_3 = GetInitialAnimOffsets
        L12_3 = L1_1
        L13_3 = L10_3
        L14_3 = L6_2.coords
        L15_3 = 0.0
        L16_3 = 0.0
        L17_3 = L6_2.heading
        L11_3, L12_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
        L13_3 = SetEntityCoordsNoOffset
        L14_3 = L9_3
        L15_3 = L11_3
        L13_3(L14_3, L15_3)
        L13_3 = SetEntityRotation
        L14_3 = L9_3
        L15_3 = L12_3
        L13_3(L14_3, L15_3)
        L13_3 = PlayEntityAnim
        L14_3 = L9_3
        L15_3 = L10_3
        L16_3 = L1_1
        L17_3 = 50000.0
        L18_3 = false
        L19_3 = true
        L20_3 = false
        L21_3 = 5000.0
        L22_3 = 0
        L13_3(L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3)
      else
        L11_3 = PlaySynchronizedEntityAnim
        L12_3 = L9_3
        L13_3 = L3_3
        L14_3 = L10_3
        L15_3 = L1_1
        L16_3 = 5000.0
        L17_3 = 0
        L18_3 = 0
        L19_3 = 5000.0
        L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
      end
    end
    L5_3 = L6_2.syncedState
    L5_3 = L5_3.cardStates
    L5_3[A0_3] = nil
    L5_3 = L6_2.automated
    if L5_3 then
      L5_3 = WaitTaskAnimToReachTime
      L6_3 = L6_2.ped
      L7_3 = L1_1
      L8_3 = L2_3
      L9_3 = 0.2
      L10_3 = 3000
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    else
      L5_3 = WaitSynchronizedSceneToReachTime
      L6_3 = L3_3
      L7_3 = 0.2
      L8_3 = 3000
      L5_3(L6_3, L7_3, L8_3)
    end
    L5_3 = IN_CASINO
    if L5_3 then
      L5_3 = L6_2.pedPickupDeck
      if L5_3 then
        goto lbl_180
      end
    end
    do return end
    ::lbl_180::
    L5_3 = pairs
    L6_3 = L4_3
    L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
    for L9_3, L10_3 in L5_3, L6_3, L7_3, L8_3 do
      L11_3 = SetEntityVisible
      L12_3 = L10_3
      L13_3 = true
      L11_3(L12_3, L13_3)
    end
    L5_3 = L6_2.automated
    if L5_3 then
      L5_3 = WaitTaskAnimToReachTime
      L6_3 = L6_2.ped
      L7_3 = L1_1
      L8_3 = L2_3
      L9_3 = 0.575
      L10_3 = 3000
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    else
      L5_3 = WaitSynchronizedSceneToReachTime
      L6_3 = L3_3
      L7_3 = 0.575
      L8_3 = 2000
      L5_3(L6_3, L7_3, L8_3)
    end
    L5_3 = Debug
    L6_3 = "dealCards"
    L7_3 = "Cards dealt"
    L8_3 = A0_3
    L9_3 = A1_3
    L5_3(L6_3, L7_3, L8_3, L9_3)
  end
  L6_2.dealCards = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L1_3 = Debug
    L2_3 = "pedCollectCards"
    L3_3 = "Collecting cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.pedEnsureDictionary
    L1_3()
    L1_3 = IsPedMale
    L2_3 = L6_2.ped
    L1_3 = L1_3(L2_3)
    if L1_3 then
      L1_3 = "cards_collect_"
      if L1_3 then
        goto lbl_24
      end
    end
    L1_3 = "female_cards_collect_"
    ::lbl_24::
    L2_3 = L1_3
    if "dealer" == A0_3 then
      L3_3 = "self"
      if L3_3 then
        goto lbl_33
      end
    end
    L3_3 = "p0"
    L4_3 = A0_3
    L3_3 = L3_3 .. L4_3
    ::lbl_33::
    L2_3 = L2_3 .. L3_3
    L1_3 = L2_3
    L2_3 = nil
    L3_3 = L6_2.automated
    if L3_3 then
      L3_3 = GetInitialAnimOffsets
      L4_3 = L1_1
      L5_3 = L1_3
      L6_3 = L6_2.coords
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = L6_2.heading
      L3_3, L4_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
      L5_3 = TaskPlayAnimAdvanced
      L6_3 = L6_2.ped
      L7_3 = L1_1
      L8_3 = L1_3
      L9_3 = L3_3
      L10_3 = L4_3
      L11_3 = 3.0
      L12_3 = 3.0
      L13_3 = -1
      L14_3 = 2
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    else
      L3_3 = CreateSynchronizedScene
      L4_3 = L6_2.coords
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = L6_2.heading
      L8_3 = 2
      L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
      L2_3 = L3_3
      L3_3 = TaskSynchronizedScene
      L4_3 = L6_2.ped
      L5_3 = L2_3
      L6_3 = L1_1
      L7_3 = L1_3
      L8_3 = 2.0
      L9_3 = -1.5
      L10_3 = 13
      L11_3 = 16
      L12_3 = 2.0
      L13_3 = 0
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
    end
    L3_3 = 1
    L4_3 = 3
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = L6_2.chairCards
      L7_3 = L7_3[A0_3]
      if nil ~= L7_3 then
        L7_3 = L6_2.chairCards
        L7_3 = L7_3[A0_3]
        L7_3 = L7_3[L6_3]
        if nil ~= L7_3 then
          L7_3 = "cards_collect_p0"
          L8_3 = A0_3
          L9_3 = "_card_"
          L10_3 = PokerLetterIndex
          L10_3 = L10_3[L6_3]
          L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
          if "dealer" == A0_3 then
            L8_3 = "cards_collect_self_card_"
            L9_3 = PokerLetterIndex
            L9_3 = L9_3[L6_3]
            L8_3 = L8_3 .. L9_3
            L7_3 = L8_3
          end
          L8_3 = L6_2.chairCards
          L8_3 = L8_3[A0_3]
          L8_3 = L8_3[L6_3]
          L9_3 = L6_2.automated
          if L9_3 then
            L9_3 = GetInitialAnimOffsets
            L10_3 = L1_1
            L11_3 = L7_3
            L12_3 = L6_2.coords
            L13_3 = 0.0
            L14_3 = 0.0
            L15_3 = L6_2.heading
            L9_3, L10_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
            L11_3 = SetEntityCoordsNoOffset
            L12_3 = L8_3
            L13_3 = L9_3
            L11_3(L12_3, L13_3)
            L11_3 = SetEntityRotation
            L12_3 = L8_3
            L13_3 = L10_3
            L11_3(L12_3, L13_3)
            L11_3 = PlayEntityAnim
            L12_3 = L8_3
            L13_3 = L7_3
            L14_3 = L1_1
            L15_3 = 5000.0
            L16_3 = false
            L17_3 = true
            L18_3 = false
            L19_3 = 5000.0
            L20_3 = 0
            L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
          else
            L9_3 = PlaySynchronizedEntityAnim
            L10_3 = L8_3
            L11_3 = L2_3
            L12_3 = L7_3
            L13_3 = L1_1
            L14_3 = 5000.0
            L15_3 = 0
            L16_3 = 0
            L17_3 = 5000.0
            L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
          end
        end
      end
    end
    L3_3 = L6_2.syncedState
    L3_3 = L3_3.cardStates
    L3_3[A0_3] = nil
    L3_3 = L6_2.automated
    if L3_3 then
      L3_3 = WaitTaskAnimToReachTime
      L4_3 = L6_2.ped
      L5_3 = L1_1
      L6_3 = L1_3
      L7_3 = 0.7
      L8_3 = 3000
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    else
      L3_3 = WaitSynchronizedSceneToReachTime
      L4_3 = L2_3
      L5_3 = 0.7
      L6_3 = 3000
      L3_3(L4_3, L5_3, L6_3)
    end
    L3_3 = IN_CASINO
    if L3_3 then
      L3_3 = L6_2.pedPickupDeck
      if L3_3 then
        goto lbl_176
      end
    end
    do return end
    ::lbl_176::
    L3_3 = L6_2.chairCards
    L3_3 = L3_3[A0_3]
    if nil ~= L3_3 then
      L3_3 = pairs
      L4_3 = L6_2.chairCards
      L4_3 = L4_3[A0_3]
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = ForceDeleteEntity
        L10_3 = L8_3
        L9_3(L10_3)
      end
    end
    L3_3 = L6_2.chairCards
    L4_3 = {}
    L3_3[A0_3] = L4_3
    L3_3 = Debug
    L4_3 = "pedCollectCards"
    L5_3 = "Cards collected"
    L6_3 = A0_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2.pedCollectCards = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = Debug
    L2_3 = "pedDealAllCards"
    L3_3 = "Dealing all cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.pedEnsureDictionary
    L1_3()
    L1_3 = 1
    L2_3 = 4
    L3_3 = 1
    for L4_3 = L1_3, L2_3, L3_3 do
      L5_3 = A0_3[L4_3]
      if nil ~= L5_3 then
        L5_3 = L6_2.dealCards
        L6_3 = L4_3
        L7_3 = A0_3[L4_3]
        L5_3(L6_3, L7_3)
      end
    end
    L1_3 = Debug
    L2_3 = "pedDealAllCards"
    L3_3 = "All cards dealt"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L6_2.pedDealAllCards = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L1_3 = Debug
    L2_3 = "pedDealCardsSelf"
    L3_3 = "Dealing cards to self"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.pedEnsureDictionary
    L1_3()
    L1_3 = IsPedMale
    L2_3 = L6_2.ped
    L1_3 = L1_3(L2_3)
    if L1_3 then
      L1_3 = "deck_deal_self"
      if L1_3 then
        goto lbl_24
      end
    end
    L1_3 = "female_deck_deal_self"
    ::lbl_24::
    L2_3 = GetInitialAnimOffsets
    L3_3 = L1_1
    L4_3 = L1_3
    L5_3 = L6_2.coords
    L6_3 = 0.0
    L7_3 = 0.0
    L8_3 = L6_2.heading
    L2_3, L3_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
    L4_3 = {}
    L5_3 = TaskPlayAnimAdvanced
    L6_3 = L6_2.ped
    L7_3 = L1_1
    L8_3 = L1_3
    L9_3 = L2_3
    L10_3 = L3_3
    L11_3 = 3.0
    L12_3 = 3.0
    L13_3 = -1
    L14_3 = 2
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    L5_3 = 1
    L6_3 = 3
    L7_3 = 1
    for L8_3 = L5_3, L6_3, L7_3 do
      L9_3 = A0_3[L8_3]
      if nil ~= L9_3 then
        L9_3 = L6_2.createCard
        L10_3 = PokerCardModels
        L11_3 = A0_3[L8_3]
        L10_3 = L10_3[L11_3]
        L9_3 = L9_3(L10_3)
        L10_3 = "deck_deal_self_card_"
        L11_3 = PokerLetterIndex
        L11_3 = L11_3[L8_3]
        L10_3 = L10_3 .. L11_3
        L11_3 = table
        L11_3 = L11_3.insert
        L12_3 = L6_2.chairCards
        L12_3 = L12_3.dealer
        L13_3 = L9_3
        L11_3(L12_3, L13_3)
        L11_3 = table
        L11_3 = L11_3.insert
        L12_3 = L4_3
        L13_3 = L9_3
        L11_3(L12_3, L13_3)
        L11_3 = SetEntityVisible
        L12_3 = L9_3
        L13_3 = false
        L11_3(L12_3, L13_3)
        L11_3 = GetInitialAnimOffsets
        L12_3 = L1_1
        L13_3 = L10_3
        L14_3 = L6_2.coords
        L15_3 = 0.0
        L16_3 = 0.0
        L17_3 = L6_2.heading
        L11_3, L12_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
        L13_3 = SetEntityCoordsNoOffset
        L14_3 = L9_3
        L15_3 = L11_3
        L13_3(L14_3, L15_3)
        L13_3 = SetEntityRotation
        L14_3 = L9_3
        L15_3 = L12_3
        L13_3(L14_3, L15_3)
        L13_3 = PlayEntityAnim
        L14_3 = L9_3
        L15_3 = L10_3
        L16_3 = L1_1
        L17_3 = 5000.0
        L18_3 = false
        L19_3 = false
        L20_3 = 0
        L21_3 = 0.0
        L22_3 = 0
        L13_3(L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3)
      end
    end
    L5_3 = WaitTaskAnimToReachTime
    L6_3 = L6_2.ped
    L7_3 = L1_1
    L8_3 = L1_3
    L9_3 = 0.2
    L10_3 = 3000
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    L5_3 = IN_CASINO
    if L5_3 then
      L5_3 = L6_2.pedPickupDeck
      if L5_3 then
        goto lbl_118
      end
    end
    do return end
    ::lbl_118::
    L5_3 = pairs
    L6_3 = L4_3
    L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
    for L9_3, L10_3 in L5_3, L6_3, L7_3, L8_3 do
      L11_3 = SetEntityVisible
      L12_3 = L10_3
      L13_3 = true
      L11_3(L12_3, L13_3)
    end
    L5_3 = WaitTaskAnimToReachTime
    L6_3 = L6_2.ped
    L7_3 = L1_1
    L8_3 = L1_3
    L9_3 = 0.85
    L10_3 = 3000
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    L5_3 = Debug
    L6_3 = "pedDealCardsSelf"
    L7_3 = "Cards dealt to self"
    L8_3 = A0_3
    L5_3(L6_3, L7_3, L8_3)
  end
  L6_2.pedDealCardsSelf = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L0_3 = Debug
    L1_3 = "pedUncoverCardsSelf"
    L2_3 = "Uncovering cards"
    L0_3(L1_3, L2_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = L6_2.createCard
      if L0_3 then
        goto lbl_12
      end
    end
    do return end
    ::lbl_12::
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = IsPedMale
    L1_3 = L6_2.ped
    L0_3 = L0_3(L1_3)
    if L0_3 then
      L0_3 = "reveal_self"
      if L0_3 then
        goto lbl_23
      end
    end
    L0_3 = "female_reveal_self"
    ::lbl_23::
    L1_3 = nil
    L2_3 = PlayFacialAnim
    L3_3 = L6_2.ped
    L4_3 = L0_3
    L5_3 = "_facial"
    L4_3 = L4_3 .. L5_3
    L5_3 = L1_1
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = GetInitialAnimOffsets
      L3_3 = L1_1
      L4_3 = L0_3
      L5_3 = L6_2.coords
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = L6_2.heading
      L2_3, L3_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
      L4_3 = TaskPlayAnimAdvanced
      L5_3 = L6_2.ped
      L6_3 = L1_1
      L7_3 = L0_3
      L8_3 = L2_3
      L9_3 = L3_3
      L10_3 = 3.0
      L11_3 = 3.0
      L12_3 = -1
      L13_3 = 2
      L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
    else
      L2_3 = CreateSynchronizedScene
      L3_3 = L6_2.coords
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = L6_2.heading
      L7_3 = 2
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
      L1_3 = L2_3
      L2_3 = TaskSynchronizedScene
      L3_3 = L6_2.ped
      L4_3 = L1_3
      L5_3 = L1_1
      L6_3 = L0_3
      L7_3 = 2.0
      L8_3 = -1.5
      L9_3 = 13
      L10_3 = 16
      L11_3 = 2.0
      L12_3 = 0
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
    end
    L2_3 = 1
    L3_3 = 3
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = L6_2.chairCards
      L6_3 = L6_3.dealer
      if nil ~= L6_3 then
        L6_3 = L6_2.chairCards
        L6_3 = L6_3.dealer
        L6_3 = L6_3[L5_3]
        if nil ~= L6_3 then
          L6_3 = "reveal_self_card_"
          L7_3 = PokerLetterIndex
          L7_3 = L7_3[L5_3]
          L6_3 = L6_3 .. L7_3
          L7_3 = L6_2.chairCards
          L7_3 = L7_3.dealer
          L7_3 = L7_3[L5_3]
          L8_3 = L6_2.automated
          if L8_3 then
            L8_3 = L6_2.createDuplicate
            L9_3 = L7_3
            L8_3 = L8_3(L9_3)
            L9_3 = L6_2.deleteCard
            L10_3 = L7_3
            L9_3(L10_3)
            L9_3 = L6_2.chairCards
            L9_3 = L9_3.dealer
            L9_3[L5_3] = L8_3
            L9_3 = Wait
            L10_3 = 0
            L9_3(L10_3)
            L9_3 = GetInitialAnimOffsets
            L10_3 = L1_1
            L11_3 = L6_3
            L12_3 = L6_2.coords
            L13_3 = 0.0
            L14_3 = 0.0
            L15_3 = L6_2.heading
            L9_3, L10_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
            L11_3 = SetEntityCoordsNoOffset
            L12_3 = L8_3
            L13_3 = L9_3
            L14_3 = false
            L15_3 = false
            L16_3 = false
            L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
            L11_3 = SetEntityRotation
            L12_3 = L8_3
            L13_3 = L10_3
            L14_3 = 2
            L15_3 = false
            L11_3(L12_3, L13_3, L14_3, L15_3)
            L11_3 = PlayEntityAnim
            L12_3 = L8_3
            L13_3 = L6_3
            L14_3 = L1_1
            L15_3 = 5000.0
            L16_3 = false
            L17_3 = false
            L18_3 = 0
            L19_3 = 0.0
            L20_3 = 0
            L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
          else
            L8_3 = PlaySynchronizedEntityAnim
            L9_3 = L7_3
            L10_3 = L1_3
            L11_3 = L6_3
            L12_3 = L1_1
            L13_3 = 5000.0
            L14_3 = 0
            L15_3 = 0
            L16_3 = 5000.0
            L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
          end
        end
      end
    end
    L2_3 = L6_2.automated
    if L2_3 then
      L2_3 = WaitTaskAnimToReachTime
      L3_3 = L6_2.ped
      L4_3 = L1_1
      L5_3 = L0_3
      L6_3 = 0.9
      L7_3 = 3000
      L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
    else
      L2_3 = SetSynchronizedScenePhase
      L3_3 = L1_3
      L4_3 = 0.0
      L2_3(L3_3, L4_3)
      L2_3 = WaitSynchronizedSceneToReachTime
      L3_3 = L1_3
      L4_3 = 0.9
      L5_3 = 3000
      L6_3 = 100
      L2_3(L3_3, L4_3, L5_3, L6_3)
    end
    L2_3 = Debug
    L3_3 = "pedUncoverCardsSelf"
    L4_3 = "Cards uncovered"
    L2_3(L3_3, L4_3)
  end
  L6_2.pedUncoverCardsSelf = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
    L1_3 = Debug
    L2_3 = "pedUncoverChairCards"
    L3_3 = "Uncovering chair cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.pedEnsureDictionary
    L1_3()
    L1_3 = IsPedMale
    L2_3 = L6_2.ped
    L1_3 = L1_3(L2_3)
    if L1_3 then
      L1_3 = ""
      if L1_3 then
        goto lbl_24
      end
    end
    L1_3 = "female_"
    ::lbl_24::
    L2_3 = nil
    L3_3 = L6_2.syncedState
    L3_3 = L3_3.cardStates
    L3_3 = L3_3[A0_3]
    if nil ~= L3_3 then
      L3_3 = L6_2.syncedState
      L3_3 = L3_3.cardStates
      L3_3 = L3_3[A0_3]
      if 9 ~= L3_3 then
        goto lbl_53
      end
    end
    L3_3 = L1_3
    L4_3 = "reveal_blind_p"
    L5_3 = string
    L5_3 = L5_3.format
    L6_3 = "%02d"
    L7_3 = A0_3
    L5_3 = L5_3(L6_3, L7_3)
    L3_3 = L3_3 .. L4_3 .. L5_3
    L1_3 = L3_3
    L3_3 = "reveal_blind_p"
    L4_3 = string
    L4_3 = L4_3.format
    L5_3 = "%02d"
    L6_3 = A0_3
    L4_3 = L4_3(L5_3, L6_3)
    L3_3 = L3_3 .. L4_3
    L2_3 = L3_3
    goto lbl_93
    ::lbl_53::
    L3_3 = L6_2.syncedState
    L3_3 = L3_3.cardStates
    L3_3 = L3_3[A0_3]
    if 1 == L3_3 then
      L3_3 = L1_3
      L4_3 = "reveal_played_p"
      L5_3 = string
      L5_3 = L5_3.format
      L6_3 = "%02d"
      L7_3 = A0_3
      L5_3 = L5_3(L6_3, L7_3)
      L3_3 = L3_3 .. L4_3 .. L5_3
      L1_3 = L3_3
      L3_3 = "reveal_played_p"
      L4_3 = string
      L4_3 = L4_3.format
      L5_3 = "%02d"
      L6_3 = A0_3
      L4_3 = L4_3(L5_3, L6_3)
      L3_3 = L3_3 .. L4_3
      L2_3 = L3_3
    else
      L3_3 = L1_3
      L4_3 = "reveal_folded_p"
      L5_3 = string
      L5_3 = L5_3.format
      L6_3 = "%02d"
      L7_3 = A0_3
      L5_3 = L5_3(L6_3, L7_3)
      L3_3 = L3_3 .. L4_3 .. L5_3
      L1_3 = L3_3
      L3_3 = "reveal_folded_p"
      L4_3 = string
      L4_3 = L4_3.format
      L5_3 = "%02d"
      L6_3 = A0_3
      L4_3 = L4_3(L5_3, L6_3)
      L3_3 = L3_3 .. L4_3
      L2_3 = L3_3
    end
    ::lbl_93::
    L3_3 = L1_3
    L4_3 = "_facial"
    L3_3 = L3_3 .. L4_3
    L4_3 = nil
    L5_3 = PlayFacialAnim
    L6_3 = L6_2.ped
    L7_3 = L3_3
    L8_3 = L1_1
    L5_3(L6_3, L7_3, L8_3)
    L5_3 = L6_2.automated
    if L5_3 then
      L5_3 = GetInitialAnimOffsets
      L6_3 = L1_1
      L7_3 = L1_3
      L8_3 = L6_2.coords
      L9_3 = 0.0
      L10_3 = 0.0
      L11_3 = L6_2.heading
      L5_3, L6_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      L7_3 = TaskPlayAnimAdvanced
      L8_3 = L6_2.ped
      L9_3 = L1_1
      L10_3 = L1_3
      L11_3 = L5_3
      L12_3 = L6_3
      L13_3 = 3.0
      L14_3 = 3.0
      L15_3 = -1
      L16_3 = 2
      L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
    else
      L5_3 = CreateSynchronizedScene
      L6_3 = L6_2.coords
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = L6_2.heading
      L10_3 = 2
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
      L4_3 = L5_3
      L5_3 = TaskSynchronizedScene
      L6_3 = L6_2.ped
      L7_3 = L4_3
      L8_3 = L1_1
      L9_3 = L1_3
      L10_3 = 2.0
      L11_3 = -1.5
      L12_3 = 13
      L13_3 = 16
      L14_3 = 2.0
      L15_3 = 0
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L5_3 = 1
    L6_3 = 3
    L7_3 = 1
    for L8_3 = L5_3, L6_3, L7_3 do
      L9_3 = L6_2.chairCards
      L9_3 = L9_3[A0_3]
      if nil ~= L9_3 then
        L9_3 = L6_2.chairCards
        L9_3 = L9_3[A0_3]
        L9_3 = L9_3[L8_3]
        if nil ~= L9_3 then
          L9_3 = L2_3
          L10_3 = "_card_"
          L11_3 = PokerLetterIndex
          L11_3 = L11_3[L8_3]
          L9_3 = L9_3 .. L10_3 .. L11_3
          L10_3 = L6_2.chairCards
          L10_3 = L10_3[A0_3]
          L10_3 = L10_3[L8_3]
          L11_3 = L6_2.automated
          if L11_3 then
            L11_3 = GetInitialAnimOffsets
            L12_3 = L1_1
            L13_3 = L9_3
            L14_3 = L6_2.coords
            L15_3 = 0.0
            L16_3 = 0.0
            L17_3 = L6_2.heading
            L11_3, L12_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
            L13_3 = L6_2.createDuplicate
            L14_3 = L10_3
            L13_3 = L13_3(L14_3)
            L14_3 = L6_2.deleteCard
            L15_3 = L10_3
            L14_3(L15_3)
            L14_3 = L6_2.chairCards
            L14_3 = L14_3[A0_3]
            L14_3[L8_3] = L13_3
            L14_3 = Wait
            L15_3 = 0
            L14_3(L15_3)
            L14_3 = SetEntityCoordsNoOffset
            L15_3 = L13_3
            L16_3 = L11_3
            L14_3(L15_3, L16_3)
            L14_3 = SetEntityRotation
            L15_3 = L13_3
            L16_3 = L12_3
            L14_3(L15_3, L16_3)
            L14_3 = PlayEntityAnim
            L15_3 = L13_3
            L16_3 = L9_3
            L17_3 = L1_1
            L18_3 = 5000.0
            L19_3 = false
            L20_3 = true
            L21_3 = false
            L22_3 = 5000.0
            L23_3 = 0
            L14_3(L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3)
          else
            L11_3 = PlaySynchronizedEntityAnim
            L12_3 = L10_3
            L13_3 = L4_3
            L14_3 = L2_3
            L15_3 = "_card_"
            L16_3 = PokerLetterIndex
            L16_3 = L16_3[L8_3]
            L14_3 = L14_3 .. L15_3 .. L16_3
            L15_3 = L1_1
            L16_3 = 5000.0
            L17_3 = 0
            L18_3 = 0
            L19_3 = 5000.0
            L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
          end
        end
      end
    end
    L5_3 = WaitTaskAnimToReachTime
    L6_3 = L6_2.ped
    L7_3 = L1_1
    L8_3 = L1_3
    L9_3 = 0.9
    L10_3 = 3000
    L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    L5_3 = Debug
    L6_3 = "pedUncoverChairCards"
    L7_3 = "Chair cards uncovered"
    L8_3 = A0_3
    L5_3(L6_3, L7_3, L8_3)
  end
  L6_2.pedUncoverChairCards = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L0_3 = Debug
    L1_3 = "pedIdle"
    L2_3 = "Ped idling"
    L0_3(L1_3, L2_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = L6_2.createCard
      if L0_3 then
        goto lbl_12
      end
    end
    do return end
    ::lbl_12::
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = nil
    L1_3 = IsPedMale
    L2_3 = L6_2.ped
    L1_3 = L1_3(L2_3)
    if L1_3 then
      L1_3 = {}
      L2_3 = "idle"
      L3_3 = "idle_var_01"
      L4_3 = "idle_var_02"
      L5_3 = "idle_var_03"
      L6_3 = "idle_var_04"
      L7_3 = "idle_var_05"
      L1_3[1] = L2_3
      L1_3[2] = L3_3
      L1_3[3] = L4_3
      L1_3[4] = L5_3
      L1_3[5] = L6_3
      L1_3[6] = L7_3
      L0_3 = L1_3
    else
      L1_3 = {}
      L2_3 = "female_idle"
      L3_3 = "female_idle_var_01"
      L4_3 = "female_idle_var_02"
      L5_3 = "female_idle_var_03"
      L6_3 = "female_idle_var_04"
      L7_3 = "female_idle_var_05"
      L8_3 = "female_idle_var_06"
      L9_3 = "female_idle_var_07"
      L10_3 = "female_idle_var_08"
      L1_3[1] = L2_3
      L1_3[2] = L3_3
      L1_3[3] = L4_3
      L1_3[4] = L5_3
      L1_3[5] = L6_3
      L1_3[6] = L7_3
      L1_3[7] = L8_3
      L1_3[8] = L9_3
      L1_3[9] = L10_3
      L0_3 = L1_3
    end
    L1_3 = GetRandomItem
    L2_3 = L0_3
    L1_3 = L1_3(L2_3)
    L2_3 = TaskPlayAnim
    L3_3 = L6_2.ped
    L4_3 = L2_1
    L5_3 = L1_3
    L6_3 = 3.0
    L7_3 = 3.0
    L8_3 = -1
    L9_3 = 1
    L10_3 = 0
    L11_3 = true
    L12_3 = true
    L13_3 = true
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
    L2_3 = PlayFacialAnim
    L3_3 = L6_2.ped
    L4_3 = L1_3
    L5_3 = "_facial"
    L4_3 = L4_3 .. L5_3
    L5_3 = L2_1
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = Debug
    L3_3 = "pedIdle"
    L4_3 = "Ped idling..."
    L2_3(L3_3, L4_3)
  end
  L6_2.pedIdle = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
    L1_3 = Debug
    L2_3 = "foldCards"
    L3_3 = "Folding cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.chairPositions
    L1_3 = L1_3[A0_3]
    L2_3 = L6_2.chairCards
    L2_3 = L2_3[A0_3]
    L3_3 = nil
    if nil == L2_3 then
      return
    end
    L4_3 = L6_2.automated
    if not L4_3 then
      L4_3 = CreateSynchronizedScene
      L5_3 = L1_3.coords
      L6_3 = L1_3.rotation
      L7_3 = 2
      L4_3 = L4_3(L5_3, L6_3, L7_3)
      L3_3 = L4_3
    end
    L4_3 = pairs
    L5_3 = L6_2.chairCards
    L5_3 = L5_3[A0_3]
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = "cards_fold_card_"
      L11_3 = PokerLetterIndex
      L11_3 = L11_3[L8_3]
      L10_3 = L10_3 .. L11_3
      L11_3 = GetInitialAnimOffsets
      L12_3 = L3_1
      L13_3 = L10_3
      L14_3 = L1_3.coords
      L15_3 = 0.0
      L16_3 = 0.0
      L17_3 = L1_3.rotation
      L17_3 = L17_3.z
      L11_3, L12_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
      L13_3 = L6_2.automated
      if L13_3 then
        L13_3 = L6_2.createDuplicate
        L14_3 = L9_3
        L13_3 = L13_3(L14_3)
        L14_3 = L6_2.deleteCard
        L15_3 = L9_3
        L14_3(L15_3)
        L14_3 = L6_2.chairCards
        L14_3 = L14_3[A0_3]
        L14_3[L8_3] = L13_3
        L14_3 = Wait
        L15_3 = 0
        L14_3(L15_3)
        L14_3 = SetEntityCoordsNoOffset
        L15_3 = L13_3
        L16_3 = L11_3
        L14_3(L15_3, L16_3)
        L14_3 = SetEntityRotation
        L15_3 = L13_3
        L16_3 = L12_3
        L14_3(L15_3, L16_3)
        L14_3 = PlayEntityAnim
        L15_3 = L13_3
        L16_3 = L10_3
        L17_3 = L3_1
        L18_3 = 50000.0
        L19_3 = false
        L20_3 = true
        L21_3 = false
        L22_3 = 5000.0
        L23_3 = 0
        L14_3(L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3)
      else
        L13_3 = PlaySynchronizedEntityAnim
        L14_3 = L9_3
        L15_3 = L3_3
        L16_3 = "cards_fold_card_"
        L17_3 = PokerLetterIndex
        L17_3 = L17_3[L8_3]
        L16_3 = L16_3 .. L17_3
        L17_3 = L3_1
        L18_3 = 5000.0
        L19_3 = 0
        L20_3 = 0
        L21_3 = 5000.0
        L13_3(L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3)
      end
    end
    L4_3 = L6_2.syncedState
    L4_3 = L4_3.cardStates
    L4_3[A0_3] = 0
    L4_3 = Debug
    L5_3 = "foldCards"
    L6_3 = "Cards folded"
    L7_3 = A0_3
    L4_3(L5_3, L6_3, L7_3)
  end
  L6_2.foldCards = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
    L1_3 = Debug
    L2_3 = "acceptAndPlay"
    L3_3 = "Accepting and playing"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.chairPositions
    L1_3 = L1_3[A0_3]
    L2_3 = L6_2.chairCards
    L2_3 = L2_3[A0_3]
    if nil == L2_3 then
      return
    end
    L3_3 = nil
    L4_3 = L6_2.automated
    if not L4_3 then
      L4_3 = CreateSynchronizedScene
      L5_3 = L1_3.coords
      L6_3 = L1_3.rotation
      L7_3 = 2
      L4_3 = L4_3(L5_3, L6_3, L7_3)
      L3_3 = L4_3
    end
    L4_3 = pairs
    L5_3 = L6_2.chairCards
    L5_3 = L5_3[A0_3]
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = "cards_play_card_"
      L11_3 = PokerLetterIndex
      L11_3 = L11_3[L8_3]
      L10_3 = L10_3 .. L11_3
      L11_3 = GetInitialAnimOffsets
      L12_3 = L3_1
      L13_3 = L10_3
      L14_3 = L1_3.coords
      L15_3 = 0.0
      L16_3 = 0.0
      L17_3 = L1_3.rotation
      L17_3 = L17_3.z
      L11_3, L12_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
      L13_3 = L6_2.automated
      if L13_3 then
        L13_3 = L6_2.createDuplicate
        L14_3 = L9_3
        L13_3 = L13_3(L14_3)
        L14_3 = L6_2.deleteCard
        L15_3 = L9_3
        L14_3(L15_3)
        L14_3 = L6_2.chairCards
        L14_3 = L14_3[A0_3]
        L14_3[L8_3] = L13_3
        L14_3 = Wait
        L15_3 = 0
        L14_3(L15_3)
        L14_3 = SetEntityCoordsNoOffset
        L15_3 = L13_3
        L16_3 = L11_3
        L14_3(L15_3, L16_3)
        L14_3 = SetEntityRotation
        L15_3 = L13_3
        L16_3 = L12_3
        L14_3(L15_3, L16_3)
        L14_3 = PlayEntityAnim
        L15_3 = L13_3
        L16_3 = L10_3
        L17_3 = L3_1
        L18_3 = 50000.0
        L19_3 = false
        L20_3 = true
        L21_3 = false
        L22_3 = 5000.0
        L23_3 = 0
        L14_3(L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3)
      else
        L13_3 = PlaySynchronizedEntityAnim
        L14_3 = L9_3
        L15_3 = L3_3
        L16_3 = "cards_play_card_"
        L17_3 = PokerLetterIndex
        L17_3 = L17_3[L8_3]
        L16_3 = L16_3 .. L17_3
        L17_3 = L3_1
        L18_3 = -6.0
        L19_3 = 0
        L20_3 = 0
        L21_3 = 6.0
        L13_3(L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3)
      end
    end
    L4_3 = L6_2.syncedState
    L4_3 = L4_3.cardStates
    L4_3[A0_3] = 1
    L4_3 = Debug
    L5_3 = "acceptAndPlay"
    L6_3 = "Accepted and played"
    L7_3 = A0_3
    L4_3(L5_3, L6_3, L7_3)
  end
  L6_2.acceptAndPlay = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3
    L1_3 = Debug
    L2_3 = "pickupCards"
    L3_3 = "Picking up cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.chairCards
    L1_3 = L1_3[A0_3]
    if nil == L1_3 then
      return
    end
    L1_3 = L6_2.chairPositions
    L1_3 = L1_3[A0_3]
    L2_3 = nil
    L3_3 = L6_2.automated
    if not L3_3 then
      L3_3 = CreateSynchronizedScene
      L4_3 = L1_3.coords
      L5_3 = L1_3.rotation
      L6_3 = 2
      L3_3 = L3_3(L4_3, L5_3, L6_3)
      L2_3 = L3_3
    end
    L3_3 = pairs
    L4_3 = L6_2.chairCards
    L4_3 = L4_3[A0_3]
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = "cards_pickup_card_"
      L10_3 = PokerLetterIndex
      L10_3 = L10_3[L7_3]
      L9_3 = L9_3 .. L10_3
      L10_3 = L6_2.automated
      if L10_3 then
        L10_3 = GetInitialAnimOffsets
        L11_3 = L3_1
        L12_3 = L9_3
        L13_3 = L1_3.coords
        L14_3 = 0.0
        L15_3 = 0.0
        L16_3 = L1_3.rotation
        L16_3 = L16_3.z
        L10_3, L11_3 = L10_3(L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
        L12_3 = SetEntityCoordsNoOffset
        L13_3 = L8_3
        L14_3 = L10_3
        L12_3(L13_3, L14_3)
        L12_3 = SetEntityRotation
        L13_3 = L8_3
        L14_3 = L11_3
        L12_3(L13_3, L14_3)
        L12_3 = PlayEntityAnim
        L13_3 = L8_3
        L14_3 = L9_3
        L15_3 = L3_1
        L16_3 = 5000.0
        L17_3 = false
        L18_3 = true
        L19_3 = false
        L20_3 = 5000.0
        L21_3 = 0
        L12_3(L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3)
      else
        L10_3 = PlaySynchronizedEntityAnim
        L11_3 = L8_3
        L12_3 = L2_3
        L13_3 = "cards_pickup_card_"
        L14_3 = PokerLetterIndex
        L14_3 = L14_3[L7_3]
        L13_3 = L13_3 .. L14_3
        L14_3 = L3_1
        L15_3 = 5000.0
        L16_3 = 0
        L17_3 = 0
        L18_3 = 5000.0
        L10_3(L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3)
      end
    end
    L3_3 = Debug
    L4_3 = "pickupCards"
    L5_3 = "Cards picked up"
    L6_3 = A0_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2.pickupCards = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L1_3 = Debug
    L2_3 = "holdCards"
    L3_3 = "Holding cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.createCard
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.getChairCards
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    if nil == L1_3 then
      return
    end
    L2_3 = L6_2.chairPositions
    L2_3 = L2_3[A0_3]
    L3_3 = nil
    L4_3 = L6_2.automated
    if not L4_3 then
      L4_3 = CreateSynchronizedScene
      L5_3 = L2_3.coords
      L6_3 = L2_3.rotation
      L7_3 = 2
      L4_3 = L4_3(L5_3, L6_3, L7_3)
      L3_3 = L4_3
    end
    L4_3 = 1
    L5_3 = 3
    L6_3 = 1
    for L7_3 = L4_3, L5_3, L6_3 do
      L8_3 = L1_3[L7_3]
      if nil ~= L8_3 then
        L8_3 = "cards_idle_card_"
        L9_3 = PokerLetterIndex
        L9_3 = L9_3[L7_3]
        L8_3 = L8_3 .. L9_3
        L9_3 = L6_2.automated
        if L9_3 then
          L9_3 = GetInitialAnimOffsets
          L10_3 = L3_1
          L11_3 = L8_3
          L12_3 = L2_3.coords
          L13_3 = 0.0
          L14_3 = 0.0
          L15_3 = L2_3.rotation
          L15_3 = L15_3.z
          L9_3, L10_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
          L11_3 = SetEntityCoordsNoOffset
          L12_3 = L1_3[L7_3]
          L13_3 = L9_3
          L11_3(L12_3, L13_3)
          L11_3 = SetEntityRotation
          L12_3 = L1_3[L7_3]
          L13_3 = L10_3
          L11_3(L12_3, L13_3)
          L11_3 = PlayEntityAnim
          L12_3 = L1_3[L7_3]
          L13_3 = L8_3
          L14_3 = L3_1
          L15_3 = 5000.0
          L16_3 = true
          L17_3 = true
          L18_3 = false
          L19_3 = 5000.0
          L20_3 = 0
          L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
        else
          L9_3 = PlaySynchronizedEntityAnim
          L10_3 = L1_3[L7_3]
          L11_3 = L3_3
          L12_3 = L8_3
          L13_3 = L3_1
          L14_3 = 5000.0
          L15_3 = 0
          L16_3 = 0
          L17_3 = 5000.0
          L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
        end
      end
    end
    L4_3 = L6_2.automated
    if not L4_3 then
      L4_3 = SetSynchronizedSceneLooped
      L5_3 = L3_3
      L6_3 = true
      L4_3(L5_3, L6_3)
    end
    L4_3 = Debug
    L5_3 = "holdCards"
    L6_3 = "Cards held"
    L7_3 = A0_3
    L4_3(L5_3, L6_3, L7_3)
  end
  L6_2.holdCards = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L0_3 = Debug
    L1_3 = "deleteRoundObjects"
    L2_3 = "Deleting round objects"
    L0_3(L1_3, L2_3)
    L0_3 = pairs
    L1_3 = L6_2.allCards
    L0_3, L1_3, L2_3, L3_3 = L0_3(L1_3)
    for L4_3, L5_3 in L0_3, L1_3, L2_3, L3_3 do
      L6_3 = ForceDeleteEntity
      L7_3 = L5_3
      L6_3(L7_3)
    end
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = pairs
      L5_3 = L6_2.chairChips
      L5_3 = L5_3[L3_3]
      L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
      for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
        L10_3 = ForceDeleteEntity
        L11_3 = L9_3
        L10_3(L11_3)
      end
      L4_3 = L6_2.chairChips
      L5_3 = {}
      L4_3[L3_3] = L5_3
    end
    L0_3 = {}
    L6_2.allCards = L0_3
    L0_3 = {}
    L6_2.chairCards = L0_3
    L0_3 = {}
    L6_2.chairChips = L0_3
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = L6_2.chairCards
      L5_3 = {}
      L4_3[L3_3] = L5_3
      L4_3 = L6_2.chairChips
      L5_3 = {}
      L4_3[L3_3] = L5_3
    end
    L0_3 = L6_2.chairCards
    L1_3 = {}
    L0_3.dealer = L1_3
    L0_3 = L6_2.syncedState
    L1_3 = {}
    L0_3.cardStates = L1_3
    L0_3 = L6_2.syncedState
    L1_3 = {}
    L0_3.cardsInHands = L1_3
    L0_3 = Debug
    L1_3 = "deleteRoundObjects"
    L2_3 = "Round objects deleted"
    L0_3(L1_3, L2_3)
  end
  L6_2.deleteRoundObjects = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L0_3 = Debug
    L1_3 = "deleteAllCards"
    L2_3 = "Deleting all cards"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.allCards
    if L0_3 then
      L0_3 = pairs
      L1_3 = L6_2.allCards
      L0_3, L1_3, L2_3, L3_3 = L0_3(L1_3)
      for L4_3, L5_3 in L0_3, L1_3, L2_3, L3_3 do
        L6_3 = ForceDeleteEntity
        L7_3 = L5_3
        L6_3(L7_3)
      end
      L0_3 = {}
      L6_2.allCards = L0_3
    end
    L0_3 = L6_2.chairCards
    if L0_3 then
      L0_3 = 1
      L1_3 = 4
      L2_3 = 1
      for L3_3 = L0_3, L1_3, L2_3 do
        L4_3 = L6_2.chairCards
        L5_3 = {}
        L4_3[L3_3] = L5_3
      end
      L0_3 = L6_2.chairCards
      L1_3 = {}
      L0_3.dealer = L1_3
    end
    L0_3 = Debug
    L1_3 = "deleteAllCards"
    L2_3 = "All cards deleted"
    L0_3(L1_3, L2_3)
  end
  L6_2.deleteAllCards = L8_2
  function L8_2(A0_3, A1_3, A2_3, A3_3, A4_3, A5_3)
    local L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3
    L6_3 = Debug
    L7_3 = "automatePedAnimation"
    L8_3 = "Automating ped animation"
    L9_3 = A0_3
    L10_3 = A1_3
    L11_3 = A2_3
    L12_3 = A3_3
    L13_3 = A4_3
    L14_3 = A5_3
    L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    L6_3 = L6_2.pedEnsureDictionary
    L6_3()
    L6_3 = tonumber
    L7_3 = A0_3
    L6_3 = L6_3(L7_3)
    if L6_3 and A0_3 <= 4 then
      L6_3 = L6_2.ambientPeds
      L6_3 = L6_3[A0_3]
      if L6_3 then
        goto lbl_25
      end
    end
    L6_3 = A0_3
    ::lbl_25::
    L7_3 = GetInitialAnimOffsets
    L8_3 = A3_3
    L9_3 = A4_3
    L10_3 = A1_3
    L11_3 = A2_3
    L7_3, L8_3 = L7_3(L8_3, L9_3, L10_3, L11_3)
    L9_3 = IsPedMale
    L10_3 = L6_3
    L9_3 = L9_3(L10_3)
    if L9_3 then
      L9_3 = 0.0
      if L9_3 then
        goto lbl_40
      end
    end
    L9_3 = 0.07
    ::lbl_40::
    L10_3 = vector3
    L11_3 = L7_3.x
    L12_3 = L7_3.y
    L13_3 = L7_3.z
    L13_3 = L13_3 + L9_3
    L10_3 = L10_3(L11_3, L12_3, L13_3)
    L7_3 = L10_3
    L10_3 = RequestAnimDictAndWait
    L11_3 = A3_3
    L10_3(L11_3)
    L10_3 = GetAnimDuration
    L11_3 = A3_3
    L12_3 = A4_3
    L10_3 = L10_3(L11_3, L12_3)
    L10_3 = L10_3 * 1000
    L11_3 = SetEntityCoordsNoOffset
    L12_3 = L6_3
    L13_3 = L7_3
    L14_3 = false
    L15_3 = false
    L16_3 = false
    L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
    L11_3 = SetEntityRotation
    L12_3 = L6_3
    L13_3 = L8_3
    L11_3(L12_3, L13_3)
    L11_3 = TaskPlayAnim
    L12_3 = L6_3
    L13_3 = A3_3
    L14_3 = A4_3
    L15_3 = 8.0
    L16_3 = 8.0
    L17_3 = L10_3
    if A5_3 then
      L18_3 = 1
      if L18_3 then
        goto lbl_81
      end
    end
    L18_3 = 0
    ::lbl_81::
    L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3)
    L11_3 = Debug
    L12_3 = "automatePedAnimation"
    L13_3 = "Ped animation automated"
    L14_3 = A0_3
    L15_3 = A1_3
    L16_3 = A2_3
    L17_3 = A3_3
    L18_3 = A4_3
    L19_3 = A5_3
    L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
  end
  L6_2.automatePedAnimation = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = Debug
    L2_3 = "automateMakeIdle"
    L3_3 = "Automating idle"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = IN_CASINO
    if L1_3 then
      L1_3 = L6_2.pedPickupDeck
      if L1_3 then
        goto lbl_13
      end
    end
    do return end
    ::lbl_13::
    L1_3 = L6_2.ambientPeds
    L1_3 = L1_3[A0_3]
    L2_3 = "idle_var_01"
    L3_3 = IsPedMale
    L4_3 = L1_3
    L3_3 = L3_3(L4_3)
    if L3_3 then
      L3_3 = "idle_var_"
      L4_3 = string
      L4_3 = L4_3.format
      L5_3 = "%02d"
      L6_3 = RandomNumber
      L7_3 = 1
      L8_3 = 13
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3)
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
      L3_3 = L3_3 .. L4_3
      L2_3 = L3_3
    else
      L3_3 = "female_idle_var_"
      L4_3 = string
      L4_3 = L4_3.format
      L5_3 = "%02d"
      L6_3 = RandomNumber
      L7_3 = 1
      L8_3 = 8
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3)
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
      L3_3 = L3_3 .. L4_3
      L2_3 = L3_3
    end
    L3_3 = L6_2.automatePedAnimation
    L4_3 = A0_3
    L5_3 = L6_2.chairPositions
    L5_3 = L5_3[A0_3]
    L5_3 = L5_3.coords
    L6_3 = L6_2.chairPositions
    L6_3 = L6_3[A0_3]
    L6_3 = L6_3.rotation
    L7_3 = L4_1
    L8_3 = L2_3
    L9_3 = true
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
    L3_3 = Debug
    L4_3 = "automateMakeIdle"
    L5_3 = "Idle automated"
    L6_3 = A0_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2.automateMakeIdle = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = Debug
    L1_3 = "automateEveryoneIdle"
    L2_3 = "Automating everyone idle"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.automateMakeIdle
    if not L0_3 then
      return
    end
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = L6_2.automateMakeIdle
      L5_3 = L3_3
      L4_3(L5_3)
    end
    L0_3 = Debug
    L1_3 = "automateEveryoneIdle"
    L2_3 = "Everyone idle automated"
    L0_3(L1_3, L2_3)
  end
  L6_2.automateEveryoneIdle = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = Debug
    L2_3 = "automateGrabCards"
    L3_3 = "Automating grab cards"
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = L6_2.syncedState
    L1_3 = L1_3.cardsInHands
    L1_3[A0_3] = true
    L1_3 = L6_2.chairPositions
    L1_3 = L1_3[A0_3]
    L2_3 = L6_2.automatePedAnimation
    L3_3 = A0_3
    L4_3 = L1_3.coords
    L5_3 = L1_3.rotation
    L6_3 = L3_1
    L7_3 = "cards_pickup"
    L8_3 = false
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
    L3_3 = L6_2.pickupCards
    L4_3 = A0_3
    L3_3(L4_3)
    L3_3 = Wait
    L4_3 = 2000
    L3_3(L4_3)
    L3_3 = L6_2.automatePedAnimation
    if L3_3 then
      L3_3 = L6_2.automatePedAnimation
      L4_3 = A0_3
      L5_3 = L1_3.coords
      L6_3 = L1_3.rotation
      L7_3 = L3_1
      L8_3 = "cards_idle"
      L9_3 = true
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
    end
    L3_3 = Debug
    L4_3 = "automateGrabCards"
    L5_3 = "Grab cards automated"
    L6_3 = A0_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2.automateGrabCards = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L0_3 = Debug
    L1_3 = "automateRound"
    L2_3 = "Automating round"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.pedEnsureDictionary
    L0_3()
    L0_3 = RequestAnimDictAndWait
    L1_3 = L3_1
    L0_3(L1_3)
    L0_3 = Wait
    L1_3 = RandomNumber
    L2_3 = 300
    L3_3 = 3000
    L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L1_3(L2_3, L3_3)
    L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
    L0_3 = {}
    L1_3 = 0
    L2_3 = {}
    L3_3 = 0
    L4_3 = 0
    L5_3 = 0
    L6_3 = 0
    L2_3[1] = L3_3
    L2_3[2] = L4_3
    L2_3[3] = L5_3
    L2_3[4] = L6_3
    L3_3 = 1
    L4_3 = 5
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = {}
      L8_3 = RandomNumber
      L9_3 = 1
      L10_3 = 52
      L8_3 = L8_3(L9_3, L10_3)
      L9_3 = RandomNumber
      L10_3 = 1
      L11_3 = 52
      L9_3 = L9_3(L10_3, L11_3)
      L10_3 = RandomNumber
      L11_3 = 1
      L12_3 = 52
      L10_3 = L10_3(L11_3, L12_3)
      L11_3 = RandomNumber
      L12_3 = 1
      L13_3 = 52
      L11_3, L12_3, L13_3 = L11_3(L12_3, L13_3)
      L7_3[1] = L8_3
      L7_3[2] = L9_3
      L7_3[3] = L10_3
      L7_3[4] = L11_3
      L7_3[5] = L12_3
      L7_3[6] = L13_3
      L0_3[L6_3] = L7_3
    end
    L3_3 = 1
    L4_3 = 4
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = CreateThread
      function L8_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
        L0_4 = Wait
        L1_4 = RandomNumber
        L2_4 = 200
        L3_4 = 3000
        L1_4, L2_4, L3_4, L4_4, L5_4, L6_4 = L1_4(L2_4, L3_4)
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4)
        L1_4 = L6_3
        L0_4 = L2_3
        L2_4 = RandomNumber
        L3_4 = 10
        L4_4 = 500
        L2_4 = L2_4(L3_4, L4_4)
        L0_4[L1_4] = L2_4
        L0_4 = IN_CASINO
        if L0_4 then
          L0_4 = L6_2.pedPickupDeck
          if L0_4 then
            goto lbl_21
          end
        end
        do return end
        ::lbl_21::
        L0_4 = L37_1
        L1_4 = L6_2.ambientPeds
        L2_4 = L6_3
        L1_4 = L1_4[L2_4]
        L2_4 = L6_2
        L3_4 = L6_3
        L5_4 = L6_3
        L4_4 = L2_3
        L4_4 = L4_4[L5_4]
        L5_4 = 1
        L6_4 = true
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4)
        L0_4 = L1_3
        L0_4 = L0_4 + 1
        L1_3 = L0_4
      end
      L9_3 = "Playing ped bet animation poker"
      L7_3(L8_3, L9_3)
    end
    while true do
      L3_3 = IN_CASINO
      if not (L3_3 and L1_3 < 4) then
        break
      end
      L3_3 = Wait
      L4_3 = 100
      L3_3(L4_3)
    end
    L3_3 = IN_CASINO
    if L3_3 then
      L3_3 = L6_2.pokerPedSay
      if L3_3 then
        goto lbl_77
      end
    end
    do return end
    ::lbl_77::
    L3_3 = L6_2.pokerPedSay
    L4_3 = "MINIGAME_DEALER_CLOSED_BETS"
    L3_3(L4_3)
    L3_3 = L6_2.pedPickupDeck
    L3_3()
    L3_3 = L6_2.pedShuffle
    L3_3()
    L3_3 = L6_2.deleteAllCards
    L3_3()
    L3_3 = L6_2.pedDealAllCards
    L4_3 = L0_3
    L3_3(L4_3)
    L3_3 = L0_3[5]
    if nil ~= L3_3 then
      L3_3 = L0_3[5]
      L0_3.dealer = L3_3
      L3_3 = L6_2.pedDealCardsSelf
      L4_3 = L0_3.dealer
      L3_3(L4_3)
    end
    L3_3 = L6_2.pedPutDownCardPile
    L3_3()
    L3_3 = L6_2.pedIdle
    L3_3()
    L1_3 = 0
    L3_3 = 1
    L4_3 = 4
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = CreateThread
      function L8_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
        L0_4 = Wait
        L1_4 = RandomNumber
        L2_4 = 200
        L3_4 = 3000
        L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4 = L1_4(L2_4, L3_4)
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
        L0_4 = L6_2.automateGrabCards
        if not L0_4 then
          return
        end
        L0_4 = L6_2.automateGrabCards
        L1_4 = L6_3
        L0_4(L1_4)
        L0_4 = L6_2.holdCards
        if not L0_4 then
          return
        end
        L0_4 = L6_2.holdCards
        L1_4 = L6_3
        L0_4(L1_4)
        L0_4 = Wait
        L1_4 = RandomNumber
        L2_4 = 1000
        L3_4 = 40000
        L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4 = L1_4(L2_4, L3_4)
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
        L0_4 = IN_CASINO
        if L0_4 then
          L0_4 = L6_2.chairPositions
          if L0_4 then
            goto lbl_34
          end
        end
        do return end
        ::lbl_34::
        L0_4 = L6_2.chairPositions
        L1_4 = L6_3
        L0_4 = L0_4[L1_4]
        L1_4 = RandomNumber
        L2_4 = 1
        L3_4 = 3
        L1_4 = L1_4(L2_4, L3_4)
        if 2 == L1_4 then
          L1_4 = L6_2.automatePedAnimation
          L2_4 = L6_3
          L3_4 = L0_4.coords
          L4_4 = L0_4.rotation
          L5_4 = L3_1
          L6_4 = "cards_play"
          L7_4 = false
          L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
          L1_4 = L6_2.acceptAndPlay
          L2_4 = L6_3
          L1_4(L2_4)
          L1_4 = Wait
          L2_4 = 1200
          L1_4(L2_4)
          L1_4 = L6_2.ambientPeds
          if not L1_4 then
            return
          end
          L1_4 = L37_1
          L2_4 = L6_2.ambientPeds
          L3_4 = L6_3
          L2_4 = L2_4[L3_4]
          L3_4 = L6_2
          L4_4 = L6_3
          L6_4 = L6_3
          L5_4 = L2_3
          L5_4 = L5_4[L6_4]
          L6_4 = 3
          L7_4 = true
          L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
        else
          L1_4 = L6_2.automatePedAnimation
          L2_4 = L6_3
          L3_4 = L0_4.coords
          L4_4 = L0_4.rotation
          L5_4 = L3_1
          L6_4 = "cards_fold"
          L7_4 = false
          L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
          L1_4 = L6_2.foldCards
          L2_4 = L6_3
          L1_4(L2_4)
          L1_4 = Wait
          L2_4 = 2000
          L1_4(L2_4)
          L1_4 = L6_2.automateMakeIdle
          if not L1_4 then
            return
          end
          L1_4 = L6_2.automateMakeIdle
          L2_4 = L6_3
          L1_4(L2_4)
        end
        L1_4 = L1_3
        L1_4 = L1_4 + 1
        L1_3 = L1_4
      end
      L9_3 = "poker animation"
      L7_3(L8_3, L9_3)
    end
    while true do
      L3_3 = IN_CASINO
      if not (L3_3 and L1_3 < 4) then
        break
      end
      L3_3 = Wait
      L4_3 = 100
      L3_3(L4_3)
    end
    L3_3 = IN_CASINO
    if L3_3 then
      L3_3 = L6_2.chairPositions
      if L3_3 then
        goto lbl_128
      end
    end
    do return end
    ::lbl_128::
    L3_3 = 1
    L4_3 = 4
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = L6_2.pedUncoverChairCards
      L8_3 = L6_3
      L7_3(L8_3)
    end
    L3_3 = L6_2.pedUncoverCardsSelf
    L3_3()
    L3_3 = L6_2.pedIdle
    L3_3()
    L3_3 = Wait
    L4_3 = 3000
    L3_3(L4_3)
    L3_3 = L6_2.pedPickupDeck
    L3_3()
    L3_3 = 1
    L4_3 = 4
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = L6_2.pedCollectCards
      L8_3 = L6_3
      L7_3(L8_3)
    end
    L3_3 = L6_2.pedCollectCards
    L4_3 = "dealer"
    L3_3(L4_3)
    L3_3 = L6_2.pedPutDownCardPile
    L3_3()
    L3_3 = L6_2.pedIdle
    L3_3()
    L3_3 = L6_2.deleteRoundObjects
    L3_3()
    L3_3 = Debug
    L4_3 = "automateRound"
    L5_3 = "Round automated"
    L3_3(L4_3, L5_3)
  end
  L6_2.automateRound = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3
    L0_3 = Debug
    L1_3 = "automate"
    L2_3 = "Automating"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.automated
    if L0_3 then
      return
    end
    L6_2.automated = true
    L0_3 = CreateThread
    function L1_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4
      while true do
        L0_4 = IN_CASINO
        if not L0_4 then
          break
        end
        L0_4 = L6_2.coords
        if not L0_4 then
          return
        end
        L0_4 = GetPlayerPosition
        L0_4 = L0_4()
        L1_4 = L6_2.coords
        L0_4 = L0_4 - L1_4
        L0_4 = #L0_4
        if L0_4 < 15.0 then
          break
        end
        L0_4 = Wait
        L1_4 = 1000
        L0_4(L1_4)
      end
      L0_4 = IN_CASINO
      if L0_4 then
        L0_4 = L6_2.automateEveryoneIdle
        if L0_4 then
          goto lbl_27
        end
      end
      do return end
      ::lbl_27::
      L0_4 = {}
      L6_2.ambientPeds = L0_4
      L0_4 = 1
      L1_4 = 4
      L2_4 = 1
      for L3_4 = L0_4, L1_4, L2_4 do
        L4_4 = Repeat
        L5_4 = L6_2.magicNumber
        L6_4 = AMBIENT_TABLES_PED_SKINS
        L6_4 = #L6_4
        L4_4 = L4_4(L5_4, L6_4)
        L4_4 = L4_4 + 1
        L4_4 = L4_4 + L3_4
        L5_4 = GetHashKey
        L6_4 = AMBIENT_TABLES_PED_SKINS
        L6_4 = L6_4[L4_4]
        L5_4 = L5_4(L6_4)
        L6_4 = RequestModelAndWait
        L7_4 = L5_4
        L6_4(L7_4)
        L6_4 = CreatePed
        L7_4 = 2
        L8_4 = L5_4
        L9_4 = L6_2.coords
        L10_4 = A3_2
        L10_4 = L10_4 + 180.0
        L11_4 = false
        L12_4 = false
        L6_4 = L6_4(L7_4, L8_4, L9_4, L10_4, L11_4, L12_4)
        L7_4 = SetModelAsNoLongerNeeded
        L8_4 = L5_4
        L7_4(L8_4)
        L7_4 = SetPedBrave
        L8_4 = L6_4
        L7_4(L8_4)
        L7_4 = SetEntityCollision
        L8_4 = L6_4
        L9_4 = false
        L10_4 = false
        L7_4(L8_4, L9_4, L10_4)
        L7_4 = FreezeEntityPosition
        L8_4 = L6_4
        L9_4 = true
        L7_4(L8_4, L9_4)
        L7_4 = table
        L7_4 = L7_4.insert
        L8_4 = L6_2.ambientPeds
        L9_4 = L6_4
        L7_4(L8_4, L9_4)
      end
      L0_4 = L6_2.automateEveryoneIdle
      L0_4()
      while true do
        L0_4 = L6_2.automated
        if not L0_4 then
          break
        end
        L0_4 = IN_CASINO
        if not L0_4 then
          break
        end
        L0_4 = GetPlayerPosition
        L0_4 = L0_4()
        L1_4 = L6_2.coords
        L0_4 = L0_4 - L1_4
        L0_4 = #L0_4
        if L0_4 < 5.0 then
          L0_4 = pcall
          L1_4 = L6_2.automateRound
          L0_4(L1_4)
        end
        L0_4 = Wait
        L1_4 = 5000
        L0_4(L1_4)
      end
    end
    L2_3 = "creating ped models poker"
    L0_3(L1_3, L2_3)
    L0_3 = Debug
    L1_3 = "automate"
    L2_3 = "Automated"
    L0_3(L1_3, L2_3)
  end
  L6_2.automate = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L0_3 = Debug
    L1_3 = "destroy"
    L2_3 = "Destroying"
    L0_3(L1_3, L2_3)
    L0_3 = L6_2.cleanDirt
    L0_3()
    L0_3 = L6_2.deleteRoundObjects
    L0_3()
    L0_3 = L6_2.pokerCamera
    if L0_3 then
      L0_3 = SetCamActive
      L1_3 = L6_2.pokerCamera
      L2_3 = false
      L0_3(L1_3, L2_3)
      L0_3 = DestroyCam
      L1_3 = L6_2.pokerCamera
      L2_3 = false
      L0_3(L1_3, L2_3)
    end
    L0_3 = ForceDeleteEntity
    L1_3 = L6_2.cardPileObject
    L0_3(L1_3)
    L0_3 = DeletePed
    L1_3 = L6_2.ped
    L0_3(L1_3)
    L0_3 = L6_2.disableCamera
    L0_3()
    L0_3 = L6_2.keepTableObject
    if not L0_3 then
      L0_3 = ForceDeleteEntity
      L1_3 = L6_2.tableObject
      L0_3(L1_3)
    end
    L0_3 = L6_2.ambientPeds
    if L0_3 then
      L0_3 = pairs
      L1_3 = L6_2.ambientPeds
      L0_3, L1_3, L2_3, L3_3 = L0_3(L1_3)
      for L4_3, L5_3 in L0_3, L1_3, L2_3, L3_3 do
        L6_3 = ForceDeleteEntity
        L7_3 = L5_3
        L6_3(L7_3)
      end
    end
    L0_3 = {}
    L6_2 = L0_3
    L0_3 = Debug
    L1_3 = "destroy"
    L2_3 = "Destroyed"
    L0_3(L1_3, L2_3)
  end
  L6_2.destroy = L8_2
  L8_2 = Debug
  L9_2 = "init"
  L10_2 = "Initializing"
  L8_2(L9_2, L10_2)
  L8_2 = L6_2.pedIdle
  L8_2()
  L8_2 = L6_2.createCardPile
  L8_2()
  L8_2 = L6_2.loadChairData
  L8_2()
  L8_2 = Debug
  L9_2 = "init"
  L10_2 = "Initialized"
  L8_2(L9_2, L10_2)
  return L6_2
end
function L58_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = DebugStart
  L1_2 = "SendSitRequest"
  L0_2(L1_2)
  L0_2 = InfoPanel_Update
  L1_2 = nil
  L2_2 = nil
  L3_2 = nil
  L4_2 = nil
  L5_2 = nil
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  L0_2 = InfoPanel_UpdateNotification
  L1_2 = nil
  L0_2(L1_2)
  L0_2 = GetMyPedNetworkId
  L0_2 = L0_2()
  if not L0_2 then
    return
  end
  L1_2 = L33_1
  L1_2()
  L1_2 = L7_1
  if nil == L1_2 then
    return
  end
  L1_2 = L7_1.getClosestChair
  L2_2 = GetPlayerPosition
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L2_2()
  L1_2, L2_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
  L3_2 = L7_1.chairPositions
  L3_2 = L3_2[L1_2]
  if nil == L3_2 then
    return
  end
  L4_2 = PokerTableDatas
  L5_2 = L7_1.color
  L4_2 = L4_2[L5_2]
  L9_1 = L4_2
  L4_2 = L9_1.MinBetValueAntePlay
  L21_1 = L4_2
  L4_2 = L9_1.MinBetValuePairPlus
  L22_1 = L4_2
  L4_2 = BlockPlayerInteraction
  L5_2 = 2000
  L4_2(L5_2)
  LAST_STARTED_GAME_TYPE = "poker"
  L4_2 = TriggerServerEvent
  L5_2 = "Poker:Sit"
  L6_2 = L7_1.coords
  L7_2 = L1_2
  L8_2 = L7_1.color
  L9_2 = PLAYER_DRUNK_LEVEL
  L10_2 = 0.5
  L9_2 = L9_2 > L10_2
  L10_2 = IsPedMale
  L11_2 = PlayerPedId
  L11_2 = L11_2()
  L10_2 = L10_2(L11_2)
  L11_2 = L0_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
end
function L59_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = PokerTableDatas
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    return
  end
  L1_2 = PokerTableDatas
  L1_2 = L1_2[A0_2]
  L2_2 = InfoPanel_UpdateNotification
  L3_2 = nil
  L2_2(L3_2)
  L2_2 = InfoPanel_Update
  L3_2 = L1_2.Banner
  L4_2 = L1_2.Banner
  L5_2 = L1_2.Title
  L6_2 = Translation
  L6_2 = L6_2.Get
  L7_2 = "POKER_WELCOME_PART1"
  L6_2 = L6_2(L7_2)
  L7_2 = Translation
  L7_2 = L7_2.Get
  L8_2 = "POKER_WELCOME_PART2"
  L7_2 = L7_2(L8_2)
  L8_2 = true
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
Poker_ShowWelcome = L59_1
function L59_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = DebugStart
  L2_2 = "Poker_OnInteraction"
  L1_2(L2_2)
  L1_2 = L10_1
  if L1_2 then
    return
  end
  L1_2 = PLAYER_DRUNK_LEVEL
  if L1_2 >= 1.0 then
    return
  end
  if A0_2 then
    L1_2 = L35_1
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L7_1 = L1_2
  end
  L1_2 = L7_1
  if nil ~= L1_2 then
    L1_2 = L7_1.chairPositions
    if L1_2 then
      L1_2 = L7_1.chairPositions
      L1_2 = #L1_2
      if not (L1_2 < 4) then
        goto lbl_29
      end
    end
    do return end
    ::lbl_29::
    L1_2 = L7_1.getClosestChair
    L2_2 = GetPlayerPosition
    L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L2_2()
    L1_2, L2_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L3_2 = L7_1.syncedState
    L3_2 = L3_2.chairs
    L3_2 = L3_2[L1_2]
    L4_2 = PokerTableDatas
    L5_2 = L7_1.color
    L4_2 = L4_2[L5_2]
    L9_1 = L4_2
    L4_2 = L9_1.VIP
    if L4_2 then
      L4_2 = PLAYER_IS_VIP
      if not L4_2 then
        L4_2 = InfoPanel_UpdateNotification
        L5_2 = Translation
        L5_2 = L5_2.Get
        L6_2 = "TABLE_GAMES_VIP_RESTRICTION"
        L5_2, L6_2, L7_2, L8_2, L9_2 = L5_2(L6_2)
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
        return
      end
    end
    L4_2 = L9_1.MinBetValueAntePlay
    L5_2 = PLAYER_CHIPS
    if L4_2 > L5_2 then
      L4_2 = InfoPanel_UpdateNotification
      L5_2 = string
      L5_2 = L5_2.format
      L6_2 = Translation
      L6_2 = L6_2.Get
      L7_2 = "TABLE_CANT_AFFORD_PLAYING"
      L6_2 = L6_2(L7_2)
      L7_2 = L9_1.MinBetValueAntePlay
      L5_2, L6_2, L7_2, L8_2, L9_2 = L5_2(L6_2, L7_2)
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
      return
    end
    if nil ~= L3_2 and -1 == L3_2 then
      L4_2 = L7_1.automated
      if not L4_2 then
        L4_2 = GAME_INFO_PANEL
        if nil == L4_2 then
          L4_2 = ShouldShowHowToPlay
          L5_2 = "poker"
          L4_2 = L4_2(L5_2)
          if L4_2 then
            L4_2 = Poker_ShowWelcome
            L5_2 = L7_1.color
            L4_2(L5_2)
        end
        else
          L4_2 = L58_1
          L4_2()
        end
    end
    else
      L4_2 = InfoPanel_Update
      L5_2 = nil
      L6_2 = nil
      L7_2 = nil
      L8_2 = nil
      L9_2 = nil
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
      L4_2 = InfoPanel_UpdateNotification
      L5_2 = Translation
      L5_2 = L5_2.Get
      L6_2 = "UI_CHAIR_USED"
      L5_2, L6_2, L7_2, L8_2, L9_2 = L5_2(L6_2)
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
    end
  end
end
Poker_OnInteraction = L59_1
function L59_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "OnPlayerStandUp"
  L0_2(L1_2)
  L0_2 = ClearPedTasks
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L0_2(L1_2)
  L0_2 = ClearPedSecondaryTask
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L0_2(L1_2)
  L0_2 = ScenePed_AnnounceEnd
  L0_2()
  L0_2 = PushNUIInstructionalButtons
  L1_2 = nil
  L0_2(L1_2)
  L0_2 = SetInventoryBusy
  L1_2 = false
  L0_2(L1_2)
end
function L60_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = DebugStart
  L1_2 = "Poker_OnQuit"
  L0_2(L1_2)
  L0_2 = L10_1
  if L0_2 then
    L0_2 = Stats_EndActivity
    L0_2()
    L0_2 = CloseAllMenus
    L0_2()
    L0_2 = ClearMugshotCache
    L0_2()
    L0_2 = BlockPlayerInteraction
    L1_2 = 2000
    L0_2(L1_2)
    L0_2 = PushNUIInstructionalButtons
    L1_2 = nil
    L0_2(L1_2)
    L0_2 = GetRandomItem
    L1_2 = {}
    L2_2 = "sit_exit_left"
    L3_2 = "sit_exit_right"
    L1_2[1] = L2_2
    L1_2[2] = L3_2
    L0_2 = L0_2(L1_2)
    L1_2 = PlaySynchronizedScene
    L2_2 = L8_1.coords
    L3_2 = L8_1.rotation
    L4_2 = L4_1
    L5_2 = L0_2
    L6_2 = false
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    L2_2 = L5_1.disableCamera
    L2_2()
    L2_2 = L33_1
    L2_2()
    L2_2 = TriggerServerEvent
    L3_2 = "Poker:Quit"
    L2_2(L3_2)
    L2_2 = CreateNewSceneEndEvent
    L3_2 = L1_2
    L4_2 = 0.7
    L5_2 = L59_1
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = ForgotLastStartedGameType
    L3_2 = "poker"
    L2_2(L3_2)
    L2_2 = nil
    L7_1 = L2_2
    return
  end
end
Poker_OnQuit = L60_1
function L60_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = Config
  L2_2 = L2_2.UseTarget
  if L2_2 then
    return
  end
  L2_2 = DebugStart
  L3_2 = "Poker_ShowNotifyUI"
  L2_2(L3_2)
  L2_2 = L10_1
  if L2_2 then
    return
  end
  L2_2 = nil
  L7_1 = L2_2
  L2_2 = pairs
  L3_2 = L0_1
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.tableObject
    if L8_2 == A0_2 then
      L7_1 = L7_2
    end
  end
  L2_2 = L7_1
  if not L2_2 then
    L2_2 = L35_1
    L3_2 = A1_2
    L2_2 = L2_2(L3_2)
    L7_1 = L2_2
    L2_2 = L7_1
    if L2_2 then
      L2_2 = DoesEntityExist
      L3_2 = L7_1.tableObject
      L2_2 = L2_2(L3_2)
      if not L2_2 then
        L7_1.tableObject = A0_2
      end
    end
  end
  L2_2 = L7_1
  if L2_2 then
    L2_2 = L7_1.chairPositions
    if not L2_2 then
      L2_2 = nil
      L7_1 = L2_2
      return
    end
  end
  L2_2 = L7_1
  if nil == L2_2 then
    L2_2 = InfoPanel_Update
    L3_2 = nil
    L4_2 = nil
    L5_2 = nil
    L6_2 = nil
    L7_2 = nil
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    L2_2 = InfoPanel_UpdateNotification
    L3_2 = nil
    L2_2(L3_2)
    return
  end
  L2_2 = L7_1.loadChairData
  L2_2()
  L2_2 = L7_1.getClosestChair
  L3_2 = GetPlayerPosition
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2()
  L2_2, L3_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_2 = L7_1.syncedState
  L4_2 = L4_2.chairs
  L4_2 = L4_2[L2_2]
  L5_2 = PokerTableDatas
  L6_2 = L7_1.color
  L5_2 = L5_2[L6_2]
  L9_1 = L5_2
  L5_2 = L9_1.VIP
  if L5_2 then
    L5_2 = PLAYER_IS_VIP
    if not L5_2 then
      L5_2 = InfoPanel_UpdateNotification
      L6_2 = Translation
      L6_2 = L6_2.Get
      L7_2 = "TABLE_GAMES_VIP_RESTRICTION"
      L6_2, L7_2, L8_2 = L6_2(L7_2)
      L5_2(L6_2, L7_2, L8_2)
      return
    end
  end
  L5_2 = L9_1.MinBetValueAntePlay
  L6_2 = PLAYER_CHIPS
  if L5_2 > L6_2 then
    L5_2 = InfoPanel_UpdateNotification
    L6_2 = string
    L6_2 = L6_2.format
    L7_2 = Translation
    L7_2 = L7_2.Get
    L8_2 = "TABLE_CANT_AFFORD_PLAYING"
    L7_2 = L7_2(L8_2)
    L8_2 = L9_1.MinBetValueAntePlay
    L6_2, L7_2, L8_2 = L6_2(L7_2, L8_2)
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  if nil ~= L4_2 and -1 == L4_2 then
    L5_2 = L7_1.automated
    if not L5_2 then
      L5_2 = Translation
      L5_2 = L5_2.Get
      L6_2 = "UI_PRESS_TO_PLAY"
      L5_2 = L5_2(L6_2)
      L6_2 = " "
      L7_2 = L9_1.Title
      L8_2 = "."
      L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2
      L6_2 = InfoPanel_UpdateNotification
      L7_2 = L5_2
      L6_2(L7_2)
  end
  else
    L5_2 = InfoPanel_UpdateNotification
    L6_2 = Translation
    L6_2 = L6_2.Get
    L7_2 = "UI_CHAIR_USED"
    L6_2, L7_2, L8_2 = L6_2(L7_2)
    L5_2(L6_2, L7_2, L8_2)
  end
end
Poker_ShowNotifyUI = L60_1
function L60_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = DebugStart
  L2_2 = "FinishRoundAtTable"
  L1_2(L2_2)
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = A0_2.chairCards
      L4_3 = L4_3[L3_3]
      if nil ~= L4_3 then
        L5_3 = #L4_3
        if L5_3 > 0 then
          L5_3 = A0_2.pedUncoverChairCards
          L6_3 = L3_3
          L5_3(L6_3)
        end
      end
    end
    L0_3 = A0_2.chairCards
    L0_3 = L0_3.dealer
    if nil ~= L0_3 then
      L0_3 = A0_2.chairCards
      L0_3 = L0_3.dealer
      L0_3 = #L0_3
      if L0_3 > 0 then
        L0_3 = A0_2.pedUncoverCardsSelf
        L0_3()
      end
    end
    L0_3 = A0_2.pedIdle
    L0_3()
    L0_3 = Wait
    L1_3 = 1000
    L0_3(L1_3)
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = A0_2.pedIdle
      if L0_3 then
        goto lbl_39
      end
    end
    do return end
    ::lbl_39::
    L0_3 = A0_2.pedPickupDeck
    L0_3()
    L0_3 = 1
    L1_3 = 4
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = A0_2.chairCards
      L4_3 = L4_3[L3_3]
      if nil ~= L4_3 then
        L5_3 = #L4_3
        if L5_3 > 0 then
          L5_3 = A0_2.pedCollectCards
          L6_3 = L3_3
          L5_3(L6_3)
        end
      end
    end
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = A0_2.pedIdle
      if L0_3 then
        goto lbl_63
      end
    end
    do return end
    ::lbl_63::
    L0_3 = A0_2.chairCards
    L0_3 = L0_3.dealer
    if nil ~= L0_3 then
      L0_3 = A0_2.chairCards
      L0_3 = L0_3.dealer
      L0_3 = #L0_3
      if L0_3 > 0 then
        L0_3 = A0_2.pedCollectCards
        L1_3 = "dealer"
        L0_3(L1_3)
      end
    end
    L0_3 = IN_CASINO
    if L0_3 then
      L0_3 = A0_2.pedIdle
      if L0_3 then
        goto lbl_82
      end
    end
    do return end
    ::lbl_82::
    L0_3 = A0_2.pedPutDownCardPile
    L0_3()
    L0_3 = A0_2.pokerPedSay
    L1_3 = "MINIGAME_DEALER_ANOTHER_GO"
    L0_3(L1_3)
    L0_3 = A0_2.pedIdle
    L0_3()
  end
  L3_2 = "FinishRoundAtTable poker"
  L1_2(L2_2, L3_2)
end
function L61_1(A0_2)
  local L1_2, L2_2
  L1_2 = DebugStart
  L2_2 = "CleanUpAtTable"
  L1_2(L2_2)
  L1_2 = A0_2.deleteRoundObjects
  L1_2()
  L1_2 = A0_2.pokerPedSay
  L2_2 = "MINIGAME_DEALER_PLACE_BET"
  L1_2(L2_2)
end
function L62_1(A0_2)
  local L1_2, L2_2
  L1_2 = DebugStart
  L2_2 = "StepChanged"
  L1_2(L2_2)
  L1_2 = L38_1
  L1_2()
  if 1 == A0_2 then
    L1_2 = IsActivityEnabled
    L2_2 = "poker"
    L1_2 = L1_2(L2_2)
    if not L1_2 then
      L1_2 = Poker_OnQuit
      L1_2()
      return
    end
  end
  if 1 == A0_2 then
    L1_2 = L9_1.MinBetValueAntePlay
    L2_2 = PLAYER_CHIPS
    if L1_2 > L2_2 then
      L1_2 = L9_1.MinBetValuePairPlus
      L2_2 = PLAYER_CHIPS
      if L1_2 > L2_2 then
        L1_2 = Poker_OnQuit
        L1_2()
        return
    end
  end
  else
    if 2 == A0_2 then
      L1_2 = L9_1.MinBetValuePairPlus
      L2_2 = PLAYER_CHIPS
      if L1_2 > L2_2 then
        L1_2 = BlockPlayerInteraction
        L2_2 = 500
        L1_2(L2_2)
        L1_2 = TriggerServerEvent
        L2_2 = "Poker:SkipPairPlus"
        L1_2(L2_2)
    end
    elseif 4 == A0_2 then
      L1_2 = L25_1.ante
      if L1_2 then
        L1_2 = L25_1.ante
        L2_2 = PLAYER_CHIPS
        if L1_2 > L2_2 then
          L1_2 = BlockPlayerInteraction
          L2_2 = 500
          L1_2(L2_2)
          L1_2 = TriggerServerEvent
          L2_2 = "Poker:SkipPlay"
          L1_2(L2_2)
        end
      end
    end
  end
  if 3 ~= A0_2 and 5 ~= A0_2 and 6 ~= A0_2 and 7 ~= A0_2 then
    L1_2 = L42_1
    L1_2()
    L1_2 = L44_1
    L1_2()
    L1_2 = L45_1
    L1_2()
  end
  L1_2 = false
  L15_1 = L1_2
  L1_2 = 0
  L13_1 = L1_2
  L1_2 = false
  L16_1 = L1_2
  L1_2 = L5_1.stopTicking
  L1_2()
  L1_2 = L46_1
  L1_2, L2_2 = L1_2()
  L19_1 = L2_2
  _ = L1_2
  if 1 == A0_2 then
    L1_2 = 0
    L23_1 = L1_2
    L1_2 = 0
    L24_1 = L1_2
    L1_2 = {}
    L25_1 = L1_2
    L1_2 = true
    L17_1 = L1_2
    L1_2 = nil
    L18_1 = L1_2
    L1_2 = L12_1
    if 0 == L1_2 then
      L1_2 = CloseAllMenus
      L1_2()
    end
  end
  if 1 == A0_2 or 2 == A0_2 then
    if 1 == A0_2 then
      L1_2 = L21_1
      if L1_2 then
        goto lbl_112
      end
    end
    L1_2 = L22_1
    ::lbl_112::
    L13_1 = L1_2
    L1_2 = L39_1
    L1_2()
  elseif 4 == A0_2 then
    L1_2 = L25_1.ante
    if nil ~= L1_2 then
      L1_2 = L25_1.ante
      if L1_2 > 0 then
        L1_2 = L25_1.ante
        L13_1 = L1_2
        L1_2 = L39_1
        L1_2()
      end
    end
  end
  if 2 == A0_2 or 3 == A0_2 then
    L1_2 = L25_1.pairPlus
    if nil ~= L1_2 then
      L1_2 = L25_1.pairPlus
      if L1_2 > 0 then
        L1_2 = L41_1
        L2_2 = L25_1.pairPlus
        L1_2(L2_2)
      end
    end
    L1_2 = L25_1.ante
    if nil ~= L1_2 then
      L1_2 = L25_1.ante
      if L1_2 > 0 then
        L1_2 = L40_1
        L2_2 = L25_1.ante
        L1_2(L2_2)
      end
    end
  end
  if A0_2 >= 6 then
    L1_2 = L5_1.disableCamera
    L1_2()
    L1_2 = BlockQuittingFor
    L2_2 = 0
    L1_2(L2_2)
  end
  L1_2 = L47_1
  L1_2()
end
function L63_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = DebugStart
  L1_2 = "OneSecondTick"
  L0_2(L1_2)
  L0_2 = L10_1
  if L0_2 then
    L0_2 = L5_1
    if nil ~= L0_2 then
      L0_2 = L6_1
      if L0_2 then
        goto lbl_14
      end
    end
  end
  do return end
  ::lbl_14::
  L0_2 = L11_1
  L1_2 = L5_1.syncedState
  L1_2 = L1_2.step
  if L0_2 ~= L1_2 then
    L0_2 = L5_1.syncedState
    L0_2 = L0_2.step
    L11_1 = L0_2
    L0_2 = L62_1
    L1_2 = L11_1
    L0_2(L1_2)
  end
  L0_2 = L5_1
  if L0_2 then
    L0_2 = L5_1.syncedState
    L0_2 = L0_2.timeleft
    if L0_2 > 0 then
      L0_2 = L5_1.syncedState
      L1_2 = L5_1.syncedState
      L1_2 = L1_2.timeleft
      L1_2 = L1_2 - 1
      L0_2.timeleft = L1_2
      L0_2 = L27_1
      if nil ~= L0_2 then
        L0_2 = L27_1.visible
        if L0_2 then
          L0_2 = L5_1.syncedState
          L0_2 = L0_2.timeleft
          if 4 == L0_2 then
            L0_2 = L5_1.startTicking
            L0_2()
          end
          L0_2 = L27_1.setText
          L1_2 = "00:"
          L2_2 = string
          L2_2 = L2_2.format
          L3_2 = "%02d"
          L4_2 = L5_1.syncedState
          L4_2 = L4_2.timeleft
          L2_2 = L2_2(L3_2, L4_2)
          L1_2 = L1_2 .. L2_2
          L0_2(L1_2)
        end
      end
    end
  end
end
function L64_1()
  local L0_2, L1_2, L2_2
  L0_2 = DebugStart
  L1_2 = "StartOneSecondTimer"
  L0_2(L1_2)
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3
    while true do
      L0_3 = IN_CASINO
      if not L0_3 then
        break
      end
      L0_3 = L10_1
      if not L0_3 then
        break
      end
      L0_3 = L63_1
      L0_3()
      L0_3 = Wait
      L1_3 = 1000
      L0_3(L1_3)
    end
  end
  L2_2 = "one second tick poker"
  L0_2(L1_2, L2_2)
end
function L65_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = DebugStart
  L3_2 = "AnimateStartAtTable"
  L2_2(L3_2)
  if nil == A0_2 then
    return
  end
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3
    L0_3 = A0_2.pokerPedSay
    L1_3 = "MINIGAME_DEALER_CLOSED_BETS"
    L0_3(L1_3)
    L0_3 = A0_2.pedPickupDeck
    L0_3()
    L0_3 = A0_2.pedShuffle
    L0_3()
    L0_3 = A1_2
    if nil ~= L0_3 then
      L0_3 = A0_2.deleteAllCards
      L0_3()
      L0_3 = A0_2.pedDealAllCards
      L1_3 = A1_2
      L0_3(L1_3)
      L0_3 = A1_2.dealer
      if nil ~= L0_3 then
        L0_3 = A0_2.pedDealCardsSelf
        L1_3 = A1_2.dealer
        L0_3(L1_3)
      end
      L0_3 = A0_2.pedPutDownCardPile
      L0_3()
      L0_3 = A0_2.pedIdle
      L0_3()
    end
  end
  L4_2 = "animate dealing cards at table"
  L2_2(L3_2, L4_2)
end
L66_1 = RegisterNetEvent
L67_1 = "Poker:PaidAmount"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:PaidAmount"
function L68_1(A0_2)
  local L1_2
  L1_2 = L23_1
  L1_2 = L1_2 + A0_2
  L23_1 = L1_2
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:WonAmount"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:WonAmount"
function L68_1(A0_2)
  local L1_2
  L1_2 = L24_1
  L1_2 = L1_2 + A0_2
  L24_1 = L1_2
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:TicketResults"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:TicketResults"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L2_2 = L24_1
  L3_2 = L23_1
  L2_2 = L2_2 - L3_2
  L3_2 = L24_1
  L4_2 = L23_1
  if L3_2 > L4_2 then
    L3_2 = Stats_Increase
    L4_2 = "rcore_casino_poker_wins"
    L5_2 = 1
    L3_2(L4_2, L5_2)
  else
    L3_2 = Stats_Increase
    L4_2 = "rcore_casino_poker_loss"
    L5_2 = 1
    L3_2(L4_2, L5_2)
  end
  L3_2 = L24_1
  if L3_2 > 0 then
    L3_2 = Stats_Increase
    L4_2 = "rcore_casino_poker_profit"
    L5_2 = L24_1
    L3_2(L4_2, L5_2)
  end
  if L2_2 > 0 then
    L3_2 = Stats_Increase
    L4_2 = "rcore_casino_poker_profitreal"
    L5_2 = L2_2
    L3_2(L4_2, L5_2)
  elseif L2_2 < 0 then
    L3_2 = Stats_Decrease
    L4_2 = "rcore_casino_poker_profitreal"
    L5_2 = math
    L5_2 = L5_2.abs
    L6_2 = L2_2
    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L5_2(L6_2)
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  end
  PLAYER_CHIPS = A1_2
  L3_2 = Casino_AnimateBalance
  L3_2()
  L3_2 = A0_2[1]
  L4_2 = A0_2[2]
  L3_2 = L3_2 + L4_2
  L4_2 = A0_2[3]
  L5_2 = A0_2[4]
  L6_2 = A0_2[5]
  L7_2 = A0_2[6]
  L8_2 = A0_2[7]
  L9_2 = ""
  L10_2 = PokerHandValueCode
  L11_2 = L6_2
  L10_2 = L10_2(L11_2)
  L11_2 = Translation
  L11_2 = L11_2.Get
  L12_2 = L10_2
  L11_2 = L11_2(L12_2)
  L10_2 = L11_2
  L11_2 = PokerHandValueCode
  L12_2 = L5_2
  L11_2 = L11_2(L12_2)
  L12_2 = Translation
  L12_2 = L12_2.Get
  L13_2 = L11_2
  L12_2 = L12_2(L13_2)
  L11_2 = L12_2
  if L6_2 < 12 then
    L12_2 = Translation
    L12_2 = L12_2.Get
    L13_2 = "POKER_RESULTS_DEALER_DOESNT_QUALIFY"
    L12_2 = L12_2(L13_2)
    L13_2 = " "
    L12_2 = L12_2 .. L13_2
    L9_2 = L12_2
  else
    L12_2 = Translation
    L12_2 = L12_2.Get
    L13_2 = "POKER_RESULTS_DEALER_HAS"
    L12_2 = L12_2(L13_2)
    L13_2 = " "
    L14_2 = L10_2
    L15_2 = ". "
    L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2
    L9_2 = L12_2
  end
  if 1 == L4_2 then
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "POKER_RESULTS_YOU_HAVE"
    L13_2 = L13_2(L14_2)
    L14_2 = " "
    L15_2 = L11_2
    L16_2 = ". "
    L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2
    L9_2 = L12_2
  elseif nil ~= L7_2 and L7_2 > 0 then
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "CASINO_RESULTS_YOU_FOLDED"
    L13_2 = L13_2(L14_2)
    L14_2 = " "
    L12_2 = L12_2 .. L13_2 .. L14_2
    L9_2 = L12_2
  else
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "CASINO_RESULTS_YOU_DIDNT_BET_ANTE_PLAY"
    L13_2 = L13_2(L14_2)
    L14_2 = " "
    L12_2 = L12_2 .. L13_2 .. L14_2
    L9_2 = L12_2
  end
  if L8_2 then
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "CASINO_RESULTS_ITS_DRAW"
    L13_2 = L13_2(L14_2)
    L12_2 = L12_2 .. L13_2
    L9_2 = L12_2
  elseif L3_2 > 0 then
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "CASINO_RESULTS_YOU_WIN_X_COINS"
    L13_2 = L13_2(L14_2)
    L14_2 = " "
    L15_2 = CommaValue
    L16_2 = L3_2
    L15_2 = L15_2(L16_2)
    L16_2 = " "
    L17_2 = Translation
    L17_2 = L17_2.Get
    L18_2 = "ROULETTE_RULES_CHIPS"
    L17_2 = L17_2(L18_2)
    L18_2 = "!"
    L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2
    L9_2 = L12_2
  else
    L12_2 = L9_2
    L13_2 = Translation
    L13_2 = L13_2.Get
    L14_2 = "CASINO_RESULTS_YOU_LOSE"
    L13_2 = L13_2(L14_2)
    L12_2 = L12_2 .. L13_2
    L9_2 = L12_2
  end
  L18_1 = L9_2
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:PlaceBet"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:PlaceBet"
function L68_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L6_2 = IN_CASINO
  if not L6_2 then
    return
  end
  L6_2 = L35_1
  L7_2 = A1_2
  L6_2 = L6_2(L7_2)
  if nil == L6_2 then
    return
  end
  L7_2 = nil
  L8_2 = GetMyPlayerId
  L8_2 = L8_2()
  if A0_2 == L8_2 then
    L8_2 = PlayerPedId
    L8_2 = L8_2()
    L7_2 = L8_2
  else
    L8_2 = ScenePed_ForceUseForPlayer
    L9_2 = A0_2
    L10_2 = A5_2
    L8_2 = L8_2(L9_2, L10_2)
    L7_2 = L8_2
  end
  if L7_2 then
    L8_2 = TaskLookAtEntity
    L9_2 = L6_2.ped
    L10_2 = L7_2
    L11_2 = 3500
    L12_2 = 2048
    L13_2 = 1
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2)
    L8_2 = L37_1
    L9_2 = L7_2
    L10_2 = L6_2
    L11_2 = A2_2
    L12_2 = A3_2
    L13_2 = A4_2
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2)
  end
  L8_2 = L5_1
  if L6_2 == L8_2 then
    L8_2 = L11_1
    if L8_2 ~= A4_2 then
      L8_2 = L11_1
      if 4 ~= L8_2 or 3 ~= A4_2 then
        goto lbl_55
      end
    end
    L8_2 = L43_1
    L9_2 = A2_2
    L8_2(L9_2)
  end
  ::lbl_55::
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:Quit"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:Quit"
function L68_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L5_2 = IN_CASINO
  if not L5_2 then
    return
  end
  L5_2 = L35_1
  L6_2 = A1_2
  L5_2 = L5_2(L6_2)
  if nil == L5_2 then
    return
  end
  L6_2 = TaskLookAtEntity
  L7_2 = L5_2.ped
  L8_2 = GetPedFromPlayerId
  L9_2 = A0_2
  L8_2 = L8_2(L9_2)
  L9_2 = 3500
  L10_2 = 2048
  L11_2 = 3
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
  L6_2 = L5_2.pokerPedSay
  L7_2 = A4_2
  L6_2(L7_2)
  L6_2 = L5_2.syncedState
  L6_2.chairs = A3_2
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:Kicked"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:Kicked"
function L68_1()
  local L0_2, L1_2
  L0_2 = IN_CASINO
  if not L0_2 then
    return
  end
  L0_2 = StopFromPlaying
  L0_2()
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:StateChanged"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:StateChanged"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L2_2 = L35_1
  L3_2 = A0_2.coords
  L2_2 = L2_2(L3_2)
  if nil == L2_2 then
    return
  end
  L2_2.syncedState = A0_2
  L3_2 = L2_2.syncedState
  L3_2 = L3_2.step
  if 3 == L3_2 then
    L3_2 = L65_1
    L4_2 = L2_2
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  else
    L3_2 = L2_2.syncedState
    L3_2 = L3_2.step
    if 6 == L3_2 then
      L3_2 = L60_1
      L4_2 = L2_2
      L3_2(L4_2)
    else
      L3_2 = L2_2.syncedState
      L3_2 = L3_2.step
      if 7 == L3_2 then
        L3_2 = L61_1
        L4_2 = L2_2
        L3_2(L4_2)
      end
    end
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:ConfirmAnte"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:ConfirmAnte"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L25_1 = A1_2
  if A0_2 and -1 ~= A0_2 then
    L2_2 = 1
    L15_1 = L2_2
    L2_2 = PlaySound
    L3_2 = "DLC_VW_CONTINUE"
    L4_2 = "dlc_vw_table_games_frontend_sounds"
    L2_2(L3_2, L4_2)
    PLAYER_CHIPS = A0_2
    L2_2 = Casino_AnimateBalance
    L2_2()
    L2_2 = BlockQuittingFor
    L3_2 = 60000
    L2_2(L3_2)
  else
    L2_2 = PlaySound
    L3_2 = "OTHER_TEXT"
    L4_2 = "HUD_AWARDS"
    L2_2(L3_2, L4_2)
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:SkipAnte"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:SkipAnte"
function L68_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = IN_CASINO
  if not L1_2 then
    return
  end
  L25_1 = A0_2
  L1_2 = L11_1
  if 1 == L1_2 then
    L1_2 = L30_1
    if nil ~= L1_2 then
      L1_2 = 1
      L15_1 = L1_2
      L30_1.visible = false
    end
  end
  L1_2 = PlaySound
  L2_2 = "OTHER_TEXT"
  L3_2 = "HUD_AWARDS"
  L1_2(L2_2, L3_2)
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:SkipPairPlus"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:SkipPairPlus"
function L68_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = IN_CASINO
  if not L1_2 then
    return
  end
  L25_1 = A0_2
  L1_2 = L11_1
  if 2 == L1_2 then
    L1_2 = L30_1
    if nil ~= L1_2 then
      L1_2 = 2
      L15_1 = L1_2
      L30_1.visible = false
    end
  end
  L1_2 = PlaySound
  L2_2 = "OTHER_TEXT"
  L3_2 = "HUD_AWARDS"
  L1_2(L2_2, L3_2)
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:SkipPlay"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:SkipPlay"
function L68_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = IN_CASINO
  if not L1_2 then
    return
  end
  L25_1 = A0_2
  L1_2 = 4
  L15_1 = L1_2
  L1_2 = PlaySound
  L2_2 = "OTHER_TEXT"
  L3_2 = "HUD_AWARDS"
  L1_2(L2_2, L3_2)
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:ConfirmPairPlus"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:ConfirmPairPlus"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L25_1 = A1_2
  if A0_2 then
    L2_2 = 2
    L15_1 = L2_2
    L2_2 = PlaySound
    L3_2 = "DLC_VW_CONTINUE"
    L4_2 = "dlc_vw_table_games_frontend_sounds"
    L2_2(L3_2, L4_2)
    PLAYER_CHIPS = A0_2
    L2_2 = Casino_AnimateBalance
    L2_2()
    L2_2 = BlockQuittingFor
    L3_2 = 60000
    L2_2(L3_2)
  else
    L2_2 = PlaySound
    L3_2 = "OTHER_TEXT"
    L4_2 = "HUD_AWARDS"
    L2_2(L3_2, L4_2)
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:ConfirmPlay"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:ConfirmPlay"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L25_1 = A1_2
  if A0_2 and -1 ~= A0_2 then
    PLAYER_CHIPS = A0_2
    L2_2 = Casino_AnimateBalance
    L2_2()
    L2_2 = 4
    L15_1 = L2_2
    L2_2 = L30_1
    if nil ~= L2_2 then
      L30_1.visible = false
    end
    L2_2 = PlaySound
    L3_2 = "DLC_VW_CONTINUE"
    L4_2 = "dlc_vw_table_games_frontend_sounds"
    L2_2(L3_2, L4_2)
  else
    L2_2 = PlaySound
    L3_2 = "OTHER_TEXT"
    L4_2 = "HUD_AWARDS"
    L2_2(L3_2, L4_2)
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:GrabCards"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:GrabCards"
function L68_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = IN_CASINO
  if not L4_2 then
    return
  end
  L4_2 = L35_1
  L5_2 = A1_2
  L4_2 = L4_2(L5_2)
  if nil == L4_2 then
    return
  end
  L5_2 = nil
  L6_2 = GetMyPlayerId
  L6_2 = L6_2()
  if A0_2 == L6_2 then
    L6_2 = PlayerPedId
    L6_2 = L6_2()
    L5_2 = L6_2
  else
    L6_2 = ScenePed_ForceUseForPlayer
    L7_2 = A0_2
    L8_2 = A3_2
    L6_2 = L6_2(L7_2, L8_2)
    L5_2 = L6_2
  end
  if L5_2 then
    L6_2 = L56_1
    L7_2 = L5_2
    L8_2 = L4_2
    L9_2 = A2_2
    L6_2(L7_2, L8_2, L9_2)
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:FoldCards"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:FoldCards"
function L68_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = IN_CASINO
  if not L4_2 then
    return
  end
  L4_2 = L35_1
  L5_2 = A1_2
  L4_2 = L4_2(L5_2)
  if nil == L4_2 then
    return
  end
  L5_2 = L5_1
  if L4_2 == L5_2 then
    L5_2 = L11_1
    if 4 == L5_2 then
      L5_2 = L43_1
      L6_2 = A2_2
      L5_2(L6_2)
    end
  end
  L5_2 = L4_2.syncedState
  L5_2 = L5_2.cardsInHands
  L5_2 = L5_2[A2_2]
  if true ~= L5_2 then
    return
  end
  L5_2 = nil
  L6_2 = GetMyPlayerId
  L6_2 = L6_2()
  if A0_2 == L6_2 then
    L6_2 = PlayerPedId
    L6_2 = L6_2()
    L5_2 = L6_2
  else
    L6_2 = ScenePed_ForceUseForPlayer
    L7_2 = A0_2
    L8_2 = A3_2
    L6_2 = L6_2(L7_2, L8_2)
    L5_2 = L6_2
  end
  if L5_2 then
    L6_2 = L55_1
    L7_2 = L5_2
    L8_2 = L4_2
    L9_2 = A2_2
    L6_2(L7_2, L8_2, L9_2)
  end
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:LastRoundScores"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:LastRoundScores"
function L68_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = IN_CASINO
  if not L1_2 then
    return
  end
  L1_2 = L6_1
  if not L1_2 then
    return
  end
  L1_2 = L12_1
  if 0 ~= L1_2 then
    return
  end
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L0_3 = GetMugshotCacheSize
    L0_3 = L0_3()
    if L0_3 > 1 then
      L0_3 = ClearMugshotCache
      L0_3()
    end
    L0_3 = {}
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_2
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = {}
      L9_3 = GetPlayerFromServerId
      L10_3 = L7_3.playerId
      L9_3 = L9_3(L10_3)
      if -1 ~= L9_3 then
        L10_3 = GetPlayerPed
        L11_3 = L9_3
        L10_3 = L10_3(L11_3)
        L11_3 = L7_3.realName
        L8_3.name = L11_3
        L11_3 = CommaValue
        L12_3 = L7_3.score
        L11_3 = L11_3(L12_3)
        L8_3.score = L11_3
        L11_3 = GetPlayerMugshotTexture
        L12_3 = L10_3
        L11_3 = L11_3(L12_3)
        L8_3.txd = L11_3
        L11_3 = L7_3.score
        if L11_3 > 0 then
          L11_3 = table
          L11_3 = L11_3.insert
          L12_3 = L0_3
          L13_3 = L8_3
          L11_3(L12_3, L13_3)
        else
          L11_3 = L7_3.score
          if L11_3 < 0 then
            L11_3 = table
            L11_3 = L11_3.insert
            L12_3 = L1_3
            L13_3 = L8_3
            L11_3(L12_3, L13_3)
          end
        end
      end
    end
    L2_3 = L18_1
    if nil ~= L2_3 then
      L2_3 = L49_1
      L3_3 = L0_3
      L4_3 = L1_3
      L5_3 = L18_1
      L2_3(L3_3, L4_3, L5_3)
      L2_3 = PlaySound
      L3_3 = "DLC_VW_WIN_CHIPS"
      L4_3 = "dlc_vw_table_games_frontend_sounds"
      L2_3(L3_3, L4_3)
    end
  end
  L3_2 = "load mugshots and show winners/losers poker"
  L1_2(L2_2, L3_2)
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:ChairReady"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:ChairReady"
function L68_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L2_2 = L11_1
  if L2_2 ~= A1_2 then
    return
  end
  L2_2 = L43_1
  L3_2 = A0_2
  L2_2(L3_2)
end
L66_1(L67_1, L68_1)
L66_1 = RegisterNetEvent
L67_1 = "Poker:Sit"
L66_1(L67_1)
L66_1 = AddEventHandler
L67_1 = "Poker:Sit"
function L68_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L6_2 = IN_CASINO
  if not L6_2 then
    return
  end
  L6_2 = L35_1
  L7_2 = A1_2
  L6_2 = L6_2(L7_2)
  if nil == L6_2 then
    return
  end
  L6_2.syncedState = A3_2
  L7_2 = TaskLookAtEntity
  L8_2 = L6_2.ped
  L9_2 = GetPedFromPlayerId
  L10_2 = A0_2
  L9_2 = L9_2(L10_2)
  L10_2 = 3500
  L11_2 = 2048
  L12_2 = 3
  L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  L7_2 = GetMyPlayerId
  L7_2 = L7_2()
  if A0_2 == L7_2 then
    L5_1 = L6_2
    L7_2 = PlaySound
    L8_2 = "DLC_VW_CONTINUE"
    L9_2 = "dlc_vw_table_games_frontend_sounds"
    L7_2(L8_2, L9_2)
    L7_2 = L5_1.pokerPedSay
    L8_2 = A4_2
    L7_2(L8_2)
    L7_2 = L5_1.chairPositions
    L7_2 = L7_2[A2_2]
    L8_1 = L7_2
    L7_2 = L8_1
    if nil == L7_2 then
      return
    end
    L7_2 = {}
    L25_1 = L7_2
    L7_2 = PokerTableDatas
    L8_2 = L5_1.color
    L7_2 = L7_2[L8_2]
    L9_1 = L7_2
    L7_2 = true
    L10_1 = L7_2
    L17_1 = A5_2
    L7_2 = L54_1
    L7_2()
    L7_2 = L64_1
    L7_2()
  end
end
L66_1(L67_1, L68_1)
function L66_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L2_2 = Repeat
  L3_2 = A0_2
  L4_2 = AMBIENT_POKER_COORDS
  L4_2 = #L4_2
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = L2_2(L3_2, L4_2)
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L1_2[5] = L6_2
  L1_2[6] = L7_2
  L1_2[7] = L8_2
  L1_2[8] = L9_2
  L1_2[9] = L10_2
  L2_2 = pairs
  L3_2 = L1_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L35_1
    L9_2 = AMBIENT_POKER_COORDS
    L10_2 = L7_2 + 1
    L9_2 = L9_2[L10_2]
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L9_2 = L8_2.automate
      L9_2()
    end
  end
end
L67_1 = RegisterNetEvent
L68_1 = "Poker:Sessions"
L67_1(L68_1)
L67_1 = AddEventHandler
L68_1 = "Poker:Sessions"
function L69_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = IN_CASINO
  if not L2_2 then
    return
  end
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L35_1
    L9_2 = L7_2.coords
    L8_2 = L8_2(L9_2)
    if nil ~= L8_2 then
      L8_2.syncedState = L7_2
      L9_2 = L8_2.changeDirtLevel
      L10_2 = L7_2.dirtLevel
      L11_2 = L7_2.dirtProps
      L9_2(L10_2, L11_2)
    end
  end
  L2_2 = Config
  L2_2 = L2_2.CASINO_ENABLE_AMBIENT_PEDS_POKER
  if L2_2 then
    L2_2 = L66_1
    L3_2 = A1_2
    L2_2(L3_2)
  end
end
L67_1(L68_1, L69_1)
function L67_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L35_1
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = L3_2.changeDirtLevel
  L5_2 = A1_2
  L6_2 = A2_2
  L4_2(L5_2, L6_2)
end
Poker_DirtChangedAtCoords = L67_1
function L67_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
  L0_2 = DebugStart
  L1_2 = "Poker_RescanTables"
  L0_2(L1_2)
  L0_2 = {}
  L1_2 = Casino_GetObjectsOfTypes
  L2_2 = {}
  L3_2 = GetHashKey
  L4_2 = "vw_prop_casino_3cardpoker_01"
  L3_2 = L3_2(L4_2)
  L4_2 = GetHashKey
  L5_2 = "vw_prop_casino_3cardpoker_01b"
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L4_2(L5_2)
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L2_2[6] = L8_2
  L2_2[7] = L9_2
  L2_2[8] = L10_2
  L2_2[9] = L11_2
  L2_2[10] = L12_2
  L2_2[11] = L13_2
  L2_2[12] = L14_2
  L2_2[13] = L15_2
  L2_2[14] = L16_2
  L2_2[15] = L17_2
  L2_2[16] = L18_2
  L2_2[17] = L19_2
  L2_2[18] = L20_2
  L2_2[19] = L21_2
  L2_2[20] = L22_2
  L2_2[21] = L23_2
  L2_2[22] = L24_2
  L2_2[23] = L25_2
  L2_2[24] = L26_2
  L2_2[25] = L27_2
  L2_2[26] = L28_2
  L1_2 = L1_2(L2_2)
  L2_2 = SortByDistance
  L3_2 = L1_2
  L4_2 = CASINO_SECOND_ROOM_COORDS
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = 0
  L4_2 = pairs
  L5_2 = L2_2
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = GetEntityCoords
    L11_2 = L9_2
    L10_2 = L10_2(L11_2)
    L11_2 = GetEntityHeading
    L12_2 = L9_2
    L11_2 = L11_2(L12_2)
    L12_2 = IsEntityVisible
    L13_2 = L9_2
    L12_2 = L12_2(L13_2)
    if L12_2 then
      L12_2 = DoesEntityHaveDrawable
      L13_2 = L9_2
      L12_2 = L12_2(L13_2)
      if L12_2 then
        L12_2 = L35_1
        L13_2 = L10_2
        L12_2 = L12_2(L13_2)
        if nil == L12_2 then
          L12_2 = GetEntityModel
          L13_2 = L9_2
          L12_2 = L12_2(L13_2)
          L13_2 = GetHashKey
          L14_2 = "vw_prop_casino_3cardpoker_01"
          L13_2 = L13_2(L14_2)
          if L12_2 == L13_2 then
            L12_2 = 0
            if L12_2 then
              goto lbl_59
            end
          end
          L12_2 = 3
          ::lbl_59::
          L13_2 = Config
          L13_2 = L13_2.POKER_JUNIOR_ENABLED
          if L13_2 then
            L13_2 = GetEntityCoords
            L14_2 = L9_2
            L13_2 = L13_2(L14_2)
            L14_2 = vector3
            L15_2 = Config
            L15_2 = L15_2.POKER_JUNIOR_COORDS
            L15_2 = L15_2[1]
            L16_2 = Config
            L16_2 = L16_2.POKER_JUNIOR_COORDS
            L16_2 = L16_2[2]
            L17_2 = Config
            L17_2 = L17_2.POKER_JUNIOR_COORDS
            L17_2 = L17_2[3]
            L14_2 = L14_2(L15_2, L16_2, L17_2)
            L13_2 = L13_2 - L14_2
            L13_2 = #L13_2
            L14_2 = 0.1
            if L13_2 < L14_2 then
              L12_2 = 2
            end
          end
          L13_2 = L57_1
          L14_2 = L9_2
          L15_2 = nil
          L16_2 = nil
          L17_2 = nil
          L18_2 = L12_2
          L19_2 = L3_2
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
          L14_2 = table
          L14_2 = L14_2.insert
          L15_2 = L0_1
          L16_2 = L13_2
          L14_2(L15_2, L16_2)
          L14_2 = table
          L14_2 = L14_2.insert
          L15_2 = L0_2
          L16_2 = L13_2
          L14_2(L15_2, L16_2)
          L14_2 = PokerTableDatas
          L14_2 = L14_2[L12_2]
          L15_2 = GetObjectOffsetFromCoords
          L16_2 = L10_2
          L17_2 = L11_2
          L18_2 = 0.0
          L19_2 = -0.05
          L20_2 = 1.5
          L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
          L16_2 = CreateTargetZone
          L17_2 = vector3
          L18_2 = L15_2.x
          L19_2 = L15_2.y
          L20_2 = L15_2.z
          L17_2 = L17_2(L18_2, L19_2, L20_2)
          L18_2 = 1.5
          L19_2 = 3.0
          L20_2 = L11_2
          L21_2 = {}
          L22_2 = {}
          L22_2.num = 1
          L22_2.type = "client"
          L22_2.event = "Casino:Target"
          L22_2.icon = "fas fa-chair"
          L23_2 = removePlaceholderText
          L24_2 = Translation
          L24_2 = L24_2.Get
          L25_2 = "UI_PRESS_TO_PLAY"
          L24_2 = L24_2(L25_2)
          L25_2 = " "
          L26_2 = L14_2.Title
          L27_2 = "."
          L24_2 = L24_2 .. L25_2 .. L26_2 .. L27_2
          L23_2 = L23_2(L24_2)
          L22_2.label = L23_2
          L22_2.targeticon = "fas fa-chair"
          function L23_2(A0_3, A1_3, A2_3)
            local L3_3
            L3_3 = CAN_INTERACT
            return L3_3
          end
          L22_2.canInteract = L23_2
          L23_2 = {}
          L24_2 = 255
          L25_2 = 255
          L26_2 = 255
          L27_2 = 255
          L23_2[1] = L24_2
          L23_2[2] = L25_2
          L23_2[3] = L26_2
          L23_2[4] = L27_2
          L22_2.drawColor = L23_2
          L23_2 = {}
          L24_2 = 30
          L25_2 = 144
          L26_2 = 255
          L27_2 = 255
          L23_2[1] = L24_2
          L23_2[2] = L25_2
          L23_2[3] = L26_2
          L23_2[4] = L27_2
          L22_2.successDrawColor = L23_2
          L22_2.eventAction = "poker_enter"
          L22_2.entity = L9_2
          L22_2.color = L12_2
          L23_2 = {}
          L23_2.num = 2
          L23_2.type = "client"
          L23_2.event = "Casino:Target"
          L23_2.icon = "fas fa-circle-info"
          L24_2 = Translation
          L24_2 = L24_2.Get
          L25_2 = "ABOUT"
          L24_2 = L24_2(L25_2)
          L23_2.label = L24_2
          L23_2.targeticon = "fas fa-chair"
          function L24_2(A0_3, A1_3, A2_3)
            local L3_3
            L3_3 = CAN_INTERACT
            return L3_3
          end
          L23_2.canInteract = L24_2
          L24_2 = {}
          L25_2 = 255
          L26_2 = 255
          L27_2 = 255
          L28_2 = 255
          L24_2[1] = L25_2
          L24_2[2] = L26_2
          L24_2[3] = L27_2
          L24_2[4] = L28_2
          L23_2.drawColor = L24_2
          L24_2 = {}
          L25_2 = 30
          L26_2 = 144
          L27_2 = 255
          L28_2 = 255
          L24_2[1] = L25_2
          L24_2[2] = L26_2
          L24_2[3] = L27_2
          L24_2[4] = L28_2
          L23_2.successDrawColor = L24_2
          L23_2.eventAction = "poker_info"
          L23_2.entity = L9_2
          L23_2.color = L12_2
          L21_2[1] = L22_2
          L21_2[2] = L23_2
          L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
        end
      end
    end
    if L3_2 < 13 then
      L3_2 = L3_2 + 1
    else
      L3_2 = 0
    end
  end
  L4_2 = {}
  L5_2 = pairs
  L6_2 = L0_2
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L4_2
    L13_2 = L10_2.coords
    L11_2(L12_2, L13_2)
  end
  L5_2 = #L4_2
  if L5_2 > 0 then
    L5_2 = TriggerServerEvent
    L6_2 = "Poker:GetSessions"
    L7_2 = L4_2
    L5_2(L6_2, L7_2)
  end
  return L0_2
end
Poker_RescanTables = L67_1
function L67_1()
  local L0_2, L1_2
  L0_2 = DebugStart
  L1_2 = "Poker_Load"
  L0_2(L1_2)
  L0_2 = Poker_RescanTables
  L0_2()
end
Poker_Load = L67_1
function L67_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = DebugStart
  L1_2 = "Poker_Destroy"
  L0_2(L1_2)
  L0_2 = pairs
  L1_2 = L0_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.destroy
    L6_2()
  end
  L0_2 = L31_1
  L0_2()
end
Poker_Destroy = L67_1
