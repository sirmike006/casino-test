local L0_1, L1_1
function L0_1()
  local L0_2, L1_2
end
ClothingShop_Load = L0_1
function L0_1()
  local L0_2, L1_2
end
ClothingShop_Destroy = L0_1
