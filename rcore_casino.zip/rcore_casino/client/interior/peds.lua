local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1
L0_1 = {}
L1_1 = nil
L2_1 = 0.003
L3_1 = {}
L4_1 = "PROP_HUMAN_SEAT_BENCH_DRINK_BEER"
L5_1 = "PROP_HUMAN_SEAT_CHAIR_UPRIGHT"
L6_1 = "PROP_HUMAN_SEAT_CHAIR_FOOD"
L7_1 = "PROP_HUMAN_SEAT_DECKCHAIR_DRINK"
L8_1 = "PROP_HUMAN_SEAT_CHAIR"
L9_1 = "WORLD_HUMAN_PARTYING"
L10_1 = "WORLD_HUMAN_MOBILE_FILM_SHOCKING"
L11_1 = "WORLD_HUMAN_STAND_IMPATIENT"
L12_1 = "WORLD_HUMAN_WINDOW_SHOP_BROWSE"
L13_1 = "WORLD_HUMAN_SMOKING"
L14_1 = "WORLD_HUMAN_STAND_MOBILE"
L15_1 = "WORLD_HUMAN_HANG_OUT_STREET"
L16_1 = "WORLD_HUMAN_GUARD_STAND_CASINO"
L17_1 = "WORLD_HUMAN_LEANING_CASINO_TERRACE"
L3_1[1] = L4_1
L3_1[2] = L5_1
L3_1[3] = L6_1
L3_1[4] = L7_1
L3_1[5] = L8_1
L3_1[6] = L9_1
L3_1[7] = L10_1
L3_1[8] = L11_1
L3_1[9] = L12_1
L3_1[10] = L13_1
L3_1[11] = L14_1
L3_1[12] = L15_1
L3_1[13] = L16_1
L3_1[14] = L17_1
L4_1 = {}
L5_1 = {}
L6_1 = nil
L7_1 = {}
L6_1 = L7_1
L6_1.id = 1
L6_1.animName = "base"
L6_1.animDict = "amb@world_human_cheering@female_c"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 2
L6_1.animName = "base"
L6_1.animDict = "anim@amb@office@boardroom@boss@female@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 3
L6_1.animName = "simple_inspect_v1_idartistfemale"
L6_1.animDict = "anim@amb@business@cfid@cfid_desk_docs@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 4
L6_1.animName = "intro_loop_ped_d"
L6_1.animDict = "anim@heists@fleeca_bank@hostages@intro"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 5
L6_1.animName = "nice_clothes"
L6_1.animDict = "anim@heists@ornate_bank@chat_manager"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 6
L6_1.animName = "amb_world_human_hang_out_street_female_hold_arm_idle_b"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 7
L6_1.animName = "try_shoes_positive_a"
L6_1.animDict = "mp_clothing@female@shoes"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 8
L6_1.animName = "idle_a"
L6_1.animDict = "amb@prop_human_seat_deckchair_drink@female@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 9
L6_1.animName = "check_out_b"
L6_1.animDict = "clothingshirt"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 10
L6_1.animName = "idle_a"
L6_1.animDict = "amb@world_human_partying@female@partying_beer@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 11
L6_1.animName = "amanda_gets_drunk_loop1"
L6_1.animDict = "timetable@amanda@drunk_in_kitchen@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 12
L6_1.animName = "base"
L6_1.animDict = "amb@world_human_drinking@beer@female@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 13
L6_1.animName = "idle_a"
L6_1.animDict = "amb@world_human_partying@female@partying_cellphone@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 14
L6_1.animName = "amb_world_human_drinking_beer_female_base"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 15
L6_1.animName = "computer_idle"
L6_1.animDict = "anim@amb@office@boss@male@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 16
L6_1.animName = "stand_phone_lookaround_nowork"
L6_1.animDict = "anim@amb@business@bgen@bgen_no_work@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 17
L6_1.animName = "try_shirt_neutral_a"
L6_1.animDict = "mp_clothing@female@shirt"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 18
L6_1.animName = "idle_d"
L6_1.animDict = "amb@prop_human_seat_chair@female@legs_crossed@idle_b"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 19
L6_1.animName = "amb_prop_human_seat_chair_drink_beer_male_idle_c"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 20
L6_1.animName = "nice_clothes"
L6_1.animDict = "anim@heists@ornate_bank@chat_manager"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 21
L6_1.animName = "base"
L6_1.animDict = "amb@world_human_prostitute@hooker@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 22
L6_1.animName = "base"
L6_1.animDict = "amb@world_human_hang_out_street@female_arms_crossed@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 23
L6_1.animName = "li-mi_amb_club_09_v1_female^1"
L6_1.animDict = "anim@amb@nightclub@dancers@club_ambientpeds@low-med_intensity"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 24
L6_1.animName = "idle_d"
L6_1.animDict = "anim_casino_a@amb@casino@games@slots@ped_male@engaged@01b@idles"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 25
L6_1.animName = "charm"
L6_1.animDict = "anim@heists@ornate_bank@chat_manager"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 26
L6_1.animName = "bet_max_press_spin"
L6_1.animDict = "anim_casino_a@amb@casino@games@slots@ped_male@slouchy@01b@play@v02"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 27
L6_1.animName = "idle_a"
L6_1.animDict = "timetable@denice@ig_4"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 28
L6_1.animName = "idle_b"
L6_1.animDict = "amb@prop_human_seat_chair@female@legs_crossed@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 29
L6_1.animName = "request_card"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_male@engaged@01a@play@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 30
L6_1.animName = "base"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_male@engaged@01a@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 31
L6_1.animName = "scratch_face_a_m_y_vinewood_01"
L6_1.animDict = "anim@amb@casino@valet_scenario@pose_d@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 32
L6_1.animName = "reaction_great"
L6_1.animDict = "anim_casino_a@amb@casino@games@slots@ped_female@regular@02a@reacts@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 33
L6_1.animName = "amb_world_human_seat_wall_female_hands_by_sides_idle_c"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 34
L6_1.animName = "place_bet"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_female@engaged@01a@play@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 35
L6_1.animName = "reaction_good_var02"
L6_1.animDict = "anim_casino_a@amb@casino@games@slots@ped_female@slouchy@01a@reacts@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 36
L6_1.animName = "collect_chips"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_male@engaged@01a@play@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 37
L6_1.animName = "place_bet"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_female@engaged@01a@play@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 38
L6_1.animName = "base"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_male@engaged@01a@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 39
L6_1.animName = "look_ahead_l_a_m_y_vinewood_01"
L6_1.animDict = "anim@amb@casino@valet_scenario@pose_c@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 40
L6_1.animName = "amb_world_human_partying_male_partying_beer_base"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 41
L6_1.animName = "amb_prop_human_seat_chair_male_generic_base"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 42
L6_1.animName = "reaction_great"
L6_1.animDict = "anim_casino_a@amb@casino@games@insidetrack@ped_male@regular@02a@reacts@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 43
L6_1.animName = "hi_dance_crowd_09_v1_male^4"
L6_1.animDict = "anim@amb@nightclub@dancers@crowddance_groups@hi_intensity"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 44
L6_1.animName = "reaction_great"
L6_1.animDict = "anim_casino_a@amb@casino@games@insidetrack@ped_female@regular@01a@reacts_big_screen@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 45
L6_1.animName = "crazy_dance_1"
L6_1.animDict = "misschinese1crazydance"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 46
L6_1.animName = "amb_world_human_partying_male_partying_beer_base"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 47
L6_1.animName = "idle_a_bartender"
L6_1.animDict = "mini@strip_club@drink@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 48
L6_1.animName = "intro_loop_ped_d"
L6_1.animDict = "anim@heists@fleeca_bank@hostages@intro"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 49
L6_1.animName = "amb_world_human_leaning_female_wall_back_texting_idle_a"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 50
L6_1.animName = "idle_a"
L6_1.animDict = "anim@amb@casino@hangout@ped_female@stand@03b@idles_convo"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 51
L6_1.animName = "idle_b"
L6_1.animDict = "amb@world_human_hang_out_street@male_c@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 52
L6_1.animName = "base_a_m_y_vinewood_01"
L6_1.animDict = "anim@amb@casino@valet_scenario@pose_c@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 53
L6_1.animName = "interview_short_anton"
L6_1.animDict = "missmic4premiere"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 54
L6_1.animName = "base_a_m_y_vinewood_01"
L6_1.animDict = "anim@amb@world_human_valet@normal@base@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 55
L6_1.animName = "idle"
L6_1.animDict = "rcmjosh1"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 56
L6_1.animName = "idle_b"
L6_1.animDict = "anim@amb@casino@shop@ped_female@01a@idles"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 57
L6_1.animName = "base"
L6_1.animDict = "amb@world_human_cheering@female_d"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 58
L6_1.animName = "cellphone_call_listen_b"
L6_1.animDict = "cellphone@str_female"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 59
L6_1.animName = "idle_c"
L6_1.animDict = "amb@prop_human_seat_chair@female@arms_folded@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 60
L6_1.animName = "try_tie_positive_c"
L6_1.animDict = "clothingtie"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 61
L6_1.animName = "prem_actress_star_a"
L6_1.animDict = "missmic4premiere"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 62
L6_1.animName = "idle_b"
L6_1.animDict = "anim@amb@casino@hangout@ped_male@stand@01a@idles"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 63
L6_1.animName = "deal_card_player_02"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@dealer"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 64
L6_1.animName = "deal_card_player_02"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@dealer"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 65
L6_1.animName = "deal_card_player_02"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@dealer"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 66
L6_1.animName = "deal_card_self"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@dealer"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 67
L6_1.animName = "look_around_a_m_y_vinewood_01"
L6_1.animDict = "anim@amb@casino@valet_scenario@pose_a@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 68
L6_1.animName = "fidget_wet"
L6_1.animDict = "move_m@_idles@wet"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 69
L6_1.animName = "base"
L6_1.animDict = "timetable@tracy@ig_8@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 70
L6_1.animName = "peeing"
L6_1.animDict = "rcm_epsilonism4"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 71
L6_1.animName = "try_tie_negative_a"
L6_1.animDict = "clothingtie"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 72
L6_1.animName = "idle_a"
L6_1.animDict = "anim@amb@clubhouse@boardroom@boss@female@base_l@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 73
L6_1.animName = "cs_amandatownley_dual-2"
L6_1.animDict = "fam_6_mcs_1-2"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 74
L6_1.animName = "base"
L6_1.animDict = "timetable@amanda@drunk@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 75
L6_1.animName = "sleep_cycle_v2_operator"
L6_1.animDict = "anim@amb@business@cfm@cfm_machine_no_work@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 76
L6_1.animName = "amb_world_human_leaning_female_wall_back_texting_idle_a"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 77
L6_1.animName = "idle_c"
L6_1.animDict = "amb@world_human_hang_out_street@female_arms_crossed@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 78
L6_1.animName = "idle_b"
L6_1.animDict = "amb@world_human_hang_out_street@male_c@idle_a"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 79
L6_1.animName = "reaction_terrible"
L6_1.animDict = "anim_casino_a@amb@casino@games@insidetrack@ped_female@regular@01a@reacts_big_screen@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 80
L6_1.animName = "amb_world_human_leaning_female_wall_back_texting_idle_a"
L6_1.animDict = "anim@amb@nightclub@peds@"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 81
L6_1.animName = "reaction_impartial_var01"
L6_1.animDict = "anim_casino_a@amb@casino@games@slots@ped_female@engaged@01b@reacts@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 82
L6_1.animName = "idle_wait"
L6_1.animDict = "mini@hookers_sp"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 83
L6_1.animName = "collect_chips"
L6_1.animDict = "anim_casino_b@amb@casino@games@blackjack@ped_male@engaged@01a@play@v01"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 84
L6_1.animName = "idle_a"
L6_1.animDict = "anim_casino_a@amb@casino@games@insidetrack@ped_male@regular@02b@idles"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 85
L6_1.animName = "base"
L6_1.animDict = "amb@code_human_wander_clipboard@male@base"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = {}
L6_1 = L7_1
L6_1.id = 86
L6_1.animName = "walk"
L6_1.animDict = "anim@move_f@waitress"
L7_1 = table
L7_1 = L7_1.insert
L8_1 = L4_1
L9_1 = L6_1
L7_1(L8_1, L9_1)
L7_1 = 1
L8_1 = nil
function L9_1()
  local L0_2, L1_2, L2_2
  L0_2 = WAITRESS_MODEL
  if not L0_2 then
    return
  end
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3
    L0_3 = RequestModelAndWait
    L1_3 = "vw_prop_vw_ice_bucket_01a"
    L0_3(L1_3)
    L0_3 = RequestAnimDictAndWait
    L1_3 = "anim@move_f@waitress"
    L0_3(L1_3)
    L0_3 = vector3
    L1_3 = table
    L1_3 = L1_3.unpack
    L2_3 = WAITRESS_PATH
    L2_3 = L2_3[1]
    L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3 = L1_3(L2_3)
    L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3)
    L1_3 = nil
    while true do
      L2_3 = DoesEntityExist
      L3_3 = L1_3
      L2_3 = L2_3(L3_3)
      if L2_3 then
        break
      end
      L2_3 = RequestModelAndWait
      L3_3 = WAITRESS_MODEL
      L2_3(L3_3)
      L2_3 = CreatePed
      L3_3 = 2
      L4_3 = GetHashKey
      L5_3 = WAITRESS_MODEL
      L4_3 = L4_3(L5_3)
      L5_3 = L0_3
      L6_3 = 0.0
      L7_3 = false
      L8_3 = false
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
      L1_3 = L2_3
      L2_3 = Wait
      L3_3 = 1000
      L2_3(L3_3)
    end
    L2_3 = CreateObject
    L3_3 = GetHashKey
    L4_3 = "vw_prop_vw_ice_bucket_01a"
    L3_3 = L3_3(L4_3)
    L4_3 = L0_3
    L5_3 = false
    L6_3 = false
    L7_3 = false
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
    L3_3 = AttachEntityToEntity
    L4_3 = L2_3
    L5_3 = L1_3
    L6_3 = GetPedBoneIndex
    L7_3 = L1_3
    L8_3 = 28422
    L6_3 = L6_3(L7_3, L8_3)
    L7_3 = 0.0
    L8_3 = 0.0
    L9_3 = 0.0
    L10_3 = 0.0
    L11_3 = 0.0
    L12_3 = 0.0
    L13_3 = true
    L14_3 = true
    L15_3 = false
    L16_3 = false
    L17_3 = 2
    L18_3 = true
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3)
    L3_3 = SetPedBrave
    L4_3 = L1_3
    L3_3(L4_3)
    L3_3 = CreateContinualMovement
    L4_3 = L1_3
    L5_3 = WAITRESS_PATH
    L3_3(L4_3, L5_3)
    L3_3 = TaskPlayAnim
    L4_3 = L1_3
    L5_3 = "anim@move_f@waitress"
    L6_3 = "walk"
    L7_3 = 1.0
    L8_3 = -1.5
    L9_3 = -1
    L10_3 = 49
    L11_3 = 0
    L12_3 = false
    L13_3 = false
    L14_3 = false
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    L3_3 = table
    L3_3 = L3_3.insert
    L4_3 = L5_1
    L5_3 = L1_3
    L3_3(L4_3, L5_3)
    L3_3 = table
    L3_3 = L3_3.insert
    L4_3 = L5_1
    L5_3 = L2_3
    L3_3(L4_3, L5_3)
  end
  L2_2 = "InitializeWaitresses"
  L0_2(L1_2, L2_2)
end
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = pairs
  L1_2 = L0_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = ForceDeleteEntity
    L7_2 = L5_2.entity
    L6_2(L7_2)
  end
  L0_2 = pairs
  L1_2 = L5_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = ForceDeleteEntity
    L7_2 = L5_2
    L6_2(L7_2)
  end
  L0_2 = {}
  L5_1 = L0_2
  L0_2 = {}
  L0_1 = L0_2
end
Peds_Destroy = L10_1
function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if nil == A1_2 then
    A1_2 = "%s"
  end
  L2_2 = {}
  i = 1
  L3_2 = string
  L3_2 = L3_2.gmatch
  L4_2 = A0_2
  L5_2 = "([^"
  L6_2 = A1_2
  L7_2 = "]+)"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2, L5_2)
  for L7_2 in L3_2, L4_2, L5_2, L6_2 do
    L8_2 = i
    L2_2[L8_2] = L7_2
    L8_2 = i
    L8_2 = L8_2 + 1
    i = L8_2
  end
  return L2_2
end
function L11_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3
    L0_3 = SetEntityVisible
    L1_3 = A0_2
    L2_3 = false
    L0_3(L1_3, L2_3)
    L0_3 = Wait
    L1_3 = 100
    L0_3(L1_3)
    L0_3 = SetEntityVisible
    L1_3 = A0_2
    L2_3 = true
    L0_3(L1_3, L2_3)
  end
  L3_2 = "local function Blink"
  L1_2(L2_2, L3_2)
end
function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = L1_1
  if nil == L0_2 then
    return
  end
  L0_2 = L1_1.entity
  L1_2 = 1
  L2_2 = IsControlPressed
  L3_2 = 2
  L4_2 = 209
  L2_2 = L2_2(L3_2, L4_2)
  if L2_2 then
    L1_2 = 10
  end
  L2_2 = GetEntityCoords
  L3_2 = L0_2
  L2_2 = L2_2(L3_2)
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 172
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_2.y
    L6_2 = L2_1
    L6_2 = L6_2 * L1_2
    L5_2 = L5_2 + L6_2
    L6_2 = L2_2.z
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 173
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_2.y
    L6_2 = L2_1
    L6_2 = L6_2 * L1_2
    L5_2 = L5_2 - L6_2
    L6_2 = L2_2.z
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 174
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_1
    L5_2 = L5_2 * L1_2
    L4_2 = L4_2 - L5_2
    L5_2 = L2_2.y
    L6_2 = L2_2.z
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 175
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_1
    L5_2 = L5_2 * L1_2
    L4_2 = L4_2 + L5_2
    L5_2 = L2_2.y
    L6_2 = L2_2.z
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 111
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_2.y
    L6_2 = L2_2.z
    L7_2 = L2_1
    L7_2 = L7_2 * L1_2
    L6_2 = L6_2 - L7_2
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 112
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = vector3
    L4_2 = L2_2.x
    L5_2 = L2_2.y
    L6_2 = L2_2.z
    L7_2 = L2_1
    L7_2 = L7_2 * L1_2
    L6_2 = L6_2 + L7_2
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L3_2
    L3_2 = SetEntityCoordsNoOffset
    L4_2 = L0_2
    L5_2 = L2_2
    L6_2 = true
    L7_2 = true
    L8_2 = true
    L9_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1.coords = L2_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 205
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = GetEntityHeading
    L4_2 = L0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L2_1
    L4_2 = L4_2 * L1_2
    L4_2 = L4_2 * 100
    L3_2 = L3_2 + L4_2
    L4_2 = SetEntityHeading
    L5_2 = L0_2
    L6_2 = L3_2
    L4_2(L5_2, L6_2)
    L1_1.heading = L3_2
  end
  L3_2 = IsControlPressed
  L4_2 = 2
  L5_2 = 206
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = GetEntityHeading
    L4_2 = L0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L2_1
    L4_2 = L4_2 * L1_2
    L4_2 = L4_2 * 100
    L3_2 = L3_2 - L4_2
    L4_2 = SetEntityHeading
    L5_2 = L0_2
    L6_2 = L3_2
    L4_2(L5_2, L6_2)
    L1_1.heading = L3_2
  end
  L3_2 = IsControlJustPressed
  L4_2 = 2
  L5_2 = 210
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3
      L0_3 = FreezeEntityPosition
      L1_3 = L0_2
      L2_3 = false
      L0_3(L1_3, L2_3)
      L0_3 = Wait
      L1_3 = 500
      L0_3(L1_3)
      L0_3 = PlaceObjectOnGroundProperly
      L1_3 = L0_2
      L0_3(L1_3)
      L0_3 = FreezeEntityPosition
      L1_3 = L0_2
      L2_3 = true
      L0_3(L1_3, L2_3)
      L0_3 = GetEntityCoords
      L1_3 = L0_2
      L0_3 = L0_3(L1_3)
      L1_1.coords = L0_3
    end
    L5_2 = "handle aiming buttons placing object to ground properly"
    L3_2(L4_2, L5_2)
  end
end
function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = pairs
  L2_2 = L0_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.entity
    if L7_2 == A0_2 then
      L8_2 = L1_1
      if L8_2 ~= L6_2 then
        L1_1 = L6_2
        L8_2 = L11_1
        L9_2 = L1_1.entity
        L8_2(L9_2)
      end
    end
  end
end
function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L2_2 = L10_1
  L3_2 = A0_2
  L4_2 = ";"
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = #L2_2
  if L3_2 < 8 then
    return
  end
  L3_2 = vector3
  L4_2 = L8_1.x
  L5_2 = tonumber
  L6_2 = L2_2[2]
  L5_2 = L5_2(L6_2)
  L4_2 = L4_2 - L5_2
  L5_2 = L8_1.y
  L6_2 = tonumber
  L7_2 = L2_2[3]
  L6_2 = L6_2(L7_2)
  L5_2 = L5_2 - L6_2
  L6_2 = L8_1.z
  L7_2 = tonumber
  L8_2 = L2_2[4]
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 - L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not A1_2 then
    L4_2 = L8_1
    L4_2 = L3_2 - L4_2
    L4_2 = #L4_2
    if L4_2 < 7.0 then
      return
    end
  end
  L4_2 = tonumber
  L5_2 = L2_2[5]
  L4_2 = L4_2(L5_2)
  L5_2 = tonumber
  L6_2 = L2_2[1]
  L5_2 = L5_2(L6_2)
  L6_2 = L2_2[18]
  L7_2 = L2_2[19]
  L8_2 = L2_2[20]
  L9_2 = tonumber
  L10_2 = L2_2[21]
  L9_2 = L9_2(L10_2)
  if not L9_2 then
    L9_2 = 1
  end
  L10_2 = Config
  L10_2 = L10_2.CASINO_AMBIENT_PEDS_DENSITY
  if L9_2 > L10_2 then
    return
  end
  L10_2 = tonumber
  L11_2 = L5_2
  L10_2 = L10_2(L11_2)
  if not L10_2 then
    L10_2 = GetHashKey
    L11_2 = L5_2
    L10_2 = L10_2(L11_2)
    L5_2 = L10_2
  end
  L10_2 = RequestModelAndWait
  L11_2 = L5_2
  L10_2(L11_2)
  L10_2 = CreatePed
  L11_2 = 2
  L12_2 = L5_2
  L13_2 = L3_2
  L14_2 = L4_2
  L15_2 = false
  L16_2 = false
  L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L11_2 = SetModelAsNoLongerNeeded
  L12_2 = L5_2
  L11_2(L12_2)
  L11_2 = SetEntityCoordsNoOffset
  L12_2 = L10_2
  L13_2 = L3_2
  L11_2(L12_2, L13_2)
  L11_2 = SetBlockingOfNonTemporaryEvents
  L12_2 = L10_2
  L13_2 = true
  L11_2(L12_2, L13_2)
  L11_2 = FreezeEntityPosition
  L12_2 = L10_2
  L13_2 = true
  L11_2(L12_2, L13_2)
  L11_2 = 0
  L12_2 = 11
  L13_2 = 1
  for L14_2 = L11_2, L12_2, L13_2 do
    L15_2 = L14_2 + 6
    L15_2 = L2_2[L15_2]
    L16_2 = L10_1
    L17_2 = L15_2
    L18_2 = "/"
    L16_2 = L16_2(L17_2, L18_2)
    L17_2 = tonumber
    L18_2 = L16_2[1]
    L17_2 = L17_2(L18_2)
    L18_2 = tonumber
    L19_2 = L16_2[2]
    L18_2 = L18_2(L19_2)
    L19_2 = tonumber
    L20_2 = L16_2[3]
    L19_2 = L19_2(L20_2)
    L20_2 = SetPedComponentVariation
    L21_2 = L10_2
    L22_2 = L17_2
    L23_2 = L18_2
    L24_2 = L19_2
    L20_2(L21_2, L22_2, L23_2, L24_2)
  end
  if "NOSCENE" ~= L6_2 then
    L11_2 = TaskStartScenarioInPlace
    L12_2 = L10_2
    L13_2 = L6_2
    L14_2 = 0
    L15_2 = true
    L11_2(L12_2, L13_2, L14_2, L15_2)
  elseif nil ~= L8_2 and "NOANIM" ~= L8_2 then
    L11_2 = RequestAnimDictAndWait
    L12_2 = L8_2
    L11_2(L12_2)
    L11_2 = TaskPlayAnim
    L12_2 = L10_2
    L13_2 = L8_2
    L14_2 = L7_2
    L15_2 = 3.0
    L16_2 = 3.0
    L17_2 = -1
    L18_2 = 1
    L19_2 = 0
    L20_2 = true
    L21_2 = true
    L22_2 = true
    L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
  end
  if nil == L7_2 then
    L7_2 = "NOANIM"
  end
  if nil == L8_2 then
    L8_2 = "NOANIM"
  end
  L11_2 = {}
  L11_2.entity = L10_2
  L11_2.coords = L3_2
  L11_2.heading = L4_2
  L11_2.model = L5_2
  L11_2.animName = L7_2
  L11_2.animDict = L8_2
  L11_2.scenarioName = L6_2
  L11_2.density = L9_2
  L12_2 = table
  L12_2 = L12_2.insert
  L13_2 = L0_1
  L14_2 = L11_2
  L12_2(L13_2, L14_2)
end
function L15_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2
  L0_2 = ""
  L1_2 = 0
  L2_2 = pairs
  L3_2 = L0_1
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.coords
    L9_2 = vector3
    L10_2 = L8_1.x
    L11_2 = L8_2.x
    L10_2 = L10_2 - L11_2
    L11_2 = L8_1.y
    L12_2 = L8_2.y
    L11_2 = L11_2 - L12_2
    L12_2 = L8_1.z
    L13_2 = L8_2.z
    L12_2 = L12_2 - L13_2
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    L8_2 = L9_2
    L9_2 = L7_2.scenarioName
    if not L9_2 then
      L9_2 = "NOSCENE"
    end
    L10_2 = L7_2.model
    L11_2 = L7_2.heading
    L12_2 = L8_2.x
    if 0.0 ~= L12_2 then
      L1_2 = L1_2 + 1
    end
    L12_2 = ""
    L13_2 = 0
    L14_2 = 11
    L15_2 = 1
    for L16_2 = L13_2, L14_2, L15_2 do
      L17_2 = GetPedDrawableVariation
      L18_2 = L7_2.entity
      L19_2 = L16_2
      L17_2 = L17_2(L18_2, L19_2)
      L18_2 = GetPedTextureVariation
      L19_2 = L7_2.entity
      L20_2 = L16_2
      L18_2 = L18_2(L19_2, L20_2)
      L19_2 = L12_2
      L20_2 = L16_2
      L21_2 = "/"
      L22_2 = L17_2
      L23_2 = "/"
      L24_2 = L18_2
      L25_2 = ";"
      L19_2 = L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2 .. L25_2
      L12_2 = L19_2
    end
    L13_2 = L7_2.animName
    L14_2 = L7_2.animDict
    if "NOANIM" ~= L13_2 or "NOSCENE" ~= L9_2 then
      L15_2 = L0_2
      L16_2 = L10_2
      L17_2 = ";"
      L18_2 = L8_2.x
      L19_2 = ";"
      L20_2 = L8_2.y
      L21_2 = ";"
      L22_2 = L8_2.z
      L23_2 = ";"
      L24_2 = L11_2
      L25_2 = ";"
      L26_2 = L12_2
      L27_2 = L9_2
      L28_2 = ";"
      L29_2 = L13_2
      L30_2 = ";"
      L31_2 = L14_2
      L32_2 = ";"
      L33_2 = L7_2.density
      L34_2 = "\n"
      L15_2 = L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2 .. L27_2 .. L28_2 .. L29_2 .. L30_2 .. L31_2 .. L32_2 .. L33_2 .. L34_2
      L0_2 = L15_2
    end
  end
  L2_2 = TriggerServerEvent
  L3_2 = "Casino:SaveAmbientPeds"
  L4_2 = L0_2
  L2_2(L3_2, L4_2)
end
function L16_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "table" == L1_2 then
    L1_2 = vector3
    L2_2 = A0_2[1]
    L3_2 = A0_2[2]
    L4_2 = A0_2[3]
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
  end
  L1_2 = pairs
  L2_2 = L0_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = vector3
    L8_2 = L6_2.coords
    L8_2 = L8_2.x
    L9_2 = L6_2.coords
    L9_2 = L9_2.y
    L10_2 = 0
    L7_2 = L7_2(L8_2, L9_2, L10_2)
    L8_2 = vector3
    L9_2 = A0_2.x
    L10_2 = A0_2.y
    L11_2 = 0
    L8_2 = L8_2(L9_2, L10_2, L11_2)
    L9_2 = L7_2 - L8_2
    L9_2 = #L9_2
    if L9_2 < 1 then
      L9_2 = true
      return L9_2
    end
  end
  L1_2 = false
  return L1_2
end
Peds_SomeoneNearCoords = L16_1
function L16_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = Config
  L1_2 = L1_2.CASINO_ENABLE_AMBIENT_PEDS
  if not L1_2 then
    return
  end
  L1_2 = Peds_Destroy
  L1_2()
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    while true do
      L0_3 = IN_CASINO
      if L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 33
      L0_3(L1_3)
    end
    L0_3 = GetGamePool
    L1_3 = "CObject"
    L0_3 = L0_3(L1_3)
    L1_3 = pairs
    L2_3 = L0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = GetEntityModel
      L8_3 = L6_3
      L7_3 = L7_3(L8_3)
      L8_3 = GetHashKey
      L9_3 = "vw_prop_vw_casino_podium_01a"
      L8_3 = L8_3(L9_3)
      if L7_3 == L8_3 then
        L7_3 = GetEntityCoords
        L8_3 = L6_3
        L7_3 = L7_3(L8_3)
        L8_1 = L7_3
        break
      end
    end
    L1_3 = L8_1
    if not L1_3 then
      L1_3 = PODIUMOBJECT_POS
      L8_1 = L1_3
    end
    L1_3 = {}
    L2_3 = "peddata.txt"
    L3_3 = "peddata_gabz.txt"
    L4_3 = "peddata_gabz.txt"
    L5_3 = "peddata_k4mb1.txt"
    L6_3 = "peddata_gtao.txt"
    L7_3 = "0"
    L8_3 = "peddata_oldk4mb1.txt"
    L9_3 = "0"
    L10_3 = "peddata_cawles.txt"
    L11_3 = "peddata_molo.txt"
    L1_3[1] = L2_3
    L1_3[2] = L3_3
    L1_3[3] = L4_3
    L1_3[4] = L5_3
    L1_3[5] = L6_3
    L1_3[6] = L7_3
    L1_3[7] = L8_3
    L1_3[8] = L9_3
    L1_3[9] = L10_3
    L1_3[10] = L11_3
    L2_3 = Config
    L2_3 = L2_3.MapType
    L2_3 = L1_3[L2_3]
    if L2_3 then
      L3_3 = LoadResourceFile
      L4_3 = GetCurrentResourceName
      L4_3 = L4_3()
      L5_3 = "client/interior/"
      L6_3 = L2_3
      L5_3 = L5_3 .. L6_3
      L3_3 = L3_3(L4_3, L5_3)
      L4_3 = L10_1
      L5_3 = L3_3
      L6_3 = "\n"
      L4_3 = L4_3(L5_3, L6_3)
      L5_3 = pairs
      L6_3 = L4_3
      L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
      for L9_3, L10_3 in L5_3, L6_3, L7_3, L8_3 do
        L11_3 = #L10_3
        if L11_3 > 10 then
          L11_3 = L14_1
          L12_3 = L10_3
          L13_3 = A0_2
          L11_3(L12_3, L13_3)
        end
      end
    end
    L3_3 = L9_1
    L3_3()
  end
  L3_2 = "Peds_Load"
  L1_2(L2_2, L3_2)
end
Peds_Load = L16_1
