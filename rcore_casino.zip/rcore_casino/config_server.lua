ServerConfig = {
    Discord = false, -- 是否啟用 Discord 通知（檢查 config_server.lua）
    DiscordInterval = 60000 * 1, -- 15 mins
    HookUrl = "https://discord.com/api/webhooks/1404687019850072116/qvlWxRGkhpmb-DA_m8BhoN9y61cUcVJrs9rVnZNKdVUyVP0q3MrbPXmIGHjcP2xeeROt",
}
