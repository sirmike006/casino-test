--[[local statsInited = false

local function setupStats()
    if not statsInited then
        statsInited = true
        TriggerEvent('rcore_stats:api:ensureCategory', 'casino', '賭場', function()
            -- 老虎機統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_time_spent",
                "賭場 - 老虎機 - 遊玩時間", "player", "time", "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_time_spent_ach1",
                        "老虎機新秀", "暢玩老虎機10分鐘，初嘗勝利的甜蜜！", "joystick",
                        "rcore_casino_slots_time_spent", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_time_spent_ach2",
                        "老虎機狂熱者", "沉浸老虎機30分鐘，連勝的節奏無法阻擋！", "joystick",
                        "rcore_casino_slots_time_spent", 30)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_time_spent_ach3",
                        "老虎機傳奇", "縱橫老虎機60分鐘，無人能擋的賭場霸主！", "joystick",
                        "rcore_casino_slots_time_spent", 60)
                end)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_wins", "賭場 - 老虎機 - 勝利次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_loss", "賭場 - 老虎機 - 失敗次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_games_played",
                "賭場 - 老虎機 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_profit",
                "賭場 - 老虎機 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_profitreal", "賭場 - 老虎機 - 淨利潤",
                "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_slots_jackpots", "賭場 - 老虎機 - 大獎次數",
                "player", nil, "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_jackpots_ach1",
                        "夢幻大獎", "一擊命中老虎機大獎，財富之門為你敞開！", "party-popper",
                        "rcore_casino_slots_jackpots", 1)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_jackpots_ach2",
                        "三連星輝", "三度摘下老虎機大獎，幸運之神與你同行！", "party-popper",
                        "rcore_casino_slots_jackpots", 3)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_slots_jackpots_ach3",
                        "賭場王者", "五次奪得老虎機大獎，賭場因你而顫抖！", "party-popper",
                        "rcore_casino_slots_jackpots", 5)
                end)

            -- 輪盤統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_time_spent",
                "賭場 - 輪盤 - 遊玩時間", "player", "time", "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_roulette_time_spent_ach1",
                        "輪盤新星", "體驗輪盤10分鐘，旋轉間的刺激令人心動！", "spade",
                        "rcore_casino_roulette_time_spent", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_roulette_time_spent_ach2",
                        "輪盤狂徒", "舞動輪盤30分鐘，每一轉都是勝利的序曲！", "spade",
                        "rcore_casino_roulette_time_spent", 30)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_roulette_time_spent_ach3",
                        "輪盤大師", "主宰輪盤60分鐘，命運之輪為你臣服！", "spade",
                        "rcore_casino_roulette_time_spent", 60)
                end)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_wins", "賭場 - 輪盤 - 勝利次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_loss", "賭場 - 輪盤 - 失敗次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_games_played",
                "賭場 - 輪盤 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_profit",
                "賭場 - 輪盤 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_roulette_profitreal",
                "賭場 - 輪盤 - 淨利潤", "player", "finance", "casino", true, nil)

            -- 撲克統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_time_spent",
                "賭場 - 撲克 - 遊玩時間", "player", "time", "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_poker_time_spent_ach1",
                        "撲克新手", "試煉撲克10分鐘，牌桌智慧初露鋒芒！", "diamond",
                        "rcore_casino_poker_time_spent", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_poker_time_spent_ach2",
                        "撲克熱血", "征戰撲克30分鐘，牌桌梟雄正在崛起！", "diamond",
                        "rcore_casino_poker_time_spent", 30)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_poker_time_spent_ach3",
                        "撲克傳奇", "統領撲克60分鐘，詐牌之王震懾全場！", "diamond",
                        "rcore_casino_poker_time_spent", 60)
                end)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_wins", "賭場 - 撲克 - 勝利次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_loss", "賭場 - 撲克 - 失敗次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_games_played",
                "賭場 - 撲克 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_profit",
                "賭場 - 撲克 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_poker_profitreal",
                "賭場 - 撲克 - 淨利潤", "player", "finance", "casino", true, nil) -- 修正描述錯誤

            -- 二十一點統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_time_spent",
                "賭場 - 二十一點 - 遊玩時間", "player", "time", "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_bj_time_spent_ach1",
                        "二十一點新秀", "挑戰二十一點10分鐘，進退之間顯露鋒芒！", "club",
                        "rcore_casino_bj_time_spent", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_bj_time_spent_ach2",
                        "二十一點高手", "縱橫二十一點30分鐘，算牌技藝令人驚嘆！", "club",
                        "rcore_casino_bj_time_spent", 30)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_bj_time_spent_ach3",
                        "二十一點王牌", "稱霸二十一點60分鐘，莊家因你而畏懼！", "club",
                        "rcore_casino_bj_time_spent", 60)
                end)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_wins", "賭場 - 二十一點 - 勝利次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_loss", "賭場 - 二十一點 - 失敗次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_games_played",
                "賭場 - 二十一點 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_profit",
                "賭場 - 二十一點 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_bj_profitreal", "賭場 - 二十一點 - 淨利潤",
                "player", "finance", "casino", true, nil)

            -- 賽馬統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_time_spent",
                "賭場 - 賽馬 - 遊玩時間", "player", "time", "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_track_time_spent_ach1",
                        "賽馬新貴", "投身賽馬10分鐘，賽場熱血即刻點燃！", "paw-print",
                        "rcore_casino_track_time_spent", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_track_time_spent_ach2",
                        "賽馬熱衷者", "馳騁賽馬30分鐘，勝利終點近在咫尺！", "paw-print",
                        "rcore_casino_track_time_spent", 30)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_track_time_spent_ach3",
                        "賽馬霸主", "統治賽馬60分鐘，賽場之王無可匹敵！", "paw-print",
                        "rcore_casino_track_time_spent", 60)
                end)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_wins", "賭場 - 賽馬 - 勝利次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_loss", "賭場 - 賽馬 - 失敗次數",
                "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_games_played",
                "賭場 - 賽馬 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_profit",
                "賭場 - 賽馬 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_track_profitreal",
                "賭場 - 賽馬 - 淨利潤", "player", "finance", "casino", true, nil)

            -- 幸運輪統計
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_time_spent",
                "賭場 - 幸運輪 - 遊玩時間", "player", "time", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_wins", "賭場 - 幸運輪 - 勝利次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_loss", "賭場 - 幸運輪 - 失敗次數", "player",
                nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_games_played",
                "賭場 - 幸運輪 - 遊玩局數", "player", nil, "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_profit",
                "賭場 - 幸運輪 - 總贏額", "player", "finance", "casino", true, nil)
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_wheel_profitreal", "賭場 - 幸運輪 - 淨利潤",
                "player", "finance", "casino", true, nil)

            -- 兌換櫃檯統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_cashier_used", "賭場 - 兌換櫃檯使用次數",
                "player", nil, "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_cashier_used_ach1", "財富初探",
                        "造訪兌換櫃檯10次，財富之門徐徐開啟！", "hand-coins", "rcore_casino_cashier_used", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_cashier_used_ach2", "常客風采",
                        "頻繁光顧兌換櫃檯50次，賭場常客的耀眼光芒！", "hand-coins",
                        "rcore_casino_cashier_used", 50)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_cashier_used_ach3", "財富大師",
                        "兌現財富100次，金錢帝國由你掌控！", "hand-coins", "rcore_casino_cashier_used", 100)
                end)

            -- 賭場訪問統計與成就
            TriggerEvent('rcore_stats:api:ensureStatType', "rcore_casino_visits", "賭場 - 訪問次數", "player", nil,
                "casino", true, nil, function()
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_visits_ach1", "賭場旅人",
                        "踏入賭場10次，奢華人生初體驗！", "coins", "rcore_casino_visits", 10)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_visits_ach2", "賭場常客",
                        "巡遊賭場50次，牌桌上無人不識你的風采！", "coins", "rcore_casino_visits", 50)
                    TriggerEvent('rcore_stats:api:ensureAchievement', "rcore_casino_visits_ach3", "賭場貴賓",
                        "駐足賭場100次，華麗殿堂成為你的第二故鄉！", "coins", "rcore_casino_visits", 100)
                end)
        end)
    end
end

if Config.Rcore_Stats then
    CreateThread(function()
        if GetResourceState("rcore_stats") == "started" or GetResourceState("rcore_stats") == "starting" then
            while not statsInited do
                TriggerEvent('rcore_stats:api:isReady', function(isReady)
                    if isReady then
                        setupStats()
                    end
                end)
                Wait(1000)
            end
        end
    end, "rcore_stats api is ready")
end]]