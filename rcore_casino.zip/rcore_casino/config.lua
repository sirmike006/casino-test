Config = {
    -- Locale
    Locale = "en", -- en

    -- Map
    MapType = 5,
    -- 1: UncleJust Casino / DlcIplLoader
    -- 2: Gabz Casino
    -- 3: NoPixel Casino
    -- 4: k4mb1 casino
    -- 5: GTA:O Interior (rcore_casino_interior)
    -- 6: Underground Casino PALETO
    -- 7: K4MB1 old enterable casino (casinointerior & casinoexterior)
    -- 8: patoche_casino
    -- 9: Clawles: Casino Los Santos
    -- 10: Molo Casino
    -- 11: Jurassic Jackpot Casino 
    -- make sure rcore_casino_interior is disabled when using another map type, and don't forget to remove rcore_casino_interior from dependencies in fxmanifest.lua as well

    --[[
    Gabz Casino
    • copy "\extra\gabz-casino\gabz_vw_vwdlc_int_01.ytyp" to "cfx-gabz-casino\stream\ytyp\"
   
    NoPixel Casino
    • delete \stream\Main\ydr\vw_prop_vw_luckywheel_01a.ydr in NoPixel Casino
    • copy "\extra\nopixel\gbz_vw_vwdlc_int_01.ytyp" inside stream\Main\ytyp in NoPixel Casino
    • copy "\extra\nopixel\vw_vwint01_betting_desks.ydr" inside stream\Main\ydr in NoPixel Casino

    K4MB1 old enterable casino
    • copy "brown_casinoextended.ytyp" to "casinointerior\stream\base k4mb1-old-casino"
    ]]

    -- Xmas trees
    -- • configurable in xmas\xmas_cl.lua and xmas\xmas_sv.lua
    Xmas = false,

    -- Target
    UseTarget = false, -- whether to use target zones or not
    TargetZoneType = 1, -- 1: q_target, 2: bt_target, 3: qb-target, 4: ox_target

    -- Chips, Inventory Settings
    UseVirtualChips = true, -- false: use inventory for chips, true: use virtual chips which are saved in the casino_players table
    InventoryResource = Inventory.AutoChoose, -- name of the inventory resource, set to Inventory.Framework if you want to use frameworks' inventory functions
    --[[
    choose InventoryResource = Inventory.AutoChoose for auto choose, or choose between:
    Inventory.Framework for built in inventory functions
    Inventory.OX for ox_inventory
    Inventory.LJ for lj_inventory
    Inventory.MF for mf_inventory
    Inventory.PS for ps_inventory
    Inventory.QS for qs-inventory
    Inventory.CodeM for codem-inventory
    ]]
    MoneyInventoryItemName = nil, -- name of the money inventory item, set to nil, if you don't want to use inventory item as the money
    UseOnlyMoney = true, -- 如果你想禁用使用賭場籌碼並只使用金錢，則設定為true
    ExchangeRate = 1, -- 設定一枚賭場籌碼的價值，例如，設定為5，如果1枚籌碼等於5$ (最小值: 0.1，按0.1、0.5或1進行四捨五入)
    ChipsInventoryItem = "casino_chips",
    UseBankMoney = false, -- 現金或銀行?
    DailyWidthdrawLimit = 0, -- 玩家每天（24小時）可以從收銀台提取多少錢，設定為0則停用

    -- 在賭場要遵守規矩?
    RestrictControls = true, -- 不要跳躍，不要在賭場內攻擊

    -- 酒吧
    BarShowSnacks = false, -- 如果您只想在調酒師菜單中看到飲品，則設定為false

    -- 內部賽車場
    IT_STARTING_SOON_TIME = 0, -- *即將開始畫面* 持續時間；預設: 0
    IT_MAIN_EVENT_MIN_PLAYERS = 1, -- 開始主要賽事所需的最少玩家；預設: 2
    IT_MAIN_EVENT_ENABLED = true, -- 當為false時，主要賽事將被禁用，大螢幕只會顯示紫色的空閒畫面；預設: true
    IT_MAIN_EVENT_BETTING_TIME = 60 * 2, -- 玩家為主要賽事下注的時間，螢幕上會顯示馬匹；預設: 60 * 5 (5分鐘)
    IT_MAIN_EVENT_RACE_DURATION = 33, -- 主要賽事的賽程長度；預設: 33
    IT_MAIN_EVENT_HORSE_ODDS = {2, 5, 6, 15, 16, 30}, -- 本地遊戲的最大賠率限制(1到30)，預設: {1, 5, 6, 15, 16, 30} (2匹賠率為1到5的馬，2匹賠率為6到15的馬，2匹賠率為16到30的馬)
    IT_MAIN_EVENT_RACE_MAX_BET = 10000000, -- 主要賽事的最大賭注
    IT_MAIN_EVENT_RACE_MIN_BET = 100000, -- 主要賽事的最小賭注
    IT_LOCAL_RACE_DURATION = 30, -- 本地賽事（橙色畫面）的長度；預設: 30
    IT_LOCAL_RACE_HORSE_ODDS = {2, 5, 6, 15, 16, 30}, -- 本地遊戲的最大賠率限制(1到30)，預設: {1, 5, 6, 15, 16, 30} (2匹賠率為1到5的馬，2匹賠率為6到15的馬，2匹賠率為16到30的馬)
    IT_LOCAL_RACE_MAX_BET = 10000000, -- 本地賽事的最大賭注
    IT_LOCAL_RACE_MIN_BET = 100000, -- 本地賽事的最小賭注
    IT_LOCAL_RACE_COOLDOWN = 0, -- 玩家在另一場本地遊戲之前要等待多久，以秒為單位，(預設: 60 * 10)
    IT_MAIN_EVENT_COOLDOWN = 0, -- 玩家在另一場主要賽事之前要等待多久，以秒為單位，(預設: 60 * 10)
    -- 馬的獲勝機會基於其賠率，但是，如果您想使遊戲更加不利，請降低獲勝機會：
    IT_LOCAL_RACE_WIN_CHANCE = 60, -- 獲勝機率 (從0到100)，預設: 100，100意味著完全不是*不利的*
    IT_MAIN_EVENT_RACE_WIN_CHANCE = 60, -- 獲勝機率 (從0到100)，預設: 100，100意味著完全不是*不利的*

    -- 輪盤
    ROULETTE_JUNIOR_ENABLED = true, -- 設定是否要有初級輪盤（藍色）桌子給新手（低賭金）
    ROULETTE_JUNIOR_COORDS = {1004.790, 57.295, 68.432},

    -- 老虎機
    SLOTS_1ST_PERSON = true, -- 當旋轉老虎機時切換到第一人稱視角

    -- 幸運輪
    LUCKY_WHEEL_ENABLED = false, -- 如果您不想使用 Lucky Wheel，請設定為 false
    LUCKY_WHEEL_FREE_DRINKS_FOR = (60 * 60 * 24), -- 當有人在幸運輪上旋到"免費飲料"時，他們可以獲得多長時間的免費飲料。預設: 24小時 (60 * 60 * 24)
    LUCKY_WHEEL_COOLDOWN = (60 * 60 * 24), -- 玩家必須等待多久才能再次旋轉。預設: 24小時 (60 * 60 * 24)
    LUCKY_WHEEL_VEHICLE_ALTERNATIVE = "Money9", -- 如果玩家旋轉車輛，但此刻沒有可用的頒獎台車輛，則旋轉至此項。定義：「Money50K」（第二大獎）
    LUCKY_WHEEL_CAR_WINABLE = true, -- true: 玩家可以贏得車輛，false: 車只是裝飾
    LUCKY_WHEEL_PAY_TO_SPIN = 0, -- 設定旋轉的價格（籌碼），設定為0表示免費旋轉，或設定為現有的庫存名稱，例如LUCKY_WHEEL_PAY_TO_SPIN = "wheel_ticket" 表示使用庫存物品支付
    LUCKY_WHEEL_CAR_ONE_WINNER = true, -- 如果只有一位玩家可以贏得展台車輛，則設為true。當有人贏得它後，車輛將從展台上消失。

    -- 二十一點
    BLACKJACK_JUNIOR_ENABLED = true, -- 設定是否要有初級二十一點（藍色）桌子給新手（低賭金）
    BLACKJACK_JUNIOR_COORDS = {1004.183, 53.192, 68.432},

    -- 撲克
    POKER_JUNIOR_ENABLED = true, -- 設定是否要有初級撲克（藍色）桌子給新手（低賭金）
    POKER_JUNIOR_COORDS = {998.439, 61.031, 68.432},

    -- 出納員
    CASHIER_DAILY_BONUS = 1000, -- 玩家每日可於出納員處領取的日常訪客獎金。如不想給予每日獎金，設為0。預設: 1000
    CASHIER_VIP_PRICE = 50000, -- 賭場VIP會員的價格。預設: 50000
    CASHIER_VIP_DURATION = (60 * 60 * 24) * 7, -- 玩家的VIP身份在此時間後重置。預設: 7天
    CASHIER_SHOW_SOCIETY_BALANCE = false, -- 是否在出納員界面上顯示可用的社會餘額

    -- 賭場設定 (除非有人告訴你，否則不要更改 :)
    CAS_DOUBLECHECK_COORDS = vector3(984.528, 52.299, 70.238),
    CASINO_ENABLE_AMBIENT_PEDS = false, -- 站立的NPC
    CASINO_ENABLE_AMBIENT_PEDS_SLOTS = false, -- 玩老虎機的NPC
    CASINO_ENABLE_AMBIENT_PEDS_POKER = false, -- 玩撲克的NPC
    CASINO_ENABLE_AMBIENT_PEDS_BLACKJACK = false, -- 玩二十一點的NPC
    CASINO_ENABLE_AMBIENT_PEDS_ROULETTE = false, -- 玩輪盤的NPC
    CASINO_AMBIENT_PEDS_DENSITY = 3, -- 1: 少量, 2: 中等, 3: 大量NPC
    CASINO_SAVE_TIMER = 30000, -- 資料庫更新間隔
    DISABLE_IDLE_CAM = true, -- 禁用閒置鏡頭動畫 (四處看)
    CASINO_ANIM_TIMEOUT = 750, -- 動畫之間的暫停 (以毫秒為單位)，減少此數字可加快互動動畫，但要小心，太小的數字可能導致動畫不同步。預設: 750
    PRICES_CURRENCY = "$", -- $, €, £, ¥, ₽, ₩, ₹ ...
    RADAR_ZOOMLEVEL = 0.0, -- 自訂雷達縮放，從0.0 (最近) 到更高
    ENTER_CASINO_FADEOUT = 0, -- 進入賭場時是否淡出螢幕 (0: 停用, 1: 只有首次進入, 2: 每次進入)
    CASHIER_MULTITASK = true, -- 多名玩家可以同時使用出納員
    LOAD_SCENE = true, -- 進入後加載整個賭場遊戲區（建議）
    CLEAR_OBJECTS_ON_ENTER = false, -- 進入賭場後銷毀所有本地創建的 ped/物體，以節省空間，設置為 false
    --
    JOB_PODIUMCAR_OWNERSHIP_CHECK = true,
    JOB_PODIUMCAR_OWNERSHIP_DELETE_ORIGINAL = true,
    JOB_PODIUMCAR_DELETE_ORIGINAL_FUNCTION_CLIENT = function(vehicleId, plateNumber) -- 車商在交付車輛後執行的客戶端函數
        SetEntityAsMissionEntity(vehicleId, true, true)
        DeleteVehicle(vehicleId)
    end,

    CASINO_BLIPS_SHORT_RANGE = false, -- true: 圖標僅對賭場附近的玩家可見，false: 圖標始終可見
    CASINO_BLIP_ID = 679, -- 679是鑽石圖標 [https://docs.fivem.net/docs/game-references/blips/]
    --
    AMBIENT_SOUNDS = false, -- 啟用賭場背景音效

    Debug = false,

    -- 如果存在一些錯誤，這將有助於指出其來源。例如CreateThread/Event/等等。
    ErrorDebug = false,
    
    -- 車牌設定
    PlateLetters = 3,
    PlateNumbers = 3,
    PlateUseSpace = true,

    -- 喝酒
    DrunkSystem = 1,
    -- 1 = 自動檢測 / 內建, 在離開賭場後重置醉酒程度
    -- 2 = esx_status
    -- 3 = evidence:client:SetStatus
    -- 4 = rcore_drunk -- https://store.rcore.cz/package/5161129


    -- 其他資源
    EnableGuidebookIntegration = false, -- https://store.rcore.cz/package/5041989

    -- 社交
    -- ⚠️ 為了使社交功能運作，請按照以下指示操作: https://documentation.rcore.cz/paid-resources/rcore_casino/society
    EnableSociety = false, -- 是否啟用社會帳戶
    SocietyAutoInstall = true, -- 如果不存在，則自動安裝社團帳戶
    SocietyName = "society_casino",
    SocietyLimitFromBalance = 10000, -- 如果社交帳戶的金額低於此值，它將開始支付減少的金額，(SocietyLimitPayoutPercentage)
    SocietyLimitPayoutPercentage = 35, -- 例如：如果 SocietyLimitPayoutPercentage 為 35%，SocietyLimitFromBalance 為 10000 => 如果社團銀行帳戶餘額低於 10000，則收銀員的 1000 支出將限制為 350
    -- 啟用後，所有賭場付款（收銀員、酒吧、幸運輪）都通過社會帳戶，如果帳戶中沒有足夠的錢，玩家就不會得到報酬
    SocietyFramework = Society.AutoChoose,
    --[[
    設定 Society.AutoChoose 進行自動選擇，或選擇以下選項：
    社會.QbBanking
    協會.QbBossMenu
    社會.Qb管理
    社會復興銀行
    社會.OkokBanking
    社會.管理710
    社會金融銀行
    社會.EsxAddonAccount
    社會.SnipeBanking
    ]]
    -- 造訪 /server/main/society.lua 取得自訂社會框架

    -- 通知
    NotifySystem = 1,
    --[[
    1：預設 GTAV 風格通知
    2：okok通知
    3：esx_通知
    4：qb_通知，
    5：ox_notify
    6：origen幫助通知
    ]]

    -- 工作
    BossGrade = 2, -- 賭場工作的最高級（老闆）
    BossName = "boss",
    JobName = "casino", -- 工作 ID（我想不是標題，不要更改它）

    -- 傳送進入 & 離開
    LeaveThroughTeleport = false, -- 如果啟用，人們將無法離開賭場大廈，相反，當他們接近入口時會被提示（如果您的地圖離洛聖都太遠，這很有用）
    EnterPosition = vector3(2469.584473, -280.015869, -58.267620),
    EnterCheckpointPosition = vector3(923.470093, 47.249229, 79.8), -- 進入賭場的自定義標記，例如，位於不同城市的自定義賭場建築前等
    LeavePosition = vector3(919.127380, 51.120274, 80.898659), -- 玩家在*離開後*出現的地方，例如，在不同城市的自定義賭場建築前等
    LeaveArea = vector3(2468.992188, -287.276459, -58.267506), -- 玩家被提示離開賭場的地方，例如，在主門前

    -- 使用者介面
    UIFontName = nil, -- 使用者介面的字體，設為nil，如果您不想使用自定義字體，設為字體名稱（帶""），如果您想要註冊並使用位於/stream/fonts資料夾內的字體
    ShowHowToPlayUI = 1, -- 如何玩/關於遊戲的資訊使用者介面（按下'E'後顯示的選單。 (0: 禁用, 1: 只顯示一次, 2: 每次按下'E'後都顯示)
    ShowChipsHud = true, -- 是否使用右上角的內置籌碼顯示
    UseNUIHUD = false, -- 是否在NUI上使用籌碼顯示 (您可以在'html/index.html'中自定義它)

     -- 數據庫
    MongoDB = false, -- 如果您決定使用MongoDB而不是MYSQL，請不要忘記編輯server/main/cache.lua，server/main/casino.lua和server/utils/plateGenerator.lua中的MongoDB查詢

    -- Mysql 資源
    Ghmattimysql = false, -- 如果您使用"ghmattimysql"而不是mysql-async

    -- 調整
    VoiceTweak = false, -- 如果你在賭場內沒有聲音問題，請保持它為false
    VehicleRGBTweak = false, -- 以RGB數組（color1, color2）保存車臺車顏色，而不是數字
    -- 啟用 rcore_stats？ (https://store.rcore.cz/package/6273968)
    --Rcore_Stats = GetResourceState("rcore_stats") ~= "missing",
    ForceNormalKeyLabels = false, -- 是否以文字（[E]、[F]、[G] 等）取代 blip 圖示程式碼（~INPUT_TALK~）
    TargetUsePeds = false, -- 使用 peds 而不是區域作為目標區域，如果您想使用區域，則設定為 false
}

Framework = {
    -- ⚠️ 有關獨立版本文件，請訪問 https://documentation.rcore.cz/paid-resources/rcore_casino/standalone-version
    -- ⚠️ 有關自定義框架版本文件，請訪問 https://documentation.rcore.cz/paid-resources/rcore_casino/custom-framework

    Active = 5, -- 選擇1表示ESX，2表示QBCore，3表示獨立，4表示自定義，5表示自動檢測
    -- 請按照安裝教程操作: --
    -- https://documentation.rcore.cz/paid-resources/rcore_casino

    -- esx 資源名稱 + 共享對象名稱
    ES_EXTENDED_RESOURCE_NAME = "es_extended",
    ESX_SHARED_OBJECT = "esx:getSharedObject",
    -- esx 額外設定
    BUILTIN_HUD_CHIPS = false,
    BUILTIN_HUD_CHIPS_ICON = "casinochip.png",
    -- qbcore 資源名稱 + 共享對象名稱
    QB_CORE_RESOURCE_NAME = "qb-core",
    QBCORE_SHARED_OBJECT = "QBCore:GetObject",
    -- 獨立設定
    STANDALONE_INITIAL_CHIPS = 1000000 -- 每個人在第一次進入後得到的籌碼
}

if Framework.Active == 2 then
    Config.PlateLetters = 4
    Config.PlateNumbers = 4
    Config.PlateUseSpace = false
end

Events = {
    QB_PLAYER_LOADED = "QBCore:Client:OnPlayerLoaded",
    QB_PLAYER_JOB_UPDATE = "QBCore:Client:OnJobUpdate",
    QB_BOSS_MENU = "qb-bossmenu:client:OpenMenu",
    -- use "qb-bossmenu:client:OpenMenu" for qb-management and "qb-bossmenu:client:openMenu" for qb-bossmenu

    ES_PLAYER_LOADED = "esx:playerLoaded",
    ES_PLAYER_JOB_UPDATE = "esx:setJob",
    ES_BOSS_MENU = "esx_society:openBossMenu"
}

GameplayKeys = {
    TableGamesMaxBet = 44, -- Choose between: (Tab = 204, E = 46, Q = 44, D = 134, Page Down = 207)
    TableGamesGrabCards = 207,
    RouletteHistoryKey = 204
}

AdminGroup = {
    ["god"] = true,
    ["admin"] = true,
    ["mod"] = true,
    ["moderator"] = true
}

-- 啟用/停用個別遊戲/活動
GameStates = {{
    activity = "slots",
    title = "Slot Machines",
    enabled = true
}, {
    activity = "luckywheel",
    title = "Lucky Wheel",
    enabled = false
}, {
    activity = "insidetrack",
    title = "Inside Track",
    enabled = true
}, {
    activity = "drinkingbar",
    title = "Drinking Bar",
    enabled = false
}, {
    activity = "roulette",
    title = "Roulette",
    enabled = true
}, {
    activity = "poker",
    title = "Poker",
    enabled = true
}, {
    activity = "blackjack",
    title = "Blackjack",
    enabled = true
}, {
    activity = "cashier",
    title = "Cashier",
    enabled = false
}, {
    activity = "seating",
    title = "Seating",
    enabled = true
}, {
    activity = "cameras",
    title = "Cameras",
    enabled = false
}, {
    activity = "casinoteleporter",
    title = "Casino Teleporter (In)",
    enabled = true
}, {
    activity = "casinoentrance",
    title = "Casino Entrance",
    enabled = true
}}

-- 營業時間
-- 例：
-- [1] = {0, 1, 2, 3, 4, 5, 6} -- 從 0:00 到凌晨 6 點
-- [1] = {-1} -- 全天開放

Config.OpeningHours = {
    [1] = {-1}, -- Sunday
    [2] = {-1}, -- Monday
    [3] = {-1}, -- Tuesday
    [4] = {-1}, -- Wednesday
    [5] = {-1}, -- Thursday
    [6] = {-1}, -- Friday
    [7] = {-1} -- Saturday
}

Config.ServerTimezoneOffsetHours = 0 -- 根據時區差異調整伺服器時間

-- 在這裡自訂 blip 函數
-- 使用 blip 圖示 ID：
-- 內部軌道：684，幸運輪：681，收銀員：683，桌上遊戲：680，VIP區/外部圖示：679，
-- [https://docs.fivem.net/docs/game-references/blips/]

function SetCasinoBlip(coords, blipIcon, blipName, exterior)
    local blip = -1
    if type(coords) == "vector3" or type(coords) == "vector2" then
        blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    elseif type(coords) == "number" and DoesEntityExist(coords) then
        blip = AddBlipForEntity(coords)
    end
    --------------
    SetBlipSprite(blip, blipIcon)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, 0)
    SetBlipAsShortRange(blip, exterior and Config.CASINO_BLIPS_SHORT_RANGE or false)
    --------------
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(blipName)
    EndTextCommandSetBlipName(blip)
    if not exterior then
        table.insert(CasinoBlips, blip)
    end
    return blip
end

function RemoveMissionBlip(name)
    if MissionBlips[name] then
        RemoveBlip(MissionBlips[name])
        MissionBlips[name] = nil
    end
end
